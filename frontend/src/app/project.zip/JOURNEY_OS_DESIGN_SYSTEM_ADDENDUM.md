# Journey OS — Design System Addendum
## Additional Screen Specifications (Home, Registration Wizard, Institution Application, Admin User Directory)

**Addendum Version:** 1.0  
**Parent Document:** JOURNEY_OS_COMPLETE_DESIGN_SYSTEM.md v2.0  
**Date:** February 18, 2026  
**Screen Count Update:** 78 → 81 screens  

---

## Purpose of This Addendum

This document extends the core design system to cover three additional screens discovered during implementation, plus an expanded specification for the Registration Wizard. These screens follow all principles from the parent document—The One Rule, three-surface hierarchy, template selection, and token usage.

**New Screens Added:**
1. Home Page (/) — Placeholder landing
2. Institution Application (/apply) — Public waitlist form
3. Admin User Directory (/admin/users) — Cross-institution user management

**Expanded Specification:**
- Registration Wizard (/register) — Full 4-step flow detail

---

# PART 1: UPDATED SCREEN INVENTORY

## 1.1 Revised Screen Count

**Total Screens:** 81 (updated from 78)

**New Category:** PUBLIC ACCESS (4 screens total)
- Landing.tsx (existing, documented in main spec)
- Home.tsx (NEW — placeholder)
- InstitutionApplication.tsx (NEW — /apply)
- Registration.tsx (existing, expanded specification)

**Updated Category:** ADMIN BACKEND (13 screens, +1)
- AdminUserDirectory.tsx (NEW — /admin/users)
- All existing admin screens unchanged

---

## 1.2 Updated Template Mapping

### PUBLIC ACCESS (4 screens)

| Screen | Route | Template | Bookmark | Status |
|--------|-------|----------|----------|--------|
| Landing.tsx | / | Template D | Stats bar | Existing |
| **Home.tsx** | **/** | **Template D** | **None** | **NEW** |
| InstitutionApplication.tsx | /apply | Template D | None | NEW |
| Registration.tsx | /register | Template C | None | Expanded |

### ADMIN BACKEND (13 screens)

| Screen | Route | Template | Bookmark | Status |
|--------|-------|----------|----------|--------|
| **AdminUserDirectory.tsx** | **/admin/users** | **Template B** | **None** | **NEW** |
| AdminDashboard.tsx | /admin | Template B | System KPIs | Existing |
| *(remaining 11 admin screens unchanged)* | | | | |

---

# PART 2: NEW SCREEN SPECIFICATIONS

## 2.1 Home Page (/) — Placeholder

**Story:** Bare-bones landing scaffold  
**Template:** D (Full-Width Flow)  
**Auth:** Public (no authentication required)  
**Route:** `/` (root)

### Visual Structure

```
┌─────────────────────────────────────────────────┐
│                                                 │
│            [cream background fills viewport]    │
│                                                 │
│                                                 │
│                  ┌─────────────┐                │
│                  │   Journey   │                │ ← Logo wordmark
│                  │     OS      │                │   (size lg, 30px)
│                  └─────────────┘                │
│                                                 │
│              Journey OS                         │ ← serif/display-lg
│                                                 │   navyDeep
│                                                 │
│         Platform launching soon                 │ ← sans/body-md
│                                                 │   textSecondary
│                                                 │
└─────────────────────────────────────────────────┘
```

### Design Tokens

**Surface:**
- Background: `cream` (#f5f3ef)
- Full viewport height: `min-h-screen`
- Content: centered both vertically and horizontally

**Typography:**
- Logo: `LogoWordmark` component, size `lg` (30px)
- Heading: `serif` (Lora) / `display-lg` (34px) / `700` / `navyDeep`
- Subtext: `sans` (Source Sans 3) / `body-md` (16px) / `400` / `textSecondary`

**Layout:**
- Container: `max-w-md` (448px)
- Vertical spacing: `gap-6` (24px) between elements
- Alignment: `items-center` + `justify-center` + `text-center`

### Component Structure

```tsx
export default function Home() {
  return (
    <div className="min-h-screen bg-[--cream] flex items-center justify-center p-4">
      <div className="max-w-md flex flex-col items-center gap-6 text-center">
        <LogoWordmark size="lg" variant="default" />
        <h1 className="font-serif text-display-lg font-bold text-[--navy-deep]">
          Journey OS
        </h1>
        <p className="font-sans text-body-md text-[--text-secondary]">
          Platform launching soon
        </p>
      </div>
    </div>
  );
}
```

### States

**Default (only state):**
- No loading state (static content)
- No error state (no data fetching)
- No interactivity (no buttons, links, or forms)

### Responsive Behavior

| Breakpoint | Adjustments |
|------------|-------------|
| Mobile (<640px) | Padding reduces to 16px, logo size remains lg |
| Tablet (640-1023px) | No changes from desktop |
| Desktop (≥1024px) | Full layout as specified |

### Notes

- This is a **temporary placeholder** awaiting the full marketing landing page
- No navigation chrome, no sidebar, no top bar
- When the full landing page (`Landing.tsx`) is ready, this screen may be removed or become a redirect
- Uses Template D with minimal content—demonstrates the template can work at any scale

---

## 2.2 Institution Application (/apply)

**Story:** STORY-U-11  
**Template:** D (Full-Width Flow)  
**Auth:** Public (no authentication required)  
**Route:** `/apply`

### Visual Structure

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│          [cream background, full viewport]              │
│                                                         │
│     ┌───────────────────────────────────────────┐       │
│     │  WHITE CARD                               │       │ ← card on cream
│     │  max-w-lg (32rem), shadow-panel           │       │   = white bg
│     │  radius-2xl (12px), padding 32px          │       │
│     │                                           │       │
│     │  ● WAITLIST                               │       │ ← section marker
│     │  Apply for Platform Access                │       │   (greenDark dot)
│     │  Submit your institution's details...     │       │
│     │                                           │       │
│     │  ┌─────────────────────────────────┐     │       │
│     │  │ INSTITUTION NAME                │     │       │ ← mono label
│     │  │ [parchment input bg]            │     │       │   parchment input
│     │  │ Morehouse School of Medicine    │     │       │   (white parent)
│     │  └─────────────────────────────────┘     │       │
│     │                                           │       │
│     │  [8 more form fields...]                  │       │
│     │                                           │       │
│     │  ┌─────────────────────────────────┐     │       │
│     │  │ Submit Application              │     │       │ ← navyDeep button
│     │  └─────────────────────────────────┘     │       │   full-width
│     │                                           │       │
│     └───────────────────────────────────────────┘       │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Design Tokens

**Surface:**
- Page background: `cream` (#f5f3ef)
- Card: `white` (#ffffff) — follows The One Rule (card on cream = white)
- Card shadow: `shadow-panel` (0 8px 32px rgba(0,44,118,0.04))
- Card border: `1px solid borderLight` (#edeae4)
- Card radius: `radius-2xl` (12px)
- Max width: `max-w-lg` (32rem / 512px)

**Typography:**
- Section marker: `mono` / `label-md` (10px) / `500` / `uppercase` / `textMuted`
- Heading: `serif` / `heading-lg` (22px) / `700` / `navyDeep`
- Subtitle: `sans` / `body-sm` (15px) / `400` / `textSecondary`
- Field labels: `mono` / `label-md` (10px) / `500` / `uppercase` / `textMuted`
- Input text: `sans` / `body-md` (16px) / `400` / `ink`
- Placeholder: `sans` / `body-md` (16px) / `400` / `textMuted`

**Form Elements:**
- Input background: `parchment` (#faf9f6) — follows The One Rule (input inside white card = parchment)
- Input border: `1px solid border` (#e2dfd8)
- Input radius: `radius-lg` (8px)
- Input padding: `13px 16px`
- Input height: `44px` (standard), `120px` (textarea min-height)
- Focus state: border → `blueMid`, box-shadow: `shadow-focus`
- Error state: border → `danger`, helper text in `danger` color

**Button:**
- Background: `navyDeep` (#002c76)
- Hover: `blue` (#004ebc)
- Text: `white`, `sans` / `15px` / `700`
- Radius: `radius-md` (6px)
- Height: `48px` (lg size)
- Full-width in mobile, full-width in card

### Form Fields (9 total)

| # | Field Name | Type | Required | Validation | Placeholder |
|---|------------|------|----------|------------|-------------|
| 1 | Institution Name | text | ✓ | min 3 chars | "Morehouse School of Medicine" |
| 2 | Institution Type | select | ✓ | enum | "MD (Allopathic)" |
| 3 | Accreditation Body | text | ✓ | min 2 chars | "LCME, AOA" |
| 4 | Contact Name | text | ✓ | min 2 chars | "Dr. Jane Smith" |
| 5 | Contact Email | email | ✓ | email regex | "jsmith@msm.edu" |
| 6 | Contact Phone | tel | — | phone format | "+1-404-555-0100" |
| 7 | Student Count | number | ✓ | > 0 | "450" |
| 8 | Website URL | url | — | https:// prefix | "https://www.msm.edu" |
| 9 | Reason for Interest | textarea | — | max 1000 chars | "Tell us why..." |

**Institution Type Options:**
- MD (Allopathic Medical School)
- DO (Osteopathic Medical School)
- Combined MD/DO Program

### Component Structure

```tsx
export default function InstitutionApplication() {
  const [formData, setFormData] = useState({...});
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [serverError, setServerError] = useState(null);

  // Default state: form view
  if (!isSuccess) {
    return (
      <div className="min-h-screen bg-[--cream] flex items-center justify-center p-6">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <SectionMarker label="Waitlist" color="green" />
            <CardTitle className="font-serif text-heading-lg text-[--navy-deep] mt-2">
              Apply for Platform Access
            </CardTitle>
            <p className="font-sans text-body-sm text-[--text-secondary] mt-2">
              Submit your institution's details to join the Journey OS waitlist.
            </p>
          </CardHeader>
          
          <CardContent>
            {serverError && (
              <Alert variant="destructive" className="mb-6">
                {serverError}
              </Alert>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* 9 form fields */}
              <LabeledInput
                label="Institution Name"
                name="institution_name"
                required
                placeholder="Morehouse School of Medicine"
                error={errors.institution_name}
              />
              
              {/* ... remaining 8 fields ... */}
              
              <Button 
                type="submit" 
                variant="primary" 
                size="lg"
                disabled={isSubmitting}
                className="w-full"
              >
                {isSubmitting ? "Submitting..." : "Submit Application"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Success state: confirmation view
  return (
    <div className="min-h-screen bg-[--cream] flex items-center justify-center p-6">
      <Card className="w-full max-w-lg text-center">
        <CardContent className="py-12">
          <div className="w-20 h-20 rounded-full bg-[--green]/10 flex items-center justify-center mx-auto mb-6">
            <span className="text-4xl text-[--green]">✓</span>
          </div>
          
          <h2 className="font-serif text-heading-lg text-[--navy-deep] mb-3">
            Application Submitted
          </h2>
          
          <p className="font-sans text-body-sm text-[--text-secondary]">
            Thank you! Your application for <strong>{formData.institution_name}</strong> is 
            now pending review. We'll contact you at the email you provided.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
```

### States

**1. Default State (Form View)**
- All fields empty (or pre-filled from URL params if applicable)
- Submit button enabled
- No error messages

**2. Validation State (Client-side)**
- Triggers on submit button click
- Each field validates independently
- Red error text appears below invalid fields (sans/caption/danger)
- Errors clear individually as user edits each field
- Submit button remains enabled (validation re-runs on next submit)

**3. Submitting State**
- Button text changes to "Submitting..."
- Button disabled
- All inputs disabled (opacity 0.5)
- No spinner needed (button text change is sufficient)

**4. Error State (Server)**
- Red banner appears above submit button
- Uses Alert component with destructive variant
- Contains server error message
- Submit button re-enabled, text returns to "Submit Application"
- Banner dismisses when user resubmits

**5. Success State (Confirmation)**
- Entire form replaced with success card
- Green checkmark icon (✓) in circle: 80px diameter, green/10% bg, 4xl text size
- "Application Submitted" heading (serif/heading-lg)
- Confirmation message includes institution name from form
- No back link (user must navigate away manually or via browser back)

### API Integration

**Endpoint:** `POST /api/v1/waitlist`

**Request Body:**
```json
{
  "institution_name": "Morehouse School of Medicine",
  "institution_type": "md",
  "accreditation_body": "LCME",
  "contact_name": "Dr. Jane Smith",
  "contact_email": "jsmith@msm.edu",
  "contact_phone": "+1-404-555-0100",
  "student_count": 450,
  "website_url": "https://www.msm.edu",
  "reason": "We are looking to modernize our curriculum..."
}
```

**Success Response (201 Created):**
```json
{
  "id": "uuid",
  "status": "pending",
  "submitted_at": "2026-02-18T14:30:00Z"
}
```

**Error Responses:**
- `400 Bad Request` — validation errors (show in banner)
- `409 Conflict` — institution already applied (show in banner)
- `429 Too Many Requests` — rate limit exceeded (show in banner)
- `500 Server Error` — generic error (show in banner)

### Validation Rules

**Client-Side (before submit):**
```javascript
const validations = {
  institution_name: (v) => v.length >= 3 || "Must be at least 3 characters",
  institution_type: (v) => ["md", "do", "combined"].includes(v) || "Required",
  accreditation_body: (v) => v.length >= 2 || "Must be at least 2 characters",
  contact_name: (v) => v.length >= 2 || "Must be at least 2 characters",
  contact_email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || "Invalid email",
  contact_phone: (v) => !v || /^\+?[\d\s\-()]+$/.test(v) || "Invalid phone format",
  student_count: (v) => Number(v) > 0 || "Must be greater than 0",
  website_url: (v) => !v || /^https?:\/\/.+/.test(v) || "Must start with http:// or https://",
  reason: (v) => !v || v.length <= 1000 || "Maximum 1000 characters"
};
```

### Responsive Behavior

| Breakpoint | Adjustments |
|------------|-------------|
| Mobile (<640px) | Card full-width minus 16px padding each side, form fields stack, textarea 3 rows |
| Tablet (640-1023px) | Card maintains max-w-lg, centered |
| Desktop (≥1024px) | Full layout as specified |

### Accessibility

- All inputs have associated labels (mono/uppercase)
- Error messages linked via `aria-describedby`
- Required fields marked with `aria-required="true"`
- Submit button has clear loading state text
- Focus order: top to bottom through form fields
- Success state announces via `role="status"` + `aria-live="polite"`

---

## 2.3 Admin User Directory (/admin/users)

**Story:** STORY-SA-1  
**Template:** B (Admin Shell)  
**Auth:** Super Admin only (role check enforced)  
**Route:** `/admin/users`

### Visual Structure

```
┌──────────┬──────────────────────────────────────────────────────┐
│          │  TOP BAR (frosted glass)                             │
│  ADMIN   │  User Directory + date                               │
│  SIDE    ├──────────────────────────────────────────────────────┤
│  BAR     │  CONTENT AREA — cream bg                             │
│          │                                                      │
│  green   │  User Directory                    ← serif/display-md │
│  left    │  {N} users                         ← mono count      │
│  border  │                                                      │
│  on      │  ┌─ FILTER BAR (white card) ────────────────────┐   │
│  active  │  │ [Search] [Role ▼] [Status ▼]  {N} users     │   │
│          │  └───────────────────────────────────────────────┘   │
│          │                                                      │
│          │  ┌─ DATA TABLE (white card) ────────────────────┐   │
│          │  │ ┌──────────────────────────────────────────┐ │   │
│          │  │ │ Name  Email  Role  Inst  Status  Login │ │   │ ← parchment
│          │  │ └──────────────────────────────────────────┘ │   │   header
│          │  │ [row hover → parchment]                      │   │
│          │  │ Jane Smith   jane@msm.edu   [Faculty]...    │   │
│          │  │ John Doe     john@msm.edu   [Student]...    │   │
│          │  │ ...                                          │   │
│          │  └───────────────────────────────────────────────┘   │
│          │                                                      │
│          │  ┌─ PAGINATION (parchment footer) ──────────────┐   │
│          │  │ [← Previous]  Page 1 of 5  [Next →]         │   │
│          │  └───────────────────────────────────────────────┘   │
└──────────┴──────────────────────────────────────────────────────┘
```

### Design Tokens

**Surface:**
- Content area: `cream` (#f5f3ef)
- Filter bar card: `white` on cream (follows The One Rule)
- Table card: `white` on cream (follows The One Rule)
- Table header row: `parchment` on white (follows The One Rule)
- Table body rows: `white` (default), `parchment` on hover
- Pagination footer: `parchment` inside white card

**Typography:**
- Page heading: `serif` / `display-md` (30-32px) / `700` / `navyDeep`
- User count: `mono` / `label-md` (10px) / `500` / `textMuted`
- Column headers: `mono` / `label-md` (10px) / `500` / `uppercase` / `textMuted`
- Cell text (Name): `sans` / `body-sm` (15px) / `600` / `textPrimary`
- Cell text (Email): `mono` / `label-md` (10px) / `400` / `textSecondary`
- Cell text (other): `sans` / `body-xs` (14px) / `400` / `textSecondary`

**Table Structure:**
- Cell padding: `12px 16px`
- Row height: auto (min 48px for touch targets)
- Border between rows: `1px solid borderLight`
- Hover transition: `transition-fast` (150ms)

**Badges:**
- Height: `20px`
- Padding: `2px 8px`
- Radius: `radius-sm` (3px)
- Font: `mono` / `label-sm` (9px) / `500` / `uppercase`

### Data Table Columns (6 total)

| Column | Width | Sortable | Content | Treatment |
|--------|-------|----------|---------|-----------|
| Name | flex-1 (auto) | ✓ | Display name + CD badge if course_director | sans/body-sm/600 + amber badge |
| Email | 220px | ✓ | Email address | mono/label-md/textSecondary |
| Role | 140px | ✓ | Role badge | Color-coded badge (see below) |
| Institution | 180px | ✗ | Institution name or "—" | sans/body-xs/textSecondary |
| Status | 100px | ✓ | Colored dot + label | Green dot (active) / gray dot (inactive) |
| Last Login | 140px | ✓ | Formatted date or "Never" | mono/label-sm/textMuted |

### Role Badge Colors

| Role | Badge BG | Badge Text |
|------|----------|------------|
| Super Admin | `rgba(128,0,128,0.1)` (purple) | `#800080` (purple) |
| Institutional Admin | `rgba(43,113,185,0.1)` (blueMid) | `#2b71b9` (blueMid) |
| Faculty | `rgba(105,163,56,0.1)` (green) | `#69a338` (green) |
| Advisor | `rgba(250,157,51,0.1)` (warning) | `#fa9d33` (warning) |
| Student | `rgba(113,128,150,0.1)` (textMuted) | `#718096` (textMuted) |

### Status Indicators

**Active:**
- Dot: 8px diameter circle, `green` (#69a338) fill
- Label: "Active" (sans/caption/textSecondary)

**Inactive:**
- Dot: 8px diameter circle, `warmGray` (#d7d3c8) fill
- Label: "Inactive" (sans/caption/textMuted)

### Filter Bar

**Layout:** White card, padding 16px 24px, flex row with gap 12px, items centered

**Search Input:**
- Placeholder: "Search by name or email..."
- Width: `240px` minimum, flex grows on desktop
- Background: `parchment` (input inside white card = parchment per The One Rule)
- Border: `1px solid border`
- Radius: `radius-lg` (8px)
- Debounce: 300ms after last keystroke
- Icon: magnifying glass SVG (14px) in `textMuted`, positioned left inside input

**Role Dropdown:**
- Options: "All Roles", "Super Admin", "Institutional Admin", "Faculty", "Advisor", "Student"
- Width: `160px`
- Background: `parchment`
- Selected shows role badge color as left border accent (3px)

**Status Dropdown:**
- Options: "All Status", "Active", "Inactive"
- Width: `140px`
- Background: `parchment`

**User Count:**
- Right-aligned, auto margin-left
- Format: "{N} users" (e.g., "247 users")
- Font: `mono` / `label-md` / `textMuted`

### Sorting Behavior

**Sortable Columns (5/6):** Name, Email, Role, Status, Last Login

**Visual Indicators:**
- Unsorted: no icon
- Ascending: ↑ arrow (12px) in `navyDeep`, positioned right of column label
- Descending: ↓ arrow (12px) in `navyDeep`, positioned right of column label

**Interaction:**
- Click column header toggles: unsorted → asc → desc → asc (cycles)
- Only one column sorted at a time
- Sorting updates URL params: `?sort_by=name&sort_dir=asc`
- Sorting resets page to 1

**Non-sortable Column:** Institution (too many unique values, not meaningful to sort)

### Component Structure

```tsx
export default function AdminUserDirectory() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  
  const [filters, setFilters] = useState({
    search: "",
    role: "all",
    status: "all"
  });
  
  const [sort, setSort] = useState({
    by: "name",
    dir: "asc"
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="font-serif text-display-md font-bold text-[--navy-deep]">
            User Directory
          </h1>
          <p className="font-mono text-label-md uppercase text-[--text-muted] mt-1">
            {totalCount} users
          </p>
        </div>

        {/* Filter Bar */}
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Input
              type="search"
              placeholder="Search by name or email..."
              value={filters.search}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="min-w-[240px] flex-1"
            />
            
            <Select value={filters.role} onValueChange={handleRoleChange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="superadmin">Super Admin</SelectItem>
                <SelectItem value="institutional_admin">Inst Admin</SelectItem>
                <SelectItem value="faculty">Faculty</SelectItem>
                <SelectItem value="advisor">Advisor</SelectItem>
                <SelectItem value="student">Student</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={filters.status} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
            
            <span className="ml-auto font-mono text-label-md text-[--text-muted]">
              {totalCount} users
            </span>
          </CardContent>
        </Card>

        {/* Data Table */}
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <LoadingState />
            ) : error ? (
              <ErrorState error={error} onRetry={fetchUsers} />
            ) : users.length === 0 ? (
              <EmptyState onReset={resetFilters} />
            ) : (
              <DataTable
                users={users}
                sort={sort}
                onSort={handleSort}
              />
            )}
          </CardContent>
          
          {/* Pagination Footer */}
          {!loading && !error && users.length > 0 && (
            <CardFooter className="bg-[--parchment] border-t border-[--border-light] p-4">
              <Pagination
                currentPage={page}
                totalPages={totalPages}
                onPageChange={setPage}
              />
            </CardFooter>
          )}
        </Card>
      </div>
    </AdminLayout>
  );
}
```

### States

**1. Loading State**
- 5 skeleton rows with pulsing gray rectangles in each cell
- Skeleton uses `parchment` fill with pulse to `warmGray`
- No header row (header renders immediately)
- Height matches actual row height for no layout shift

**2. Error State**
- Red alert banner inside table card
- Icon: ◈ in `danger` color
- Message: server error message or "Failed to load users"
- Button: "Retry" (secondary variant) triggers refetch
- Preserves filter/sort state on retry

**3. Empty State**
- Centered content in table card, 120px padding vertical
- Icon: ◇ in `navyDeep/10%` circle (80px diameter)
- Heading: "No users found" (serif/heading-lg)
- Description: "Try adjusting your filters" (sans/body-sm/textSecondary)
- Button: "Reset Filters" (secondary) clears all filters and sorts

**4. Success State (Default)**
- Populated table with actual data
- Row hover: background changes to `parchment` (fast transition)
- Pagination footer visible if totalPages > 1

### API Integration

**Endpoint:** `GET /api/v1/admin/users`

**Query Parameters:**
```
?page=1
&limit=25
&search=jane
&role=faculty
&is_active=true
&sort_by=name
&sort_dir=asc
```

**Request Headers:**
```
Authorization: Bearer {token}
```

**Success Response (200 OK):**
```json
{
  "users": [
    {
      "id": "uuid",
      "display_name": "Dr. Jane Smith",
      "email": "jane.smith@msm.edu",
      "role": "faculty",
      "institution": {
        "id": "uuid",
        "name": "Morehouse School of Medicine"
      },
      "is_active": true,
      "is_course_director": true,
      "last_login_at": "2026-02-18T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 25,
    "total_pages": 10,
    "total_count": 247
  }
}
```

**Error Responses:**
- `401 Unauthorized` — missing or invalid token
- `403 Forbidden` — user is not super admin
- `500 Server Error` — show error state with retry

### Pagination

**Layout:** Parchment footer inside white card, padding 16px 24px, flex row

**Components:**
- Previous button: ghost variant, disabled if page === 1
- Page indicator: "Page {current} of {total}" (mono/label-md/textMuted)
- Next button: ghost variant, disabled if page === totalPages

**Behavior:**
- 25 users per page (fixed)
- Page changes update URL: `?page=2`
- Page changes scroll to top of table
- Changing filters resets to page 1

### Responsive Behavior

| Breakpoint | Adjustments |
|------------|-------------|
| Mobile (<640px) | Table horizontal scroll, show Name + Role + Status only, other columns hidden |
| Tablet (640-1023px) | Show Name + Email + Role + Status, hide Institution + Last Login |
| Desktop (≥1024px) | All 6 columns visible |

### Accessibility

- Table uses semantic `<table>` element with `<thead>` and `<tbody>`
- Column headers are `<th>` with `scope="col"`
- Sortable headers have `aria-sort` attribute
- Row hover has sufficient contrast (parchment on white)
- Status dots have accompanying text labels (not icon-only)
- Pagination buttons have `aria-label` for screen readers
- Loading state announces via `aria-live="polite"`

### Special Badge: Course Director (CD)

**When Shown:** If `is_course_director === true`

**Visual Treatment:**
- Appears immediately after name in Name column
- Badge: `warning/10%` background (#fa9d33 at 10%)
- Text: "CD" (mono/label-sm/uppercase/warning)
- Padding: `1px 4px`
- Radius: `radius-sm` (3px)
- Positioned inline with 6px gap from name

---

# PART 3: EXPANDED REGISTRATION WIZARD

## 3.1 Registration Wizard (/register) — Full Specification

**Story:** STORY-U-8  
**Template:** C (Split Panel)  
**Auth:** Public (no authentication required)  
**Route:** `/register`

This expands the existing Registration.tsx documentation with full 4-step wizard detail.

### Visual Structure

```
┌─────────────────────────┬──────────────────────────────────┐
│   BRAND PANEL           │       FORM PANEL                 │
│   (same as Login)       │       cream bg                   │
│                         │                                  │
│   Logo, squares         │   ┌──────────────────────────┐   │
│   Headline, subtitle    │   │ [Progress: 1 2 3 4]      │   │ ← step indicator
│   Pillar grid           │   │                          │   │
│   Thread divider        │   │ WHITE CARD               │   │
│   Institution name      │   │ max-w-md                 │   │
│                         │   │                          │   │
│                         │   │ [Step content]           │   │
│                         │   │                          │   │
│                         │   │ [Back] [Continue]        │   │
│                         │   └──────────────────────────┘   │
│                         │                                  │
│                         │   Already have account? Sign in  │
└─────────────────────────┴──────────────────────────────────┘
```

### Step Progress Indicator

**Visual Treatment:**
- 4 numbered circles connected by horizontal lines
- Circle size: 32px diameter
- Line thickness: 2px
- Gap between circles: 16px on mobile, 24px on desktop

**Step States:**

**Completed:**
- Circle fill: `navyDeep` (#002c76)
- Number: `white` text, `mono` / `label-lg` / `700`
- Connecting line: `navyDeep` (filled)

**Current:**
- Circle fill: `navyDeep` (#002c76)
- Number: `white` text, `mono` / `label-lg` / `700`
- Connecting line to next: `borderLight` (unfilled)

**Future:**
- Circle outline: `2px solid borderLight`
- Circle fill: `white`
- Number: `textMuted`, `mono` / `label-lg` / `500`
- Connecting line: `borderLight` (unfilled)

**Step Labels (shown on sm+ breakpoints):**
- Position: below circles, 8px gap
- Font: `mono` / `label-sm` (9px) / `500` / `uppercase`
- Color: `navyDeep` (completed/current), `textMuted` (future)
- Labels: "Role", "Profile", "Institution", "Consent"

### Step 1: Role Selection

**Heading:** "Select Your Role" (serif/heading-lg/navyDeep)

**Layout:** 3 large card-style buttons, stacked vertically, gap 12px

**Card Structure (each role):**
- Width: full
- Height: auto (min 100px)
- Padding: 20px 24px
- Border: `2px solid borderLight` (default), `2px solid blueMid` (selected)
- Background: `white` (default), `rgba(43,113,185,0.03)` (selected) — blueMid/3%
- Radius: `radius-lg` (8px)
- Cursor: pointer
- Hover: border → `blueMid` (if not selected)
- Transition: `transition-default` (200ms)

**Content:**
- Role name: `sans` / `heading-md` (16px) / `700` / `navyDeep`
- Description: `sans` / `body-sm` (15px) / `400` / `textSecondary`
- Gap between name and description: 4px

**Role Options:**

1. **Faculty**
   - Name: "Faculty"
   - Description: "Create and manage course content, assessments, and curricula."

2. **Student**
   - Name: "Student"
   - Description: "Access learning paths, practice questions, and track your progress."

3. **Advisor**
   - Name: "Advisor"
   - Description: "Monitor student progress, set alerts, and manage interventions."

**Validation:**
- Continue button disabled until a role is selected
- No error messages on this step

**Data Model:**
```typescript
{
  role: "faculty" | "student" | "advisor"
}
```

### Step 2: Profile Information

**Heading:** "Profile Information" (serif/heading-lg/navyDeep)

**Form Fields (3 total):**

1. **Full Name**
   - Label: "FULL NAME" (mono/label-md/uppercase)
   - Input: parchment bg (follows The One Rule)
   - Placeholder: "Dr. Jane Smith"
   - Validation: min 2 characters
   - Error: "Name must be at least 2 characters"

2. **Email**
   - Label: "EMAIL" (mono/label-md/uppercase)
   - Input: parchment bg
   - Placeholder: "you@example.edu"
   - Validation: email regex `^[^\s@]+@[^\s@]+\.[^\s@]+$`
   - Error: "Please enter a valid email address"

3. **Password**
   - Label: "PASSWORD" (mono/label-md/uppercase)
   - Input: parchment bg, type="password"
   - Toggle: eye icon (ghost button, right-aligned inside input)
   - Placeholder: "At least 8 characters"
   - Validation: min 8 chars, 1 uppercase, 1 number
   - Error: "Password must be at least 8 characters with 1 uppercase letter and 1 number"
   - Real-time validation: checkmarks appear next to requirements as they're met

**Password Requirements Checklist:**
- Position: below password input, 12px gap
- Layout: vertical list, gap 4px
- Each item: checkmark icon (8px) + text (sans/caption/textMuted)
- Met requirement: green checkmark + green text
- Unmet requirement: gray circle outline + textMuted

Requirements:
- ✓ At least 8 characters
- ✓ One uppercase letter
- ✓ One number

**Validation Behavior:**
- Validation runs on Continue click
- Errors appear below each invalid field
- Errors clear individually when field is edited
- All fields must be valid to proceed

**Data Model:**
```typescript
{
  display_name: string;
  email: string;      // lowercased and trimmed on submit
  password: string;
}
```

### Step 3: Institution Search

**Heading:** "Institution" (serif/heading-lg/navyDeep)

**Subtext:** "Search for your institution by name or domain" (sans/body-sm/textSecondary)

**Search Input:**
- Label: "INSTITUTION SEARCH" (mono/label-md/uppercase)
- Input: parchment bg, with magnifying glass icon (left)
- Placeholder: "Start typing to search..."
- Debounce: 300ms after last keystroke
- Min characters: 2 (doesn't search until user types 2+ chars)

**Search Behavior:**
- On typing: hits `GET /api/v1/auth/institutions/search?q={query}`
- Results appear in dropdown below input (max-height 200px, scroll)
- Each result shows: Institution name (sans/body-sm/600) + domain (mono/label-sm/textMuted)
- Results have hover state: parchment bg
- Clicking a result selects it and clears the search input

**Selected State:**
- Search input disappears
- Blue info box appears (blueMid/5% bg, blueMid left border 3px)
- Icon: ◆ in blueMid
- Text: "Selected: {institution name}" (sans/body-sm/navyDeep)
- Button: "Change" (ghost, small) to deselect and return to search

**No Results State:**
- Amber warning box (warning/10% bg, warning left border 3px)
- Icon: ▣ in warning
- Text: "Institution not found?" (sans/body-sm/600)
- Link: "/request-institution" styled as blueMid, underline on hover

**Validation:**
- Continue button disabled until an institution is selected
- No error messages on this step

**API Response:**
```json
{
  "institutions": [
    {
      "id": "uuid",
      "name": "Morehouse School of Medicine",
      "domain": "msm.edu"
    }
  ]
}
```

**Data Model:**
```typescript
{
  institution_id: string; // UUID
}
```

### Step 4: FERPA Consent

**Heading:** "FERPA Consent" (serif/heading-lg/navyDeep)

**Subtext:** "Please review and agree to the following disclosure" (sans/body-sm/textSecondary)

**Disclosure Text Box:**
- Background: `parchment` (inside white card, so follows The One Rule in reverse: elevated content)
- Border: `1px solid borderLight`
- Radius: `radius-lg` (8px)
- Padding: 20px
- Max height: 240px (mobile) / 300px (desktop)
- Overflow: auto (scrollable)

**FERPA Disclosure Content:**

```
FERPA Disclosure and Consent

Journey OS Educational Records Notice

1. Data Collection and Storage
   We collect and store your educational records, including assessment 
   results, learning progress, and curriculum interactions, in accordance 
   with the Family Educational Rights and Privacy Act (FERPA).

2. Data Usage
   Your educational data will be used to:
   - Personalize your learning experience
   - Generate adaptive assessments
   - Track competency development
   - Provide analytics to authorized faculty and administrators

3. Data Sharing
   Your records will only be shared with:
   - Faculty teaching your enrolled courses
   - Academic advisors assigned to support you
   - Institutional administrators for compliance reporting
   - No third parties without your explicit consent

4. Your Rights
   Under FERPA, you have the right to:
   - Inspect and review your educational records
   - Request amendments to inaccurate information
   - Consent to disclosures of personally identifiable information
   - File complaints with the U.S. Department of Education

5. Consent Revocation
   You may revoke this consent at any time by contacting your 
   institution's registrar. Revocation will not affect data collected 
   prior to revocation.

For questions, contact privacy@journeyos.edu
```

**Version Label:**
- Position: bottom-right of disclosure box
- Text: "Version 1.0" (mono/label-sm/textMuted)

**Consent Checkbox:**
- Position: 16px below disclosure box
- Checkbox: 18px square, navyDeep when checked
- Label: "I have read and agree to the FERPA disclosure above" (sans/body-sm/ink)
- Wrapper has hover state: background → parchment (subtle)

**Validation:**
- "Create Account" button disabled until checkbox is checked
- Checking/unchecking toggles button state immediately
- No separate validation message needed

**Data Model:**
```typescript
{
  consented: boolean;
  consent_version: "1.0";
}
```

### Navigation Buttons

**Layout:**
- Flex row, space-between
- Gap: 12px
- Margin top: 32px
- Full width on mobile

**Back Button:**
- Variant: ghost
- Size: md (40px height)
- Icon: ← arrow (left)
- Text: "Back"
- Hidden on Step 1
- Always enabled when visible

**Continue/Create Button:**
- Variant: primary (navyDeep bg)
- Size: md (40px height)
- Text: "Continue" (Steps 1-3), "Create Account" (Step 4)
- Icon: → arrow (right, on "Continue"), none on "Create Account"
- Disabled state: warmGray bg, textMuted color
- Disabled when:
  - Step 1: no role selected
  - Step 2: validation fails
  - Step 3: no institution selected
  - Step 4: checkbox not checked OR submitting

**Submitting State (Step 4 only):**
- Button text: "Creating Account..."
- Button disabled
- Spinner: 18px CSS spinner replaces arrow
- All inputs disabled (opacity 0.5)
- Back button disabled

### Form Submission

**Endpoint:** `POST /api/v1/auth/register`

**Request Body:**
```json
{
  "role": "faculty",
  "email": "jane.smith@msm.edu",
  "password": "SecurePass123",
  "display_name": "Dr. Jane Smith",
  "institution_id": "uuid",
  "consented": true,
  "consent_version": "1.0"
}
```

**Success Response (201 Created):**
```json
{
  "id": "uuid",
  "email": "jane.smith@msm.edu",
  "verification_sent": true
}
```

**Error Responses:**
- `400 Bad Request` — validation errors
- `409 Conflict` — email already registered
- `429 Too Many Requests` — rate limit
- `500 Server Error` — generic error

### Error Handling

**Server Error State:**
- Red alert banner appears above the current step
- Icon: ◈ in danger color
- Text: server error message (or generic "Something went wrong")
- Position: above form content, below step indicator
- Dismisses when:
  - User clicks Continue again (retry)
  - User changes the consent checkbox (specific to Step 4)
  - User clicks Back to previous step

**Error Banner Component:**
```tsx
{serverError && (
  <Alert variant="destructive" className="mb-6">
    <AlertDescription>{serverError}</AlertDescription>
  </Alert>
)}
```

### Success State

**Replaces entire wizard with confirmation:**

```
┌─────────────────────────┬──────────────────────────────────┐
│   BRAND PANEL           │       FORM PANEL                 │
│   (same as before)      │       cream bg                   │
│                         │                                  │
│                         │   ┌──────────────────────────┐   │
│                         │   │ WHITE CARD (centered)    │   │
│                         │   │                          │   │
│                         │   │      [✓ checkmark]       │   │ ← green circle
│                         │   │                          │   │   80px diameter
│                         │   │   Check Your Email       │   │
│                         │   │                          │   │
│                         │   │   A verification link    │   │
│                         │   │   has been sent to       │   │
│                         │   │   jane.smith@msm.edu     │   │
│                         │   │                          │   │
│                         │   │   [Go to Login →]        │   │
│                         │   │                          │   │
│                         │   └──────────────────────────┘   │
│                         │                                  │
└─────────────────────────┴──────────────────────────────────┘
```

**Success Content:**
- Checkmark icon: ✓ in 80px diameter circle, green (#69a338) background at 10%, green text at 4xl size
- Heading: "Check Your Email" (serif/heading-lg/navyDeep)
- Message: "A verification link has been sent to {email}" (sans/body-sm/textSecondary)
- Email should be the actual email from Step 2 (display in green color for emphasis)
- Button: "Go to Login →" (primary variant, navigates to /login)

### Footer Link

**Persistent across all steps:**
- Position: below form card, centered
- Text: "Already have an account? " (sans/caption/textSecondary) + "Sign in" (blueMid link, underline on hover)
- Gap from card: 24px

### State Preservation

**Wizard state is stored in component state:**
```typescript
const [currentStep, setCurrentStep] = useState(1);
const [formData, setFormData] = useState({
  role: null,
  display_name: "",
  email: "",
  password: "",
  institution_id: null,
  consented: false
});
```

**Back button behavior:**
- Step 2 → Step 1: all Step 1 data preserved (selected role still selected)
- Step 3 → Step 2: all Step 2 data preserved (name, email, password filled in)
- Step 4 → Step 3: all Step 3 data preserved (institution still selected)

**Data persists in memory only** (not localStorage, for security). If user refreshes the page, they start over.

### Responsive Behavior

| Breakpoint | Adjustments |
|------------|-------------|
| Mobile (<640px) | Brand panel stacks on top (compact), form panel below, role cards full-width, institution results full-width |
| Tablet (640-1023px) | Brand panel narrows to 340px, form panel grows |
| Desktop (≥1024px) | Brand panel 480px, form panel flex-1, full layout |

### Accessibility

- Progress indicator uses `role="progressbar"` with `aria-valuenow`, `aria-valuemin`, `aria-valuemax`
- Each step has unique heading (h1) for screen reader navigation
- Form fields have associated labels via `htmlFor`
- Error messages linked to inputs via `aria-describedby`
- Disabled buttons have `aria-disabled="true"`
- Success state announces via `role="status"` + `aria-live="polite"`

---

# PART 4: UPDATED FILE STRUCTURE

## 4.1 New Component Files

```
/src/app
├── /pages
│   ├── Home.tsx                          ← NEW (placeholder)
│   ├── InstitutionApplication.tsx        ← NEW (/apply)
│   ├── /admin
│   │   └── AdminUserDirectory.tsx        ← NEW (/admin/users)
│   └── /auth
│       └── Registration.tsx              ← EXPANDED (4-step wizard)
```

## 4.2 Shared Components Used

**From main design system:**
- `Card`, `CardHeader`, `CardTitle`, `CardContent`, `CardFooter`
- `Button` (all variants)
- `Input`, `LabeledInput`
- `Select`, `SelectTrigger`, `SelectValue`, `SelectContent`, `SelectItem`
- `Alert`, `AlertDescription`
- `Badge`
- `Checkbox`
- `LogoWordmark`
- `SectionMarker`

**New or Extended:**
- `ProgressIndicator` (4-step wizard) — can be extracted to `/components/shared/`
- `DataTable` (admin users) — can be extracted to `/components/organisms/`
- `Pagination` (admin users) — can be extracted to `/components/shared/`

---

# PART 5: DECISION CHECKLIST UPDATES

Add these questions to the main document's checklist:

**For Registration Wizard:**
- [ ] Is this a multi-step flow? → Use progress indicator with numbered circles
- [ ] Does data persist across steps? → Store in component state, clear on unmount
- [ ] Does each step validate independently? → Disable Continue until step is valid

**For Admin Tables:**
- [ ] Does the table need sorting? → Column headers clickable with arrow indicators
- [ ] Does the table need filtering? → Filter bar in white card above table
- [ ] Does the table need pagination? → Parchment footer inside table card

**For Public Forms:**
- [ ] Is this a waitlist/application form? → Template D, white card on cream
- [ ] Does success replace the form? → Full card replacement with checkmark + confirmation
- [ ] Does the form collect PII? → Follow FERPA disclosure pattern from registration

---

# PART 6: TESTING CHECKLIST

## 6.1 Visual Regression Tests

**For each new screen, verify:**
- [ ] The One Rule applied correctly (card/input backgrounds contrast parents)
- [ ] Typography hierarchy matches tokens (serif headings, sans body, mono labels uppercase)
- [ ] Spacing uses 4px base unit throughout
- [ ] Hover states transition smoothly (200-250ms)
- [ ] Focus states show blueMid ring on all interactive elements
- [ ] Loading states use parchment skeleton or button spinner
- [ ] Error states use danger color with clear messaging
- [ ] Success states use green checkmark in circle

## 6.2 Responsive Tests

**Test at each breakpoint:**
- [ ] Mobile (<640px): stacked layouts, full-width cards, simplified tables
- [ ] Tablet (640-1023px): 2-column grids, overlay sidebars, compact tables
- [ ] Desktop (≥1024px): full grids, fixed sidebars, all table columns

## 6.3 Accessibility Tests

**For each new screen:**
- [ ] Keyboard navigation works (Tab, Shift+Tab, Enter, Escape)
- [ ] Screen reader announces all interactive elements
- [ ] Focus visible on all interactive elements
- [ ] Color contrast meets WCAG AA (4.5:1 minimum)
- [ ] Form errors linked to inputs via aria-describedby
- [ ] Loading/success states announced via aria-live

---

# PART 7: IMPLEMENTATION PRIORITY

**Phase 1 (Immediate):**
1. Home.tsx — simplest, no dependencies
2. InstitutionApplication.tsx — public form, no auth required

**Phase 2 (After Auth):**
3. Registration.tsx (expanded) — requires auth API integration

**Phase 3 (After Admin Shell):**
4. AdminUserDirectory.tsx — requires admin role check, user API

---

**End of Addendum**

This addendum is now part of the official Journey OS design system documentation. All specifications herein follow the parent document's reasoning system and design principles. When implemented, these 3 new screens bring the total to **81 screens** with complete design coverage.

Update the main document's screen count from 78 → 81 in the opening summary.
