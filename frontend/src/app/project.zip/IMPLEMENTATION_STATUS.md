# Journey-OS Design System Implementation Status

## COMPLETED (As of now)

### ✓ Core Infrastructure
1. **DashboardComponents.tsx** - Shared organisms library
   - WovenField, AscSquares, Sparkline, ProgressBar, MasteryCell
   - All tokens (C object), fonts (sans/serif/mono)
   - Reusable across all dashboard screens

### ✓ Dashboards (Self-Contained Pattern)
1. **Dashboard.tsx** (Main/Faculty) - Reference implementation
2. **FacultyDashboard.tsx** - Self-contained, imports shared components
3. **StudentDashboard.tsx** - Self-contained, imports shared components  
4. **AdminDashboard.tsx** - NEXT TO COMPLETE

### ✓ Auth Screens
1. **Login.tsx** - Split panel pattern complete

---

## DESIGN METHODOLOGY APPLIED

### The 6 Core Rules (from Reference)
```
1. CREAM BACKGROUND        → Content #f5f3ef, never white
2. ONE BOOKMARK            → Max 1 navyDeep section per page
3. SURFACE HIERARCHY       → cream → white → parchment
4. CONSISTENT CARD ANATOMY → SectionMarker + serif title always
5. TYPE TRIO               → Serif titles, sans body, mono UPPERCASE labels
6. SEMANTIC COLOR REUSE    → green/blue/warning consistent meaning
```

### Component Patterns

#### Dashboard Shell (52 screens use this)
- Sidebar: 240px white, fixed position, borderLight right edge
- Top bar: Sticky, frosted glass (white 95% + blur 12px)
- Content: Cream background, 28-32px padding, maxWidth 1200px
- Cards: White on cream, 12px radius, borderLight edge

#### KPI Strip (The Bookmark)
- Background: navyDeep with WovenField texture
- Position: First element in content, rounded 12px
- Content: AscSquares + greeting + 4 stat cards
- Stat cards: Frosted glass (white 6% opacity + blur)

#### Card Anatomy
```
┌─────────────────────────────────────┐
│ [padding: 20px 24px 16px]          │
│ ● SECTION LABEL (mono uppercase)   │
│ Card Title (serif 18px navyDeep)   │
│                     View all →      │
├─────────────────────────────────────┤
│ [content with borderLight dividers] │
│ Row 1 (parchment on hover)          │
│ ─────────────────────────────────── │
│ Row 2 (parchment on hover)          │
└─────────────────────────────────────┘
```

---

## NEXT ACTIONS (Priority Order)

### IMMEDIATE: Complete AdminDashboard
Update `/src/app/pages/admin/AdminDashboard.tsx` to:
- Remove DashboardLayout wrapper
- Use self-contained pattern like Faculty/Student
- Import from DashboardComponents.tsx
- Admin-specific KPI strip + cards

### PHASE 1: Auth & Onboarding (9 screens, 2 days)
Apply split panel or centered flow pattern:

| Screen | Pattern | Status |
|--------|---------|--------|
| RoleSelection.tsx | Split panel | TODO |
| FacultyRegistration.tsx | Split panel | TODO |
| StudentRegistration.tsx | Split panel | TODO |
| AdminRegistration.tsx | Split panel | TODO |
| ForgotPassword.tsx | Split panel | DONE |
| EmailVerification.tsx | Centered | TODO |
| FacultyOnboarding.tsx | Centered flow | TODO |
| StudentOnboarding.tsx | Centered flow | TODO |
| AdminOnboarding.tsx | Centered flow | TODO |

**Key changes:**
- Cream background for all
- White cards on cream (not white on white)
- Parchment inputs (not white inputs)
- WovenField texture on white panels
- AscendingSquares brand motif
- Next/Back buttons with proper styling

### PHASE 2: High-Traffic Screens (14 screens, 3 days)
Apply dashboard shell pattern:

| Screen | Key Elements | Status |
|--------|--------------|--------|
| AllCourses.tsx | Course grid, filters | TODO |
| CourseDashboard.tsx | Course KPI strip | TODO |
| QuestionReviewList.tsx | Review queue | TODO |
| FacultyReviewQueue.tsx | Question cards | TODO |
| Repository.tsx | Item grid/list | TODO |
| Analytics.tsx | Chart dashboard | TODO |

**Key changes:**
- Use dashboard shell (sidebar + top bar + cream content)
- White cards on cream with SectionMarkers
- Proper hover states (parchment bg on rows)
- Serif titles, mono uppercase labels
- No DashboardLayout wrapper

---

## IMPLEMENTATION CHECKLIST

Before marking ANY screen complete, verify ALL 20 items:

### Surface (5 items)
- [ ] Content background is `C.cream` (#f5f3ef)
- [ ] Cards on cream use `C.white` background
- [ ] Nested elements use `C.parchment` background
- [ ] Inputs use `C.parchment` background
- [ ] Max ONE `C.navyDeep` inverted section

### Typography (5 items)
- [ ] Page titles use `serif` font
- [ ] Card titles use `serif` font  
- [ ] Body text uses `sans` font
- [ ] Labels use `mono` font + UPPERCASE
- [ ] Mono labels have letterSpacing: "0.08em"

### Components (5 items)
- [ ] Every card has SectionMarker (5px dot + mono label)
- [ ] WovenField on navyDeep sections (opacity 0.015)
- [ ] AscendingSquares in KPI strips
- [ ] Responsive (mobile/tablet/desktop)
- [ ] Staggered fadeIn animations

### Interaction (5 items)
- [ ] Card hover: borderLight → blueMid + shadow
- [ ] Button hover: navyDeep → blue
- [ ] Input focus: blueMid border + 3px ring
- [ ] Row hover: parchment background
- [ ] Transitions: 0.15s-0.25s

---

## SHARED COMPONENTS USAGE

### Import Pattern
```tsx
import { 
  C, sans, serif, mono,
  WovenField, AscSquares, Sparkline, 
  ProgressBar, MasteryCell 
} from "../../components/shared/DashboardComponents";
```

### Example: Dashboard Screen
```tsx
export default function MyDashboard() {
  const bp = useBreakpoint();
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => { setMounted(true); }, []);
  
  const fadeIn = (d = 0) => ({
    opacity: mounted ? 1 : 0,
    transform: mounted ? "translateY(0)" : "translateY(8px)",
    transition: `opacity 0.45s ease ${d}s, transform 0.45s ease ${d}s`,
  });

  return (
    <div style={{ fontFamily: sans, minHeight: "100vh", background: C.cream }}>
      {/* Sidebar */}
      {/* Top bar */}
      <main>
        {/* KPI Strip with WovenField + AscSquares */}
        {/* White cards with SectionMarkers */}
      </main>
    </div>
  );
}
```

### Example: Auth Screen
```tsx
// Split panel: white left (brand), cream right (form)
<div style={{ display: "flex", minHeight: "100vh", background: C.cream }}>
  <div style={{ flex: "0 0 480px", background: C.white }}>
    <WovenField color={C.navyDeep} opacity={0.02} />
    <AscSquares colors={[C.navyDeep, C.blue, C.blueMid, C.green]} />
  </div>
  <div style={{ flex: 1 }}>
    <div style={{ background: C.white, borderRadius: 12, padding: 32 }}>
      {/* Form with parchment inputs */}
    </div>
  </div>
</div>
```

---

## SUCCESS CRITERIA

A screen is **PRODUCTION READY** when:

1. ✓ All 20 checklist items verified
2. ✓ Imports from DashboardComponents.tsx (no inline duplicates)
3. ✓ Visual comparison matches reference dashboard quality
4. ✓ Responsive tested (mobile 640px, tablet 1024px, desktop 1200px+)
5. ✓ No inline hex colors (only C.tokenName)
6. ✓ No layout wrapper components for dashboards
7. ✓ Proper semantic HTML (main, header, nav, section)
8. ✓ Accessibility (proper heading hierarchy, alt text, ARIA)

---

## ESTIMATED TIMELINE

- AdminDashboard: 1 hour
- Phase 1 (Auth): 2 days (9 screens)
- Phase 2 (High-traffic): 3 days (14 screens)
- Phase 3 (Remaining): 13 days (58 screens)

**Total: ~18 days for complete design system implementation**

---

## FILES TO UPDATE NEXT

1. `/src/app/pages/admin/AdminDashboard.tsx` - Self-contained pattern
2. `/src/app/pages/auth/RoleSelection.tsx` - Split panel
3. `/src/app/pages/auth/FacultyRegistration.tsx` - Split panel
4. `/src/app/pages/auth/StudentRegistration.tsx` - Split panel
5. `/src/app/pages/auth/AdminRegistration.tsx` - Split panel

After these 5 files, we'll have:
- All dashboards matching reference ✓
- Auth flow complete ✓
- Shared component library established ✓
- Clear pattern for remaining 76 screens ✓
