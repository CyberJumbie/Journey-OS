# Journey-OS Design System Implementation Guide

## 🎯 Quick Start

### The Three-Layer Mental Model

Remember this single rule: **Cards always contrast their parent.**

```
Parent Surface  →  Card Variant  →  Background
──────────────────────────────────────────────
cream           →  default       →  white
white           →  elevated      →  parchment
parchment       →  default       →  white
navyDeep        →  inverted      →  rgba(white, 0.06)
```

### Decision Checklist

Before building any screen, answer these questions:

1. ✓ Which template? (Shell / Split Panel / Full-Width / Focus)
2. ✓ What surface is the content area? (cream / white / parchment)
3. ✓ What card variant? (default / elevated / inverted)
4. ✓ Does it get a bookmark? (one inverted navyDeep strip per page, or none)
5. ✓ Section marker on every card header? (yes)
6. ✓ Title hierarchy? (serif for cards, sans for subheads)
7. ✓ All labels uppercase? (yes, always)

---

## 📦 Component Usage

### Card System (CRITICAL)

```tsx
import { Card, CardHeader, CardTitle, CardContent } from "@/app/components/ui/card";
import { SectionMarker } from "@/app/components/shared/section-marker";

// ✅ CORRECT: White card on cream background (Dashboard)
export function MyDashboard() {
  return (
    <div className="p-6 bg-cream">
      <Card variant="default"> {/* white bg */}
        <CardHeader>
          <SectionMarker label="My Courses" color="navy" />
          <CardTitle>Active Courses</CardTitle>
        </CardHeader>
        <CardContent>
          {/* ... */}
        </CardContent>
      </Card>
    </div>
  );
}

// ✅ CORRECT: Parchment card on white parent
export function NestedPanel() {
  return (
    <Card variant="default"> {/* white card on cream */}
      <CardContent>
        <div className="bg-white p-4"> {/* white inner container */}
          <Card variant="elevated"> {/* parchment card on white */}
            {/* ... */}
          </Card>
        </div>
      </CardContent>
    </Card>
  );
}

// ✅ CORRECT: Inverted card inside bookmark section
export function DashboardWithKPI() {
  return (
    <div className="p-6 bg-cream">
      {/* THE BOOKMARK — one per page */}
      <div className="bg-[--navy-deep] rounded-[--radius-2xl] p-6 mb-6 relative">
        <WovenField color="var(--navy-deep)" opacity={0.02} />
        <div className="relative z-10 grid grid-cols-4 gap-4">
          <StatCard variant="inverted" label="Items" value="342" />
          {/* inverted cards on navyDeep */}
        </div>
      </div>

      {/* Regular cards below */}
      <Card variant="default"> {/* white card on cream */}
        {/* ... */}
      </Card>
    </div>
  );
}

// ❌ WRONG: Parchment card on cream
<Card variant="elevated"> {/* NO! parchment disappears on cream */}

// ❌ WRONG: White card on white
<Card variant="default"> {/* NO! no contrast */}
```

### Shared Molecules

```tsx
import { SectionMarker } from "@/app/components/shared/section-marker";
import { AscendingSquares } from "@/app/components/shared/ascending-squares";
import { WovenField } from "@/app/components/shared/woven-field";
import { LogoWordmark } from "@/app/components/shared/logo-wordmark";
import { StatCard } from "@/app/components/shared/stat-card";
import { ProgressRing } from "@/app/components/shared/progress-ring";
import { ThreadDivider } from "@/app/components/shared/thread-divider";

// Section Marker — every card header
<SectionMarker label="My Courses" color="navy" />
<SectionMarker label="Curriculum" color="green" />

// Logo Wordmark — nav, sidebar, brand panels
<LogoWordmark size="md" />

// Ascending Squares — hero, step progress
<AscendingSquares 
  colors={["var(--navy-deep)", "var(--blue)", "var(--blue-mid)", "var(--green)"]} 
  size={14} 
  gap={4} 
/>

// Woven Field — brand panels, inverted sections
<div className="relative bg-white overflow-hidden">
  <WovenField color="var(--navy-deep)" opacity={0.02} density={16} />
  <div className="relative z-10">{/* content */}</div>
</div>

// Stat Card
<StatCard 
  variant="inverted" // or "light"
  label="Total Items"
  value={342}
  change="+28 this week"
/>

// Progress Ring
<ProgressRing percentage={75} size={40} />
```

### Hooks

```tsx
import { useBreakpoint } from "@/app/hooks/useBreakpoint";
import { useScrollY } from "@/app/hooks/useScrollY";

function MyComponent() {
  const breakpoint = useBreakpoint(); // "mobile" | "tablet" | "desktop"
  const scrollY = useScrollY();

  const isMobile = breakpoint === "mobile";
  const isScrolled = scrollY > 60;

  return (
    <div className={isScrolled ? "opacity-95" : "opacity-100"}>
      {isMobile ? <MobileView /> : <DesktopView />}
    </div>
  );
}
```

---

## 🎨 Design Tokens

### Colors (CSS Variables)

```tsx
// Use CSS variables for all colors
<div style={{ 
  background: "var(--navy-deep)", 
  color: "var(--text-on-inverted)" 
}} />

// Or Tailwind utilities
<div className="bg-[--cream] text-[--ink]" />
<div className="border-[--border-light]" />
<div className="text-[--navy-deep]" />
```

### Common Token Patterns

```css
/* Surfaces */
--cream          /* Page backgrounds */
--parchment      /* Cards on white, inputs */
--white          /* Cards on cream, active tabs */

/* Text */
--ink            /* Primary text, headings */
--text-secondary /* Body copy, descriptions */
--text-muted     /* Captions, labels */
--text-on-inverted         /* White text on navyDeep */
--text-on-inverted-muted   /* Muted text on navyDeep */

/* Borders */
--border-light   /* Card edges, dividers */
--border         /* Input borders */
--border-focus   /* Focus rings (blueMid) */

/* Interactive */
--navy-deep      /* Primary buttons, headings */
--blue           /* Hover states, links */
--blue-mid       /* Focus rings, secondary interactive */
--green          /* Success, faculty persona */
--green-dark     /* Labels, badges, section markers */

/* Semantic */
--success        /* = green */
--warning        /* Caution states */
--danger         /* Errors, critical */
--info           /* = blue-light */
```

### Typography

```tsx
// Use semantic heading elements
<h1>Page Title</h1> {/* serif, 32px, navy-deep */}
<h2>Section Title</h2> {/* serif, 26px, navy-deep */}
<h3>Card Title</h3> {/* sans, 18px, ink */}

// Or explicit classes
<div className="font-serif text-[--font-size-heading-lg] text-[--navy-deep]">
  Card Title
</div>

<p className="text-[--font-size-body-sm] text-[--text-secondary]">
  Body copy
</p>

// Labels MUST be mono + uppercase
<span className="font-mono text-[--font-size-label-md] uppercase tracking-[--letter-spacing-wide] text-[--text-muted]">
  Label Text
</span>
```

### Spacing & Layout

```tsx
// Use design tokens
<div className="p-[--space-6xl]"> {/* 40px */}
<div className="gap-[--space-lg]"> {/* 12px */}

// Or Tailwind equivalents
<div className="p-10 gap-3">
```

### Shadows

```tsx
// Shadows only on hover/focus, never at rest
<Card className="border border-[--border-light] hover:shadow-[--shadow-card]">

// Focus rings
<input className="focus:shadow-[--shadow-focus]" />
```

---

## 🏗️ Templates

### Dashboard Shell (Template A)

```tsx
import DashboardLayout from "@/app/components/layout/DashboardLayout";

export default function MyPage() {
  return (
    <DashboardLayout showSearch={false}>
      <div className="p-6 space-y-6">
        {/* Content on cream background */}
        <Card variant="default"> {/* white cards */}
          {/* ... */}
        </Card>
      </div>
    </DashboardLayout>
  );
}
```

### Split Panel (Template C)

For auth pages, onboarding flows:

```tsx
export default function MyAuthPage() {
  return (
    <div className="flex min-h-screen bg-[--cream]">
      {/* LEFT: Brand Panel (white) */}
      <div className="flex-[0_0_480px] bg-white relative overflow-hidden">
        <WovenField color="var(--navy-deep)" opacity={0.02} />
        <div className="relative z-10 p-12">
          <LogoWordmark size="md" />
          <AscendingSquares 
            colors={["var(--navy-deep)", "var(--blue)", "var(--blue-mid)", "var(--green)"]}
            size={14}
            className="my-6"
          />
          <h1 className="font-serif text-[--font-size-display-md] text-[--navy-deep] mb-4">
            Every thread of your curriculum, woven together.
          </h1>
          <p className="text-[--text-secondary]">
            Subtitle text here
          </p>
        </div>
      </div>

      {/* RIGHT: Form Panel (cream) */}
      <div className="flex-1 flex items-center justify-center p-12">
        <div className="w-full max-w-md">
          <Card variant="default" className="p-8"> {/* white card on cream */}
            {/* Form content */}
          </Card>
        </div>
      </div>
    </div>
  );
}
```

---

## 🚫 Anti-Patterns

### DO NOT

```tsx
// ❌ Pure grays
<div style={{ background: "#f5f5f5" }}> // Use var(--parchment) instead

// ❌ Black text
<div style={{ color: "#000000" }}> // Use var(--ink) instead

// ❌ Arbitrary border radius
<div className="rounded-[15px]"> // Use var(--radius-xl) instead

// ❌ Shadows at rest
<Card className="shadow-md"> // Only on hover!

// ❌ Bold for body emphasis
<p className="font-bold"> // Use color shift to --navy-deep instead

// ❌ Lowercase mono labels
<span className="font-mono">label</span> // ALWAYS uppercase!

// ❌ Wrong card on wrong surface
<div className="bg-cream">
  <Card variant="elevated"> // NO! Parchment on cream has no contrast
</div>

// ❌ Two bookmarks per page
<div className="bg-[--navy-deep]">{/* bookmark 1 */}</div>
<div className="bg-[--navy-deep]">{/* bookmark 2 */}</div>
// Only ONE inverted section per page!

// ❌ Italic headings
<h1 className="italic"> // Serif 700 upright always

// ❌ Colors outside palette
<div style={{ color: "#ff00ff" }}> // Every color must be a token
```

### DO

```tsx
// ✅ Warm neutrals
<div className="bg-[--parchment]">

// ✅ Ink for primary text
<div className="text-[--ink]">

// ✅ Token-based radius
<div className="rounded-[--radius-xl]">

// ✅ Hover shadows only
<Card className="hover:shadow-[--shadow-card]">

// ✅ Color emphasis
<p className="text-[--navy-deep]">

// ✅ Uppercase labels
<span className="font-mono uppercase text-[--text-muted]">LABEL</span>

// ✅ Correct card/surface pairing
<div className="bg-cream">
  <Card variant="default"> {/* white on cream ✓ */}
</div>

// ✅ One bookmark
<div className="bg-[--navy-deep]">{/* THE bookmark */}</div>
{/* regular cards below */}

// ✅ Upright serif headings
<h1 className="font-serif font-bold">

// ✅ Design system colors only
<div className="text-[--navy-deep]">
```

---

## 📋 Component Checklist

When creating a new page/component:

### Every Card Should Have:
- [ ] `<SectionMarker>` at top of header
- [ ] Serif `<CardTitle>` 
- [ ] Correct `variant` prop based on parent surface
- [ ] `border-[--border-light]` by default
- [ ] `hover:border-[--blue-mid] hover:shadow-[--shadow-card]`

### Every Form Should Have:
- [ ] Labels in mono, uppercase
- [ ] Inputs with `bg-[--parchment]` background
- [ ] Focus ring: `focus:border-[--blue-mid] focus:shadow-[--shadow-focus]`
- [ ] Primary button: `bg-[--navy-deep] hover:bg-[--blue]`

### Every Dashboard Should Have:
- [ ] Cream background (`bg-[--cream]`)
- [ ] At most ONE inverted bookmark section
- [ ] White cards (`variant="default"`)
- [ ] Section markers on all cards
- [ ] Responsive grid (1 col mobile → 2/4 cols desktop)

### Every Auth Page Should Have:
- [ ] Split panel layout
- [ ] White brand panel with `<WovenField>`
- [ ] `<LogoWordmark>` and `<AscendingSquares>`
- [ ] Cream form side
- [ ] White card for form (`variant="default"`)

---

## 🎯 Quick Reference

### Most Common Patterns

```tsx
// Standard card on dashboard
<Card variant="default" className="border-[--border-light] hover:border-[--blue-mid] hover:shadow-[--shadow-card]">
  <CardHeader>
    <SectionMarker label="Section" color="navy" />
    <CardTitle>Title</CardTitle>
  </CardHeader>
  <CardContent>
    {/* ... */}
  </CardContent>
</Card>

// Inverted KPI strip (the bookmark)
<div className="bg-[--navy-deep] rounded-[--radius-2xl] p-6 relative">
  <WovenField color="var(--navy-deep)" opacity={0.02} />
  <div className="relative z-10">
    <StatCard variant="inverted" label="KPI" value="123" />
  </div>
</div>

// Input field
<div>
  <label className="font-mono text-[--font-size-label-md] uppercase tracking-wide text-[--text-muted]">
    Email
  </label>
  <input 
    className="w-full bg-[--parchment] border border-[--border] rounded-[--radius-lg] p-3 
               focus:border-[--blue-mid] focus:shadow-[--shadow-focus] transition-all"
  />
</div>

// Primary button
<button className="bg-[--navy-deep] text-white px-6 py-3 rounded-[--radius-md] 
                   hover:bg-[--blue] transition-all font-sans font-semibold">
  Submit
</button>
```

---

## 🔄 Migration Guide

### Updating Existing Components

1. **Find inline color values** → Replace with CSS variables
2. **Find inline components** (WovenField, AscendingSquares) → Import from `/shared/`
3. **Update Card usage** → Add `variant` prop
4. **Add SectionMarkers** → Every card header needs one
5. **Check surface layering** → Verify parent/child contrast
6. **Verify labels** → All mono labels must be uppercase
7. **Check for multiple bookmarks** → Max one inverted section per page

---

This system is now live. All new components should follow these patterns. Existing components should be migrated incrementally following the Priority phases in the main design system spec.
