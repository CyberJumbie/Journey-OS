# Journey OS — Complete Design System Specification
## The Single Source of Truth for All 78 Screens

**Version:** 2.0  
**Last Updated:** February 18, 2026  
**System:** AI-Powered Competency-Based Medical Education Platform  
**Institution:** Morehouse School of Medicine  
**Architecture:** 78 screens · 5 templates · 4 personas · 1 reasoning system  

---

## CRITICAL: Read This First

This document is organized around **mental models that generate the system**, not component catalogs. If you internalize Part 1 (The Reasoning System), you can make correct decisions for any screen—including screens not yet specified.

Every design decision in Journey OS flows from these core principles. No arbitrary choices. No magic numbers. Every color, every spacing value, every surface decision is derived from the foundational reasoning system.

---

# PART 1: THE REASONING SYSTEM

Before any hex values, font sizes, or component specs—internalize these models. They are the DNA from which everything else grows.

---

## 1.1 What This Is

Journey OS is **the substrate**—a knowledge graph operating system with:
- **Neo4j kernel** for graph database
- **Anthropic Claude** for AI generation
- **Supabase** for authentication
- **pgvector** for semantic search
- **75+ node types** and **80+ relationship types**

It serves **four personas** across **78 screens** in **14 functional areas**:
- **Faculty:** Question generation, course management, analytics
- **Students:** Practice, progress tracking, mastery development
- **Advisors:** Student guidance, curriculum oversight
- **Administrators:** System configuration, compliance, data integrity

The UI is a set of persona experiences sitting on top of that graph. Every design decision reflects this depth without exposing technical complexity.

**Visual Identity Foundation:**
- Based on **MSM Brand Identity Style Guide**, Education Pillar palette
- **"Woven Tapestry" concept** from MSM's 2022 Annual Report
- Geometric squares representing four pillars (Education, Research, Clinical, Community) in ascending orientation
- This is the DNA of every visual element

---

## 1.2 Three Sheets of Paper

**The entire UI is built on three warm surfaces.** Think of a desk with sheets of paper on it:

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   CREAM (#f5f3ef) — the desk                                │
│   The largest surface. Page backgrounds. Dashboard content  │
│   areas. The warm tone visible between and behind cards.    │
│   Section alternation fill on landing pages.                │
│                                                             │
│     ┌─────────────────────────────────────────────────┐     │
│     │                                                   │     │
│     │   WHITE (#ffffff) — a sheet of paper on the desk  │     │
│     │   Cards on cream backgrounds. Primary reading     │     │
│     │   surfaces. Active tabs. Modal bodies. Question   │     │
│     │   stems. The content you focus on.                │     │
│     │                                                   │     │
│     │     ┌─────────────────────────────────────┐       │     │
│     │     │                                       │       │     │
│     │     │   PARCHMENT (#faf9f6) — a note on      │       │     │
│     │     │   the sheet                              │       │     │
│     │     │   Nested elements inside white cards.    │       │     │
│     │     │   Inputs. Table headers. Form panels.    │       │     │
│     │     │   Sidebar active items. Row hovers.      │       │     │
│     │     │                                       │       │     │
│     │     └─────────────────────────────────────┘       │     │
│     │                                                   │     │
│     └─────────────────────────────────────────────────┘     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Key Principle:** The outermost layer has the largest surface area on screen. The innermost is the smallest. This matches what you see: cream fills the page, white cards sit on top, parchment elements nest inside those cards.

**No Pure Grays:** There are no pure grays anywhere. `#f5f5f5`, `#e5e5e5`, `#999` are **forbidden**. Every neutral has a yellow-warm undertone pulled from MSM's Pantone 7527c (→ warmGray `#d7d3c8`). This keeps the interface human and textured, not sterile.

---

## 1.3 The One Rule

**Cards always contrast their parent surface.**

This single rule governs every surface decision in all 78 screens:

```
Parent Surface    →    Child Surface    →    Grandchild Surface
─────────────────────────────────────────────────────────────────
cream                  white                 parchment
white                  parchment             white
parchment              white                 —
navyDeep (inverted)    text only             —
```

**If you know what surface you're on, you know what color every child element should be. No exceptions.**

### Applied Everywhere

✓ **Card on cream** → ALWAYS white bg  
✓ **Input inside white card** → parchment bg (most common case)  
✓ **Input inside parchment panel** → white bg (The One Rule applies to inputs too)  
✓ **Nested panel inside parchment card** → ALWAYS white bg  
✓ **Table header row inside white card** → ALWAYS parchment bg  
✓ **Row hover inside white table** → ALWAYS parchment bg  

### Violations Are Bugs

✗ Card on cream with parchment bg → **BUG**  
✗ Input on white card with white bg → **BUG**  
✗ Input on parchment panel with parchment bg → **BUG** (should be white)  
✗ Nested card same color as parent → **BUG**  

### Why This Matters Most

If this rule breaks, the interface goes flat. Cards don't lift. Content lacks visual grouping. The system feels assembled from parts instead of grown from a shared root. **This one rule is responsible for more visual quality than any other decision.**

### The One Rule Applied: Login Page

Every surface annotated—source of truth for Template C (Split Panel):

```
┌─────────────────────────┬──────────────────────────────────────────────┐
│                         │                                              │
│   BRAND PANEL           │  Form panel background: cream (#f5f3ef)      │
│   white bg (#ffffff)    │  Optional: WovenField at 0.015 opacity       │
│   WovenField texture    │                                              │
│   (navyDeep, 0.02)      │    ┌──────────────────────────┐              │
│                         │    │ Login card: white         │  ← card on  │
│   Logo (serif+mono)     │    │ border: 1px borderLight   │    cream =  │
│   Ascending squares     │    │ border-radius: 12px       │    white    │
│   Headline (serif)      │    │ padding: 32px             │             │
│   Subtitle (sans)       │    │ box-shadow: panel         │             │
│                         │    │                           │             │
│   Pillar grid (bottom)  │    │ Input bg: parchment       │  ← input   │
│   ThreadDivider         │    │ Input border: border      │    inside   │
│   Institution (mono)    │    │ Input focus: blueMid      │    white =  │
│                         │    │                           │    parchment│
│   1px borderLight →     │    │ Button bg: navyDeep       │             │
│                         │    │ Button hover: blue        │             │
│                         │    │                           │             │
│                         │    │ Tab strip: parchment bg   │  ← nested  │
│                         │    │   Active tab: white bg    │    element  │
│                         │    │                           │    on white │
│                         │    └──────────────────────────┘              │
└─────────────────────────┴──────────────────────────────────────────────┘
```

---

## 1.4 Navy as a Surface: Two Scales

Navy (`navyDeep` #002c76) is the system's highest-contrast surface color. It appears at **two distinct scales**, each with different rules.

### Scale 1: The Bookmark (one per page)

**One full-width or near-full-width `navyDeep` inverted section per page.** The KPI strip on dashboards. The stats bar on the landing page. The command bar on admin screens. The score summary on student results. This is the "bookmark between pages of a book"—a single large moment of visual weight that anchors the eye and establishes page context.

**Bookmark Rules:**
- Never more than one bookmark per page
- Always contains the most important contextual information (KPIs, greeting, progress, score)
- Gets `border-radius: 12px` when inside content padding, `0` when full-bleed
- Always gets WovenField canvas texture (white threads at 0.015 opacity on navy)
- Text is white. Muted text is `bluePale` (#a3d9ff)
- Stat cards inside use frosted glass: `rgba(255,255,255,0.06)` bg, `rgba(255,255,255,0.08)` border, `backdrop-filter: blur(4px)`

**Why One Bookmark:** Navy on cream is the strongest contrast available. If there were two full-width navy sections, they'd compete for attention and neither would anchor anything. One creates a focal point. Multiple create noise. The bookmark is the spine of the page—there's only one.

### Scale 2: Navy Accents (unlimited within cards)

Navy also appears as accent elements **inside** the warm surface hierarchy. These are small, contained uses that add weight and brand presence without competing with the bookmark. They are part of the 70% True Blues budget and appear on every screen.

**Navy Accent Patterns (all permitted, use freely):**

| Element | Treatment | Where Used |
|---------|-----------|------------|
| Accent bar (left/top) | 3-4px solid navyDeep | Priority cards, selected rows, featured items, active states |
| Tinted background | navyDeep at 5-8% opacity | Badges (navyDeep/8%), activity feed icons, week badges, stat highlights, tag chips |
| Filled small elements | solid navyDeep bg, white text | Buttons, checkboxes, toggles, avatars (square), chat bubbles, persona tab active states, step indicators (active) |
| Card header accent | navyDeep/5% bg on header row OR 2px navyDeep bottom border | Featured/pinned cards, alert cards, "new" content markers |
| Stat value highlight | navyDeep bg, white text, radius md, padding 4px 10px | Inline stat callouts inside white cards (small, contained) |
| Section marker dots | 5px solid navyDeep square | Every card header (structural) |
| Text color | navyDeep for headings, navyDeep for emphasis | All serif headings, all card titles, link hover states |

**The Distinction:** A bookmark is a *section*—it spans the full content width, has its own internal layout (greeting, stat grid, woven texture), and serves as the page's primary anchor. Navy accents are *elements*—they sit inside cards, inside rows, inside components. They add weight and brand presence at the card level.

**What This Means in Practice:** A Faculty Dashboard has one navy KPI strip (the bookmark) AND navy accent bars on priority task cards, navy tinted badges on course rows, navy checkboxes, navy buttons, navy section marker dots, and navy stat highlights inside white cards. The page reads as blue-dominant because navy is *everywhere at the element level*, but there's still only one large inverted section anchoring the top.

---

## 1.5 The 70/30 Split

The overall system palette is approximately **70% True Blues** (navy, blue, blueMid—structure, headings, buttons, inverted sections) and **30% Evergreens** (greenDark, green—badges, labels, success states, accents). This ratio comes from the MSM brand guide's Education Pillar specification.

**How This Manifests:**
- Blues dominate structure on every screen—navyDeep headings, primary buttons, inverted bookmarks, links
- Green appears as punctuation: section marker dots on curriculum cards, success badges, coverage ring fills, progress bars, the "OS" logo badge
- On brand-heavy screens (landing page, onboarding) the 70/30 is visible
- On structural screens (settings, data tables, review lists) the ratio skews more like 85/15

**Key Constraint:** Green is never used for primary navigation, page headings, or buttons (except the one-off "Approve" button which uses green bg as a semantic override). Green accents. Blue structures.

---

## 1.6 The Type Trio

Three font families with non-negotiable roles:

| Family | Web Font | Role |
|--------|----------|------|
| **Lora (serif)** | Google Fonts, maps to MSM's Heuristica | Display moments. Headings. Titles. Hero text. Card titles. The eye-catching font. Used for the most prominent text on any screen. |
| **Source Sans 3 (sans)** | Google Fonts, maps to MSM's Myriad Variable | Everything else. Body copy. Buttons. Navigation. Descriptions. Form text. The workhorse. |
| **DM Mono (mono)** | Google Fonts | Structural annotations. Labels. Badges. Timestamps. Field labels. Data values. **ALWAYS uppercase. ALWAYS letter-spaced. ALWAYS small.** |

**The Absolute Rule:** Mono text that isn't uppercase = bug. Heading that isn't serif = wrong (unless card subtitle → sans/700). Label in sans-serif = should be mono.

The trio creates three distinct textures: serif pulls the eye (I'm important), sans recedes (read me), mono signals structure (I'm metadata).

---

## 1.7 The Section Marker

The single most repeated pattern in the system. Every card header, every section opener, every panel:

```
● MY COURSES                    ← 5px dot + mono/label-md/uppercase/textMuted
Active Courses                  ← serif/heading-lg/navyDeep
Optional description            ← sans/body-sm/textSecondary
```

Dot color = category:
- `navyDeep` for structural (courses, tasks, questions)
- `greenDark` for curriculum/education (mastery, coverage, outcomes)

This heartbeat pattern means the eye learns to parse cards instantly.

---

## 1.8 The Surface Rhythm

On the landing page and any long-scroll page, surfaces alternate A-B-A-B:

```
white → cream → white → cream (with one navyDeep bookmark breaking the pattern)
```

**Never stack two same-colored sections** without a visual break (1px borderLight, inverted strip, or surface change).

---

## 1.9 Anti-Patterns

Everything this system explicitly forbids:

| ✗ Forbidden | → Use Instead |
|-------------|---------------|
| Pure grays (#f5f5f5, #e5e5e5, #999) | Warm neutrals only |
| Black text (#000000) | Darkest is ink (#1b232a) |
| Black buttons or backgrounds | navyDeep (#002c76) instead |
| Yellow/orange as primary accent | Education Pillar uses navy + green |
| Shadows at rest on grid cards | Border only; shadow on hover only (exception: login card, modals, mobile sidebar) |
| Arbitrary border-radius | Only 3, 6, 8, 10, 12px |
| Colors outside the palette | Every color is a token |
| Bold for emphasis in body copy | navyDeep color shift instead |
| Emoji as icons | SVG or serif symbols (◈ ◆ ◇ ▣ ▢ ✦) |
| Inter, Arial, Roboto, Geist | Source Sans 3 is the system sans |
| Two same-surface sections adjacent | Alternate or break with inverted |
| More than one inverted SECTION per page | One bookmark strip only (navy accents inside cards are unlimited and encouraged) |
| Card on cream with parchment bg | Cards on cream are ALWAYS white |
| Input same bg as parent surface | Inputs contrast parent (parchment on white, white on parchment) |
| Lowercase mono labels | ALWAYS uppercase |
| Italic headings | Serif 700 upright always |
| Generic "Loading..." bare text | Skeleton or spinner |
| Circle avatars | Squares (the system shape) |

---

# PART 2: DESIGN TOKENS

Every value is a token. No raw hex, no magic numbers.

## 2.1 Colors

```css
:root {
  /* ── TRUE BLUES (70% of composition) ───────────────── */
  --navy-deep: #002c76;     /* Headlines, CTAs, inverted sections, primary buttons */
  --navy: #003265;          /* Deep accents, sidebar active text */
  --blue: #004ebc;          /* Hover on navyDeep, interactive emphasis */
  --blue-mid: #2b71b9;      /* Focus rings, links, secondary interactive */
  --blue-light: #00a8e1;    /* Advisor persona, info states */
  --blue-pale: #a3d9ff;     /* Text-on-inverted muted, sparklines */

  /* ── EVERGREENS (30% of composition) ───────────────── */
  --green-dark: #5d7203;    /* Labels, badges, OS tag, section markers on cream */
  --green: #69a338;         /* Success states, faculty persona, progress fills */
  --lime: #d8d812;          /* Reserved — MSM brand, not yet used in UI */

  /* ── SURFACES (warm neutrals — no pure grays) ──────── */
  --white: #ffffff;         /* Layer 3: primary reading, active tabs, content */
  --parchment: #faf9f6;     /* Layer 2: cards on white, inputs, form panels */
  --cream: #f5f3ef;         /* Layer 1: page bg, dashboard content area */
  --warm-gray: #d7d3c8;     /* Decorative: thread dividers, subtle borders */

  /* ── BORDERS ───────────────────────────────────────── */
  --border-light: #edeae4;  /* Structural: section dividers, card edges */
  --border: #e2dfd8;        /* Interactive: input borders, hover targets */

  /* ── TEXT ───────────────────────────────────────────── */
  --ink: #1b232a;           /* Body copy, headings (= textPrimary) */
  --text-secondary: #4a5568;/* Descriptions, card body text */
  --text-muted: #718096;    /* Labels, captions, placeholders, timestamps */
  --text-on-inverted: #ffffff;
  --text-on-inverted-muted: #a3d9ff;

  /* ── SEMANTIC ──────────────────────────────────────── */
  --success: #69a338;       /* = green */
  --warning: #fa9d33;       /* MSM Bright Earth */
  --danger: #c9282d;        /* MSM Bright Earth */
  --info: #00a8e1;          /* = blueLight */
}
```

**Persona Identifiers** (tab strips, color bars, indicators):
- Faculty: `navyDeep` #002c76
- Admin: `blueMid` #2b71b9
- Advisor: `blueLight` #00a8e1
- Student: `green` #69a338

---

## 2.2 Typography

### Type Scale

| Token | Font | Wt | Size | Lead | Track | Usage |
|-------|------|-----|------|------|-------|-------|
| display-xl | serif | 700 | 54/38/30px* | 1.18 | -0.015em | Landing hero H1 |
| display-lg | serif | 700 | 34px | 1.25 | -0.015em | Section H2 (major) |
| display-md | serif | 700 | 30-32px | 1.25 | -0.01em | Section H2 (standard) |
| display-sm | serif | 700 | 24-26px | 1.25 | -0.01em | Mobile H2, sub-headers |
| heading-lg | serif | 700 | 22px | 1.3 | -0.01em | Card titles, page headings |
| heading-md | sans | 700 | 16px | 1.35 | 0 | Card subtitles, nav items |
| heading-sm | sans | 700 | 15px | 1.35 | 0 | Step titles, row titles |
| body-lg | sans | 400 | 18px | 1.8 | 0 | Hero subtitle, lead text |
| body-md | sans | 400 | 16px | 1.75 | 0 | Body copy, descriptions |
| body-sm | sans | 400 | 15px | 1.7 | 0 | Card body, table cells |
| body-xs | sans | 400 | 14px | 1.65 | 0 | Detail text, metadata |
| caption | sans | 400 | 13px | 1.5 | 0 | Links, help text, fine print |
| label-lg | mono | 500 | 11px | 1 | 0.1em | Section markers (with dot) |
| label-md | mono | 500 | 10px | 1 | 0.08em | Field labels, timestamps |
| label-sm | mono | 500 | 9px | 1 | 0.08em | Badge text, tags, indicators |
| label-xs | mono | 400 | 8px | 1 | 0.08em | Pillar square labels |

*display-xl is responsive: 54px desktop / 38px tablet / 30px mobile

---

## 2.3 Spacing (4px base unit)

| Token | Value | CSS Var | Tailwind | Usage |
|-------|-------|---------|----------|-------|
| xs | 4px | --space-xs | gap-1 | Icon gaps, tight grouping |
| sm | 6px | --space-sm | gap-1.5 | Grid gaps, badge padding |
| md | 8px | --space-md | gap-2 | Logo gap, inline grouping |
| lg | 12px | --space-lg | gap-3 | Card gaps (mobile) |
| xl | 16px | --space-xl | gap-4 p-4 | Card padding (mobile), connectors |
| 2xl | 20px | --space-2xl | gap-5 p-5 | Card padding, field spacing |
| 3xl | 24px | --space-3xl | gap-6 p-6 | Card padding (large), nav height |
| 4xl | 28px | --space-4xl | gap-7 p-7 | Wrap horizontal padding |
| 5xl | 32px | --space-5xl | gap-8 p-8 | Form padding, section intros |
| 6xl | 40px | --space-6xl | gap-10 | Section group spacing |
| 7xl | 48px | --space-7xl | gap-12 | Section header-to-content (desktop) |
| 8xl | 56px | --space-8xl | py-14 | Stats section padding |
| 9xl | 64px | --space-9xl | py-16 | Section padding (mobile) |
| 10xl | 90px | --space-10xl | py-[90px] | Section padding (desktop) |

**Container:** `max-width: 1120px`, centered, `padding: 0 28px` (desktop) / `0 18px` (mobile).

---

## 2.4 Borders & Radii

```css
:root {
  --radius-sm: 3px;    /* Logo OS badge, small tags, badge pills */
  --radius-md: 6px;    /* Buttons, tabs, step indicators, nav items */
  --radius-lg: 8px;    /* Cards (small), inputs, pillar squares */
  --radius-xl: 10px;   /* Feature cards, benefit cards */
  --radius-2xl: 12px;  /* Dashboard cards, form panels, modals, KPI strip */
}
```

Five values only. No arbitrary radii.

---

## 2.5 Shadows

Shadows are accent, not structure. Elevation comes from surface color contrast. Shadow color is ALWAYS derived from `navyDeep rgba(0,44,118,...)`, never black.

```css
:root {
  --shadow-subtle: 0 1px 3px rgba(0,0,0,0.04);           /* Active tab chip */
  --shadow-card: 0 4px 16px rgba(0,44,118,0.05);          /* Card hover */
  --shadow-lifted: 0 4px 20px rgba(0,44,118,0.06);        /* Feature card hover */
  --shadow-panel: 0 8px 32px rgba(0,44,118,0.04);         /* Login form, modals */
  --shadow-focus: 0 0 0 3px rgba(43,113,185,0.08);        /* Input focus ring */
  --shadow-sidebar: 4px 0 24px rgba(0,44,118,0.06);       /* Mobile sidebar */
}
```

**RULE: No shadows at rest** for standard cards. Cards in dashboard grids, review lists, and data tables have `border: 1px solid var(--border-light)` and zero shadow. Shadow appears ONLY on hover or focus.

**Exceptions—shadow at rest:** A small set of elements float as the sole focal point on their surface:
- Login form card (the only element on the cream form panel)
- Modal panels (floating over a backdrop)
- Mobile sidebar overlay (sliding over content)

---

## 2.6 Transitions

```css
:root {
  --transition-fast: 150ms ease;     /* Checkbox, icon swap, row highlight */
  --transition-default: 200ms ease;  /* Border, color, background shifts */
  --transition-medium: 250ms ease;   /* Card hover states */
  --transition-slow: 300ms ease;     /* Nav scroll, sidebar slide */
  --transition-reveal: 500ms ease;   /* Scroll-triggered fade-in (landing) */
}
```

Stagger: 60-100ms per item for sequential reveals.

---

## 2.7 Z-Index

```css
:root {
  --z-base: 0;
  --z-card: 1;
  --z-card-hover: 10;
  --z-sidebar: 40;
  --z-sticky: 50;
  --z-sheet: 70;
  --z-dialog: 80;
  --z-dropdown: 90;
  --z-tooltip: 100;
}
```

---

# PART 3: TEMPLATES

All 78 screens use one of five templates. Every template specifies its surface color, sidebar behavior, and bookmark placement.

## 3.1 Template A: Dashboard Shell (52 screens)

```
┌──────────┬────────────────────────────────────────────────────┐
│          │  TOP BAR (frosted glass, sticky)                   │
│  SIDE    │  white/F2 + blur 12px, 1px borderLight bottom      │
│  BAR     ├────────────────────────────────────────────────────┤
│          │  CONTENT AREA — cream (#f5f3ef) bg                 │
│  white   │  padding: 28px 32px desktop / 24px tablet / 20px   │
│  bg      │  max-width: 1200px (left-aligned from sidebar)     │
│  240px   │                                                    │
│  fixed   │    ┌═══ BOOKMARK (navyDeep) ══════════════════┐   │
│  border  │    ║ KPI strip, woven texture, frosted cards   ║   │
│  Right   │    ║ ONE per page — anchors the eye             ║   │
│          │    └═══════════════════════════════════════════┘   │
│          │                                                    │
│          │    ┌─ White Card ──────┐  ┌─ White Card ──────┐   │
│          │    │ borderLight        │  │ nested = parchment │   │
│          │    │ nested = parchment │  │ table header = p   │   │
│          │    └────────────────────┘  └────────────────────┘   │
└──────────┴────────────────────────────────────────────────────┘
```

**Used by:** All dashboards, course management, question review, analytics, settings

---

## 3.2 Template B: Admin Shell (12 screens)

Identical to Template A but:
- Admin-specific sidebar nav
- Active item: `greenDark` left border instead of parchment bg (distinguishes admin from faculty)

**Used by:** All admin backend screens

---

## 3.3 Template C: Split Panel (9 auth screens)

```
┌─────────────────────────┬──────────────────────────────────┐
│   BRAND PANEL           │       FORM PANEL                 │
│   white bg              │       cream bg                   │
│   WovenField texture    │       centered content           │
│   flex: 0 0 480px       │       flex: 1                    │
│                         │       max-width: 400px form      │
│   Logo, squares         │                                  │
│   Headline, subtitle    │       Form card (white bg,       │
│   Pillar grid           │       panel shadow, radius 2xl)  │
│   Thread divider        │       OR direct form elements    │
│   Institution name      │                                  │
│   1px borderLight right │                                  │
└────���────────────────────┴──────────────────────────────────┘
```

**Responsive:**
- Tablet: left panel → 340px
- Mobile: stacks vertically, brand panel compact

**Used by:** Login, registration, forgot password, email verification

---

## 3.4 Template D: Full-Width Flow (5 screens)

No sidebar. Optional minimal top bar (logo + back link only). Centered content, max-width varies (600-800px forms, 1120px reviews). Background: white or gradient. Can use section rhythm (white/cream/inverted alternation).

**Used by:** Landing page, onboarding flows, CourseReady celebration

---

## 3.5 Template E: Focus Mode (11 screens)

```
┌──────────┬──────────────────────────────┬─────────────────┐
│  SIDE    │  PRIMARY PANEL               │  CONTEXT PANEL  │
│  BAR     │  white bg, full height       │  parchment bg   │
│  (thin)  │  question content, editor    │  metadata, chat │
│          │  graph visualization         │  history, notes │
│          │                              │  300-360px      │
└──────────┴──────────────────────────────┴─────────────────┘
```

**The One Rule on split surfaces:** Focus Mode creates two adjacent panels with different backgrounds. The One Rule applies independently to each:

**PRIMARY PANEL (white bg):**
- Cards/sections → elevated (parchment) bg
- Inputs inside parchment cards → white bg (parchment parent → white child)
- Table headers → parchment

**CONTEXT PANEL (parchment bg):**
- Cards/sections → white bg (default variant)
- Inputs inside white cards → parchment bg (white parent → parchment child)
- Chat bubbles: AI messages → white bg, User messages → navyDeep bg (inverted)

**Responsive:**
- Mobile: context → bottom drawer or tab
- Tablet: context → slide-in sheet from right
- Desktop: full three-column

**Used by:** Question detail, AI refinement, syllabus editor, knowledge browser, exam assembly

---

# PART 4: 78-SCREEN INVENTORY

## 4.1 Screen-to-Template Mapping

### A. PUBLIC & AUTH (9 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| Landing.tsx | Template D | Stats bar |
| Login.tsx | Template C | None |
| RoleSelection.tsx | Template C | None |
| Registration.tsx | Template C | None |
| StudentRegistration.tsx | Template C | None |
| FacultyRegistration.tsx | Template C | None |
| AdminRegistration.tsx | Template C | None |
| ForgotPassword.tsx | Template C | None |
| EmailVerification.tsx | Template C | None |

### B. ONBOARDING (4 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| Onboarding.tsx | Template D | None |
| StudentOnboarding.tsx | Template D | None |
| FacultyOnboarding.tsx | Template D | None |
| AdminOnboarding.tsx | Template D | None |

### C. DASHBOARDS (3 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| Dashboard.tsx | Template A | Router |
| FacultyDashboard.tsx | Template A | KPI strip |
| StudentDashboard.tsx | Template A | Progress strip |

### D. STUDENT LEARNING (5 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| StudentPractice.tsx | Template A | None |
| StudentQuestionView.tsx | Template E | None |
| StudentResults.tsx | Template A | Score strip |
| StudentProgress.tsx | Template A | Streak bar |
| StudentAnalytics.tsx | Template A | KPI strip |

### E. COURSE MANAGEMENT (14 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| AllCourses.tsx | Template A | None |
| CreateCourse.tsx | Template A | None |
| UploadSyllabus.tsx | Template A | None |
| SyllabusProcessing.tsx | Template A | Progress bar |
| SyllabusEditor.tsx | Template E | None |
| ReviewSyllabusMapping.tsx | Template E | None |
| CourseDashboard.tsx | Template A | Course KPIs |
| CourseReady.tsx | Template D | Celebration |
| WeekView.tsx | Template A | None |
| WeekMaterialsUpload.tsx | Template A | None |
| LectureUpload.tsx | Template A | None |
| LectureProcessing.tsx | Template A | Progress bar |
| SubConceptReviewQueue.tsx | Template A | None |
| OutcomeMapping.tsx | Template E | None |

### F. QUESTION GENERATION (7 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| GenerationSpecWizard.tsx | Template A | Step bar |
| GenQuestionsSyllabus.tsx | Template A | None |
| GenQuestionsTopic.tsx | Template A | None |
| GenerateTest.tsx | Template A | Blueprint strip |
| GenerateQuiz.tsx | Template A | None |
| GenerateHandout.tsx | Template A | None |
| BatchProgress.tsx | Template A | Progress strip |

### G. QUESTION REVIEW (7 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| QuestionReviewList.tsx | Template A | None |
| FacultyReviewQueue.tsx | Template A | Queue count |
| ItemDetail.tsx | Template E | None |
| QuestionDetailView.tsx | Template E | None |
| AIRefinement.tsx | Template E | None |
| ConversationalRefine.tsx | Template E | None |
| QuestionHistory.tsx | Template A | None |

### H. REPOSITORY (2 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| Repository.tsx | Template A | Repo stats |
| ItemBankBrowser.tsx | Template A | None |

### I. EXAM MANAGEMENT (3 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| ExamAssembly.tsx | Template E | Blueprint strip |
| ExamAssignment.tsx | Template A | None |
| RetiredExamUpload.tsx | Template A | None |

### J. UPLOADS & OPS (2 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| FacultyQuestionUpload.tsx | Template A | None |
| BulkOperations.tsx | Template A | Queue count |

### K. ANALYTICS (4 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| Analytics.tsx | Template A | KPI strip |
| CourseAnalytics.tsx | Template A | Course KPIs |
| PersonalDashboard.tsx | Template A | Teaching KPIs |
| BlueprintCoverage.tsx | Template A | Coverage % |

### L. ADMIN BACKEND (12 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| AdminDashboard.tsx | Template B | System KPIs |
| SetupWizard.tsx | Template B | Step bar |
| FrameworkManagement.tsx | Template B | None |
| FacultyManagement.tsx | Template B | None |
| KnowledgeBrowser.tsx | Template E* | None |
| SubConceptDetail.tsx | Template E* | None |
| ILOManagement.tsx | Template B | None |
| DataIntegrityDash.tsx | Template B | Health strip |
| FULFILLSReviewQueue.tsx | Template B | None |
| LCMEComplianceHeatmap.tsx | Template B | Compliance % |
| LCMEElementDrillDown.tsx | Template B | None |

*Focus template nested inside admin shell

### M. SETTINGS & SUPPORT (6 screens)
| Screen | Template | Bookmark |
|--------|----------|----------|
| Profile.tsx | Template A | None |
| Settings.tsx | Template A | None |
| Notifications.tsx | Template A | None |
| Help.tsx | Template A | None |
| Collaborators.tsx | Template A | None |
| QuestionTemplates.tsx | Template A | None |

### N. ERROR (1 screen)
| Screen | Template | Bookmark |
|--------|----------|----------|
| NotFound.tsx | Template D | None |

---

# PART 5: COMPONENT SPECIFICATIONS

## 5.1 Section Marker (NEW)

```tsx
export function SectionMarker({ label, color = "navy" }) {
  const dotColor = color === "green" ? "var(--green-dark)" : "var(--navy-deep)";
  return (
    <div className="flex items-center gap-2">
      <div className="w-[5px] h-[5px] rounded-[1px]" style={{ background: dotColor }} />
      <span className="font-mono text-label-md uppercase text-muted">{label}</span>
    </div>
  );
}
```

**Usage:** Every card header, every section opener, every panel

---

## 5.2 Card Variants

```tsx
<Card>                         // white bg — use when parent is cream
<Card variant="elevated">      // parchment bg — use when parent is white
<Card variant="inverted">      // rgba(w,0.06) bg — use inside navyDeep sections
```

**Surface Mapping:**
| Variant | BG | Border | Child Element BG |
|---------|-----|--------|------------------|
| default | white | 1px borderLight | parchment (inputs, nested panels, headers) |
| elevated | parchment | 1px borderLight | white (inputs, nested panels) |
| inverted | rgba(w,0.06) | 1px rgba(w,0.08) | rgba(w,0.1) |

All cards: `border-radius: 2xl (12px)`. Padding: `20px 24px` desktop / `16px` mobile.
Hover: `border → blueMid`, `box-shadow: card-hover`. Transition: `medium (250ms)`.

---

## 5.3 Woven Field (Canvas Texture)

```tsx
function WovenField({ color = C.navyDeep, opacity = 0.015, density = 10 }) {
  // Canvas-drawn woven thread pattern
  // position: absolute, inset: 0, pointer-events: none
}
```

**Specific Usages:**
- Hero: navyDeep threads, 0.025 opacity, density 22 (12 mobile)
- What It Does: greenDark threads, 0.015 opacity, density 24 (10 mobile)
- Benefits: navyDeep threads, 0.012 opacity, density 20 (10 mobile)
- Waitlist: navyDeep threads, 0.015 opacity, density 16 (10 mobile)
- KPI Strips: white threads, 0.015 opacity, density 10

---

## 5.4 Ascending Squares (Brand Element)

```tsx
function AscendingSquares({ colors, size = 8, gap = 3 }) {
  // 4 squares in pillar colors, ascending left-to-right
  // Each offset upward by size × 0.2px
}
```

**Props:**
- colors: education pillar blues + green
- size: 8-12px (decorative), 14px (functional), 28-32px (hero)
- gap: spacing between squares

**Usage:** hero decoration, step progress, section openers, brand panels, login

---

## 5.5 Logo Wordmark

```tsx
function LogoWordmark({ size = "md", variant = "default" }) {
  // "Journey" serif + "OS" mono badge
  // Always live text + CSS, never an image
}
```

**Variants:**
- default: navy + green
- white: knockout for dark bg
- mono: all navy

**Sizes:**
- xs (16px), sm (19px), md (22px), lg (30px), xl (40px)

---

# PART 6: RESPONSIVE STRATEGY

| Breakpoint | Range | Sidebar | Grid | Padding |
|------------|-------|---------|------|---------|
| mobile | < 640px | overlay | 1 col | 16-20px |
| tablet | 640-1023px | overlay | 2 col | 24px |
| desktop | ≥ 1024px | fixed 240px | 2-4 col | 28-32px |

**Hook:** `useBreakpoint()` → `"mobile" | "tablet" | "desktop"`

### Per-template Responsive Behavior

**Dashboard Shell:**
- Mobile: no sidebar, hamburger, 1-col
- Tablet: overlay sidebar, 2-col
- Desktop: fixed sidebar, full grids

**Split Panel:**
- Mobile: stacked (brand compact, no pillar grid)
- Tablet: narrow left (340px)
- Desktop: full left (480px)

**Focus Mode:**
- Mobile: context → bottom drawer
- Tablet: context → slide-in sheet
- Desktop: three-column

---

# PART 7: DECISION CHECKLIST

Before building or modifying any screen, answer:

- [ ] **Which template?** → A (shell), B (admin), C (split), D (full-width), E (focus)
- [ ] **Content area surface?** → cream (shell), cream (split right), white (focus primary), parchment (focus context)
- [ ] **Card variant?** → white (on cream) or elevated/parchment (on white)
- [ ] **Input backgrounds?** → contrast parent: parchment inside white cards, white inside parchment panels
- [ ] **Does it get a bookmark?** → one inverted navyDeep strip per page, or none (navy accents inside cards are separate—always allowed)
- [ ] **Section marker?** → dot + mono label on every card header
- [ ] **Title hierarchy?** → serif for page/card titles, sans for everything else
- [ ] **Label treatment?** → mono, uppercase, letterSpacing 0.08-0.1em, always
- [ ] **If Focus Mode: which panel holds what?** → each panel is an independent surface context; The One Rule applies to each separately
- [ ] **Responsive?** → define for mobile, tablet, desktop
- [ ] **Loading state?** → skeleton (parchment pulse) for cards, spinner for buttons
- [ ] **Hover treatment?** → border blueMid + shadow on cards, parchment bg on rows

---

# PART 8: BRAND INTEGRATION

The MSM "Woven Tapestry" manifests three ways:

1. **Woven Field** — canvas texture on brand panels and inverted sections
2. **Thread Divider** — sinusoidal SVG between sections
3. **Ascending Squares** — 4 squares in pillar colors (Education, Research, Clinical, Community)

**Logo Placement:** sidebar top (Shell), top-left brand panel (Split Panel), centered (Full-Width). Always live text + CSS, never image.

**Education Pillar Palette** (70/30) governs every screen. No yellows, oranges, purples.

**"Morehouse School of Medicine"** appears in `mono/label-md/uppercase` in sidebar and login brand panel.

**Hero Gradient** (landing page and onboarding flows):
```css
background: linear-gradient(170deg, #ffffff 0%, #f5f3ef 40%, #faf9f6 100%);
```

**Nav Transparency** (both landing page nav and dashboard top bar):
```css
background: #ffffffF2;           /* white at 95% opacity */
backdrop-filter: blur(12px);
border-bottom: 1px solid #edeae4; /* borderLight */
```

---

# PART 9: FILE STRUCTURE

```
/src
├── /app
│   ├── /components
│   │   ├── /ui                    ← 50 shadcn atoms + section-marker
│   │   ├── /shared                ← Molecules: stat-card, progress-ring, 
│   │   │                             sparkline, mastery-cell, ascending-squares,
│   │   │                             woven-field, thread-divider, logo-wordmark
│   │   ├── /organisms             ← kpi-strip, course-row, activity-feed, 
│   │   │                             task-list, mastery-heatmap, quick-actions
│   │   └── /layout
│   │       ├── DashboardLayout.tsx      ← Template A
│   │       ├── AdminLayout.tsx          ← Template B
│   │       ├── SplitPanelLayout.tsx     ← Template C
│   │       ├── FullWidthLayout.tsx      ← Template D
│   │       ├── FocusModeLayout.tsx      ← Template E
│   │       ├── TopNavigation.tsx
│   │       └── AdminSidebar.tsx
│   ├── /pages                     ← 78 screens
│   └── /hooks
│       ├── useBreakpoint.ts
│       ├── useScrollY.ts
│       └── useIntersectionReveal.ts
└── /styles
    ├── theme.css                  ← all tokens
    ├── tailwind.css
    ├── fonts.css
    └── animations.css
```

---

# PART 10: THE STRATEGIC FRAME

This design system isn't just a component library—it's the visual substrate for a knowledge graph operating system. Every design decision reinforces the "woven tapestry" metaphor:

- Individual threads (curriculum, assessment, measurement, compliance) gain strength when woven together
- The atomic design hierarchy mirrors the graph architecture: atoms are nodes, molecules are small subgraphs, organisms are connected systems, templates are schema patterns, pages are instantiated graphs
- The three warm surfaces feel like layers of paper—curriculum documents, assessment blueprints, compliance matrices—stacked on a desk
- The single navy bookmark is the spine of the book holding those pages together, while navy accents woven throughout every card are the thread that makes the whole tapestry feel blue-dominant and branded

**The system enables rapid page creation while maintaining brand consistency.** Any developer answers the 10-question checklist, selects template/organisms/molecules, follows the surface hierarchy, and produces a screen that belongs to Journey OS without referencing source code or making arbitrary decisions.

**Every screen should feel like it belongs**—not because they look identical, but because they follow the same rules.

---

**End of Design System Specification v2.0**

This document supersedes all previous design system documentation. If there is any conflict between this document and existing code, this document is the source of truth.
