import { RouterProvider } from 'react-router';
import { router } from './routes';
import { Toaster } from './components/ui/sonner';
import '@/styles/tailwind.css';
import '@/styles/index.css';

function App() {
  return (
    <>
      <RouterProvider
        router={router}
        fallbackElement={
          <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#f5f3ef' }}>
            <div className="flex flex-col items-center gap-4">
              <div className="size-10 border-3 border-[#002c76] border-t-transparent rounded-full animate-spin" />
              <p style={{ color: '#5a5a58', fontFamily: "'Source Sans 3', sans-serif" }}>Loading...</p>
            </div>
          </div>
        }
      />
      <Toaster />
    </>
  );
}

export default App;
