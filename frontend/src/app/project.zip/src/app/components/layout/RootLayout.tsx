import { Suspense } from "react";
import { Outlet } from "react-router";

function LoadingFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#f5f3ef' }}>
      <div className="flex flex-col items-center gap-4">
        <div className="size-10 border-3 border-[#002c76] border-t-transparent rounded-full animate-spin" />
        <p style={{ color: '#5a5a58', fontFamily: "'Source Sans 3', sans-serif" }}>Loading...</p>
      </div>
    </div>
  );
}

export default function RootLayout() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Outlet />
    </Suspense>
  );
}
