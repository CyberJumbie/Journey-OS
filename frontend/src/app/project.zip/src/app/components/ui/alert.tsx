import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "./utils";

const alertVariants = cva(
  "relative w-full rounded-[--radius-md] border-l-[3px] px-5 py-4 text-[14px] font-sans grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
  {
    variants: {
      variant: {
        default: "bg-[--parchment] text-[--ink] border-l-[--border-default]",
        success:
          "bg-[--success-bg] text-[--green-dark] border-l-[--green] [&>svg]:text-[--green]",
        warning:
          "bg-[--warning-bg] text-[#8a7a10] border-l-[--warning] [&>svg]:text-[--warning]",
        danger:
          "bg-[--danger-bg] text-[#8a2c0a] border-l-[--danger] [&>svg]:text-[--danger]",
        info:
          "bg-[--info-bg] text-[--navy] border-l-[--info] [&>svg]:text-[--info]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

function Alert({
  className,
  variant,
  ...props
}: React.ComponentProps<"div"> & VariantProps<typeof alertVariants>) {
  return (
    <div
      data-slot="alert"
      role="alert"
      className={cn(alertVariants({ variant }), className)}
      {...props}
    />
  );
}

function AlertTitle({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-title"
      className={cn(
        "col-start-2 line-clamp-1 min-h-4 font-semibold tracking-normal text-[14px]",
        className,
      )}
      {...props}
    />
  );
}

function AlertDescription({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-description"
      className={cn(
        "col-start-2 grid justify-items-start gap-1 text-[14px] [&_p]:leading-relaxed opacity-90",
        className,
      )}
      {...props}
    />
  );
}

export { Alert, AlertTitle, AlertDescription };
