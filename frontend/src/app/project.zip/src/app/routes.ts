import { createBrowserRouter } from "react-router";
import { lazy } from "react";
import RootLayout from "./components/layout/RootLayout";

/**
 * AUTHENTICATION FLOWS BY ROLE
 * 
 * STUDENT FLOW:
 * 1. / (Landing) → Landing page with waitlist
 * 2. /role-selection → Select "Student"
 * 3. /register/student (StudentRegistration) → Fill form
 * 4. Email sent with verification link
 * 5. /email-verification?token=xxx&role=student → Verify email
 * 6. /onboarding/student (StudentOnboarding) → Personalize (study goals, subjects, time)
 * 7. /student-dashboard → Student Dashboard
 * 
 * FACULTY FLOW:
 * 1. / (Landing) → Landing page with waitlist
 * 2. /role-selection → Select "Faculty"
 * 3. /register/faculty (FacultyRegistration) → Fill form
 * 4. Email sent with verification link
 * 5. /email-verification?token=xxx&role=faculty → Verify email
 * 6. /onboarding/faculty (FacultyOnboarding) → Personalize (teaching areas, question types, courses)
 * 7. /dashboard → Faculty Dashboard
 * 
 * ADMIN FLOW:
 * 1. / (Landing) → Landing page with waitlist
 * 2. /role-selection → Select "Institutional Admin"
 * 3. /register/admin (AdminRegistration) → Fill form (includes access code)
 * 4. Email sent with verification link
 * 5. /email-verification?token=xxx&role=admin → Verify email
 * 6. /onboarding/admin (AdminOnboarding) → Setup guide and task overview
 * 7. /admin → Admin Dashboard
 * 
 * SIGN IN:
 * - /login → Select role tab (Student/Faculty/Admin) → Redirects to appropriate dashboard
 */

// Landing page
const Landing = lazy(() => import("./pages/Landing"));
const Home = lazy(() => import("./pages/Home"));

// Auth screens
const Login = lazy(() => import("./pages/auth/Login"));
const Registration = lazy(() => import("./pages/auth/Registration"));
const RoleSelection = lazy(() => import("./pages/auth/RoleSelection"));
const StudentRegistration = lazy(() => import("./pages/auth/StudentRegistration"));
const FacultyRegistration = lazy(() => import("./pages/auth/FacultyRegistration"));
const AdminRegistration = lazy(() => import("./pages/auth/AdminRegistration"));
const ForgotPassword = lazy(() => import("./pages/auth/ForgotPassword"));
const EmailVerification = lazy(() => import("./pages/auth/EmailVerification"));
const InvitationAccept = lazy(() => import("./pages/auth/InvitationAccept"));
const PersonaOnboarding = lazy(() => import("./pages/auth/PersonaOnboarding"));

// Dashboard
const Dashboard = lazy(() => import("./pages/dashboard/Dashboard"));
const DashboardFacultyView = lazy(() => import("./pages/dashboard/FacultyDashboard"));
const StudentDashboard = lazy(() => import("./pages/dashboard/StudentDashboard"));

// Student Learning
const StudentPractice = lazy(() => import("./pages/student/StudentPractice"));
const StudentQuestionView = lazy(() => import("./pages/student/StudentQuestionView"));
const StudentResults = lazy(() => import("./pages/student/StudentResults"));
const StudentProgress = lazy(() => import("./pages/student/StudentProgress"));
const StudentAnalytics = lazy(() => import("./pages/student/StudentAnalytics"));

// Course Management
const CreateCourse = lazy(() => import("./pages/courses/CreateCourse"));
const UploadSyllabus = lazy(() => import("./pages/courses/UploadSyllabus"));
const SyllabusProcessing = lazy(() => import("./pages/courses/SyllabusProcessing"));
const SyllabusEditor = lazy(() => import("./pages/courses/SyllabusEditor"));
const ReviewSyllabusMapping = lazy(() => import("./pages/courses/ReviewSyllabusMapping"));
const CourseDashboard = lazy(() => import("./pages/courses/CourseDashboard"));
const AllCourses = lazy(() => import("./pages/courses/AllCourses"));
const LectureUpload = lazy(() => import("./pages/courses/LectureUpload"));
const LectureProcessing = lazy(() => import("./pages/courses/LectureProcessing"));
const SubConceptReviewQueue = lazy(() => import("./pages/courses/SubConceptReviewQueue"));
const OutcomeMapping = lazy(() => import("./pages/courses/OutcomeMapping"));
const CourseReady = lazy(() => import("./pages/courses/CourseReady"));
const WeekView = lazy(() => import("./pages/courses/WeekView"));
const WeekMaterialsUpload = lazy(() => import("./pages/courses/WeekMaterialsUpload"));

// Question Generation
const GenerateQuestionsSyllabus = lazy(() => import("./pages/generation/GenerateQuestionsSyllabus"));
const GenerateQuestionsTopic = lazy(() => import("./pages/generation/GenerateQuestionsTopic"));
const GenerationSpecificationWizard = lazy(() => import("./pages/generation/GenerationSpecificationWizard"));
const BatchProgress = lazy(() => import("./pages/generation/BatchProgress"));
const GenerateTest = lazy(() => import("./pages/generation/GenerateTest"));
const GenerateQuiz = lazy(() => import("./pages/generation/GenerateQuiz"));
const GenerateHandout = lazy(() => import("./pages/generation/GenerateHandout"));

// Question Review
const QuestionReviewList = lazy(() => import("./pages/questions/QuestionReviewList"));
const QuestionDetailView = lazy(() => import("./pages/questions/QuestionDetailView"));
const ItemDetail = lazy(() => import("./pages/questions/ItemDetail"));
const AIRefinement = lazy(() => import("./pages/questions/AIRefinement"));
const ConversationalRefinement = lazy(() => import("./pages/questions/ConversationalRefinement"));
const QuestionHistory = lazy(() => import("./pages/questions/QuestionHistory"));
const FacultyReviewQueue = lazy(() => import("./pages/questions/FacultyReviewQueue"));

// Repository
const Repository = lazy(() => import("./pages/repository/Repository"));
const ItemBankBrowser = lazy(() => import("./pages/repository/ItemBankBrowser"));

// Exams
const ExamAssembly = lazy(() => import("./pages/exams/ExamAssembly"));
const ExamAssignment = lazy(() => import("./pages/exams/ExamAssignment"));
const RetiredExamUpload = lazy(() => import("./pages/exams/RetiredExamUpload"));

// Uploads
const FacultyQuestionUpload = lazy(() => import("./pages/uploads/FacultyQuestionUpload"));

// Analytics
const CourseAnalytics = lazy(() => import("./pages/analytics/CourseAnalytics"));
const PersonalDashboard = lazy(() => import("./pages/analytics/PersonalDashboard"));
const BlueprintCoverage = lazy(() => import("./pages/analytics/BlueprintCoverage"));
const Analytics = lazy(() => import("./pages/analytics/Analytics"));

// Settings & Support
const Settings = lazy(() => import("./pages/settings/Settings"));
const Help = lazy(() => import("./pages/help/Help"));

// Profile & User Management
const Profile = lazy(() => import("./pages/profile/Profile"));
const Notifications = lazy(() => import("./pages/notifications/Notifications"));

// Operations & Templates
const BulkOperations = lazy(() => import("./pages/operations/BulkOperations"));
const QuestionTemplates = lazy(() => import("./pages/templates/QuestionTemplates"));

// Admin
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const SetupWizard = lazy(() => import("./pages/admin/SetupWizard"));
const FrameworkManagement = lazy(() => import("./pages/admin/FrameworkManagement"));
const FacultyManagement = lazy(() => import("./pages/admin/FacultyManagement"));
const KnowledgeBrowser = lazy(() => import("./pages/admin/KnowledgeBrowser"));
const SubConceptDetail = lazy(() => import("./pages/admin/SubConceptDetail"));
const ILOManagement = lazy(() => import("./pages/admin/ILOManagement"));
const DataIntegrityDashboard = lazy(() => import("./pages/admin/DataIntegrityDashboard"));
const FULFILLSReviewQueue = lazy(() => import("./pages/admin/FULFILLSReviewQueue"));
const LCMEComplianceHeatmap = lazy(() => import("./pages/admin/LCMEComplianceHeatmap"));
const LCMEElementDrillDown = lazy(() => import("./pages/admin/LCMEElementDrillDown"));
const AdminUserDirectory = lazy(() => import("./pages/admin/AdminUserDirectory"));
const ApplicationReviewQueue = lazy(() => import("./pages/admin/ApplicationReviewQueue"));
const InstitutionListDashboard = lazy(() => import("./pages/admin/InstitutionListDashboard"));
const InstitutionDetailView = lazy(() => import("./pages/admin/InstitutionDetailView"));

// Public
const InstitutionApplication = lazy(() => import("./pages/InstitutionApplication"));

// Institutional Admin
const InstitutionalAdminDashboard = lazy(() => import("./pages/institution/InstitutionalAdminDashboard"));
const UserManagement = lazy(() => import("./pages/institution/UserManagement"));
const FrameworkConfiguration = lazy(() => import("./pages/institution/FrameworkConfiguration"));
const CoverageDashboard = lazy(() => import("./pages/institution/CoverageDashboard"));
const AccreditationReports = lazy(() => import("./pages/institution/AccreditationReports"));

// Institutional Admin — new screens
const SectionSequenceModeler = lazy(() => import("./pages/institution/SectionSequenceModeler"));
const InstitutionalUSMLECoverage = lazy(() => import("./pages/institution/InstitutionalUSMLECoverage"));
const FacultyUSMLECoverage = lazy(() => import("./pages/institution/FacultyUSMLECoverage"));

// Faculty
const FacultyDashboardMain = lazy(() => import("./pages/faculty/FacultyDashboard"));
const CourseList = lazy(() => import("./pages/faculty/CourseList"));
const CourseDetailView = lazy(() => import("./pages/faculty/CourseDetailView"));
const CreateEditCourse = lazy(() => import("./pages/faculty/CreateEditCourse"));
const CourseRoster = lazy(() => import("./pages/faculty/CourseRoster"));
const QuestWorkbench = lazy(() => import("./pages/faculty/QuestWorkbench"));

// Communication & Collaboration
const FacultyCommunicationHub = lazy(() => import("./pages/communications/FacultyCommunicationHub"));
const StudentSupportCenter = lazy(() => import("./pages/communications/StudentSupportCenter"));
const AnnouncementSystem = lazy(() => import("./pages/communications/AnnouncementSystem"));

// Analytics & Reporting
const InstitutionalAnalytics = lazy(() => import("./pages/analytics/InstitutionalAnalytics"));
const QuestionPerformanceMetrics = lazy(() => import("./pages/analytics/QuestionPerformanceMetrics"));

// System Settings & Administration
const SystemConfigurationDashboard = lazy(() => import("./pages/settings/SystemConfigurationDashboard"));
const UserRoleManagement = lazy(() => import("./pages/settings/UserRoleManagement"));

// Onboarding
const StudentOnboarding = lazy(() => import("./pages/onboarding/StudentOnboarding"));
const FacultyOnboarding = lazy(() => import("./pages/onboarding/FacultyOnboarding"));
const AdminOnboarding = lazy(() => import("./pages/onboarding/AdminOnboarding"));

// Error pages
const NotFound = lazy(() => import("./pages/errors/NotFound"));

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Landing },
      { path: "home", Component: Home },
      { path: "apply", Component: InstitutionApplication },

      // Institution Admin
      { path: "institution", Component: InstitutionalAdminDashboard },
      { path: "institution/dashboard", Component: InstitutionalAdminDashboard },
      { path: "institution/faculty", Component: FacultyManagement },
      { path: "institution/students", Component: InstitutionalAdminDashboard },
      { path: "institution/courses", Component: InstitutionalAdminDashboard },
      { path: "institution/blueprints", Component: InstitutionalAdminDashboard },
      { path: "institution/analytics", Component: InstitutionalAnalytics },
      { path: "institution/users", Component: UserManagement },
      { path: "institution/frameworks", Component: FrameworkConfiguration },
      { path: "institution/coverage", Component: CoverageDashboard },
      { path: "institution/usmle-coverage", Component: InstitutionalUSMLECoverage },
      { path: "institution/faculty-coverage", Component: FacultyUSMLECoverage },
      { path: "institution/sequence", Component: SectionSequenceModeler },
      { path: "institution/accreditation", Component: AccreditationReports },
      { path: "institution/settings", Component: Settings },

      // Faculty
      { path: "faculty", Component: FacultyDashboardMain },
      { path: "faculty/dashboard", Component: FacultyDashboardMain },
      { path: "faculty/courses", Component: CourseList },
      { path: "faculty/courses/create", Component: CreateEditCourse },
      { path: "faculty/courses/:id", Component: CourseDetailView },
      { path: "faculty/courses/:id/edit", Component: CreateEditCourse },
      { path: "faculty/courses/:id/roster", Component: CourseRoster },
      { path: "faculty/questions/generate", Component: GenerateQuestionsTopic },
      { path: "faculty/quest", Component: QuestWorkbench },
      { path: "faculty/questions/batch-upload", Component: GenerateQuestionsTopic },
      { path: "faculty/questions/retired-upload", Component: GenerateQuestionsTopic },
      { path: "faculty/questions/repository", Component: Repository },
      { path: "faculty/questions/:id", Component: QuestionDetailView },
      { path: "faculty/questions/review", Component: FacultyReviewQueue },
      { path: "faculty/exams/assembly", Component: ExamAssembly },
      { path: "faculty/exams/assignment", Component: ExamAssignment },
      { path: "faculty/communications", Component: FacultyCommunicationHub },
      { path: "faculty/analytics", Component: InstitutionalAnalytics },
      { path: "faculty/repository", Component: Repository },
      { path: "faculty/settings", Component: Settings },

      // Auth
      { path: "role-selection", Component: RoleSelection },
      { path: "login", Component: Login },
      { path: "register", Component: Registration },
      { path: "register/student", Component: StudentRegistration },
      { path: "register/faculty", Component: FacultyRegistration },
      { path: "register/admin", Component: AdminRegistration },
      { path: "forgot-password", Component: ForgotPassword },
      { path: "email-verification", Component: EmailVerification },
      { path: "verify-email", Component: EmailVerification },
      { path: "invite/accept", Component: InvitationAccept },

      // Onboarding
      { path: "onboarding", Component: PersonaOnboarding },
      { path: "onboarding/student", Component: StudentOnboarding },
      { path: "onboarding/faculty", Component: FacultyOnboarding },
      { path: "onboarding/admin", Component: AdminOnboarding },

      // Dashboards
      { path: "dashboard", Component: Dashboard },
      { path: "faculty-dashboard", Component: DashboardFacultyView },
      { path: "student-dashboard", Component: StudentDashboard },

      // Student
      { path: "student", Component: StudentDashboard },
      { path: "student/dashboard", Component: StudentDashboard },
      { path: "student/practice", Component: StudentPractice },
      { path: "student/practice/session", Component: StudentQuestionView },
      { path: "student/practice/results", Component: StudentResults },
      { path: "student/progress", Component: StudentProgress },
      { path: "student/analytics", Component: StudentAnalytics },
      { path: "student/support", Component: StudentSupportCenter },

      // Profile & Notifications
      { path: "profile", Component: Profile },
      { path: "notifications", Component: Notifications },

      // Courses
      { path: "courses", Component: AllCourses },
      { path: "courses/create", Component: CreateCourse },
      { path: "courses/upload-lecture", Component: LectureUpload },
      { path: "courses/lecture-processing", Component: LectureProcessing },
      { path: "courses/subconcept-review", Component: SubConceptReviewQueue },
      { path: "courses/syllabus-editor", Component: SyllabusEditor },
      { path: "courses/outcome-mapping", Component: OutcomeMapping },
      { path: "courses/:courseId/upload-syllabus", Component: UploadSyllabus },
      { path: "courses/:courseId/processing", Component: SyllabusProcessing },
      { path: "courses/:courseId/review-mapping", Component: ReviewSyllabusMapping },
      { path: "courses/:courseId/ready", Component: CourseReady },
      { path: "courses/:courseId/week/:weekId", Component: WeekView },
      { path: "courses/:courseId/week/:weekId/upload-materials", Component: WeekMaterialsUpload },
      { path: "courses/:courseId/week/:weekId/generate", Component: GenerateQuestionsSyllabus },
      { path: "courses/:courseId/week/:weekId/generate-test", Component: GenerateTest },
      { path: "courses/:courseId/week/:weekId/generate-quiz", Component: GenerateQuiz },
      { path: "courses/:courseId/week/:weekId/generate-handout", Component: GenerateHandout },
      { path: "courses/:courseId/questions", Component: QuestionReviewList },
      { path: "courses/:courseId", Component: CourseDashboard },

      // Generation
      { path: "generation/wizard", Component: GenerationSpecificationWizard },
      { path: "generation/progress", Component: BatchProgress },
      { path: "generate/topic", Component: GenerateQuestionsTopic },
      { path: "generate/test", Component: GenerateTest },
      { path: "generate/quiz", Component: GenerateQuiz },
      { path: "generate/handout", Component: GenerateHandout },

      // Questions
      { path: "questions/review", Component: FacultyReviewQueue },
      { path: "questions/:questionId", Component: ItemDetail },
      { path: "questions/:questionId/detail", Component: QuestionDetailView },
      { path: "questions/:questionId/refine", Component: ConversationalRefinement },
      { path: "questions/:questionId/ai-refine", Component: AIRefinement },
      { path: "questions/:questionId/history", Component: QuestionHistory },

      // Exams
      { path: "exams/assembly", Component: ExamAssembly },
      { path: "exams/assign", Component: ExamAssignment },
      { path: "exams/retired-upload", Component: RetiredExamUpload },

      // Uploads
      { path: "uploads/faculty-questions", Component: FacultyQuestionUpload },

      // Repository
      { path: "repository", Component: Repository },
      { path: "repository/item-bank", Component: ItemBankBrowser },

      // Templates & Operations
      { path: "templates", Component: QuestionTemplates },
      { path: "bulk-operations", Component: BulkOperations },

      // Analytics
      { path: "analytics", Component: Analytics },
      { path: "analytics/course/:courseId", Component: CourseAnalytics },
      { path: "analytics/personal", Component: PersonalDashboard },
      { path: "analytics/blueprint-coverage", Component: BlueprintCoverage },
      { path: "analytics/questions", Component: QuestionPerformanceMetrics },

      // Admin
      { path: "admin", Component: AdminDashboard },
      { path: "admin/dashboard", Component: AdminDashboard },
      { path: "admin/institutions", Component: InstitutionListDashboard },
      { path: "admin/institutions/:id", Component: InstitutionDetailView },
      { path: "admin/users", Component: AdminUserDirectory },
      { path: "admin/announcements", Component: AnnouncementSystem },
      { path: "admin/analytics", Component: InstitutionalAnalytics },
      { path: "admin/settings", Component: SystemConfigurationDashboard },
      { path: "admin/settings/roles", Component: UserRoleManagement },
      { path: "admin/applications", Component: ApplicationReviewQueue },
      { path: "admin/setup", Component: SetupWizard },
      { path: "admin/frameworks", Component: FrameworkManagement },
      { path: "admin/faculty", Component: FacultyManagement },
      { path: "admin/knowledge", Component: KnowledgeBrowser },
      { path: "admin/knowledge/:uuid", Component: SubConceptDetail },
      { path: "admin/ilos", Component: ILOManagement },
      { path: "admin/data-integrity", Component: DataIntegrityDashboard },
      { path: "admin/fulfills-review", Component: FULFILLSReviewQueue },
      { path: "admin/lcme-compliance-heatmap", Component: LCMEComplianceHeatmap },
      { path: "admin/lcme-element-drill-down", Component: LCMEElementDrillDown },

      // Settings & Help
      { path: "settings", Component: Settings },
      { path: "help", Component: Help },

      // Catch-all
      { path: "*", Component: NotFound },
    ],
  },
]);