# Journey OS — Value-Sequenced Build Roadmap v3.0

**Date:** March 2, 2026
**Baseline:** Architecture v10.0 · NODE_REGISTRY v1.0 · SUPABASE_DDL v1.0 · Gap Analysis v2.0
**Methodology:** Value phases (not technical layers). Each phase ends with a real consumer using the product.
**Supersedes:** Roadmap v2.3 (56-sprint technical-layer sequence)

---

## Why This Roadmap Exists

Roadmap v2.3 was sequenced by technical dependency — graph schema, then DDL, then ingestion, then generation, then UI. That's an engineer's roadmap. This document resequences the same work by **quickest path to consumer value** — what delivers something a real human at MSM would use, as fast as possible, while proving each layer of the thesis.

The architecture, schema, and design decisions are unchanged. The order in which they get built is different.

---

## The Thesis, Proven in Stages

Journey OS proves four things, in order:

1. **Generation quality.** Can AI generate NBME-quality questions from MSM curriculum context?
2. **Coverage chain.** Can a knowledge graph make those questions traceable to national standards?
3. **Institutional intelligence.** Can that traceability automate compliance evidence?
4. **Closed loop.** Can student interaction data personalize learning through the same graph?

Each phase proves one layer while delivering a real tool to a real person.

---

## Consumers and When They Come Online

**Faculty (Dr. Amara Osei)** — Available immediately. She writes exam questions in Word right now. If you make that faster, she uses it tomorrow. She doesn't need the full knowledge graph. She needs the generation pipeline with enough curriculum context to produce questions that feel like they understand her course.

**Course Director / Institutional Admin (Dr. Takahashi)** — Needs the coverage chain and compliance data. Slower burn, enormous value when LCME comes knocking.

**Students (Marcus Williams)** — Needs the item bank, delivery mechanism, and ideally the adaptive layer. Longest path, biggest market.

---

## PHASE 1: "The Question Factory"

**Weeks 1–8 · Consumer: Faculty · Proves: Generation quality**

Faculty generates their first real exam question from their own curriculum content. The knowledge graph exists but is minimal — just enough to provide curriculum context for generation.

---

### Week 1–2: Skeleton + Seeding + CopilotKit Spike

**Infrastructure:**
- Monorepo scaffold (Turborepo): `apps/web` (Next.js 15), `apps/server` (Express), `packages/shared-types`, `packages/ui`, `services/kg-seeder`
- Neo4j Aura provisioned (Free tier for dev)
- Supabase project provisioned, pgvector enabled
- CI/CD: GitHub Actions (lint, type-check, build)
- `.claude.md` loaded from CLAUDE_MD_TEMPLATE (correct labels, relationships, design tokens from day one)
- Environment: Anthropic API key, Voyage AI key

**Neo4j Seeding (idempotent scripts in `services/kg-seeder/`):**
- Layer 1 institutional hierarchy: Institution → School → Program → ProgramTrack → AcademicYear → CurricularPhase → Block → Course → Section → AcademicTerm + ILO (~65–70 nodes)
- Layer 2 framework nodes (~492 nodes):
  - USMLE: 16 `USMLE_System` + 7 `USMLE_Discipline` + 4 `USMLE_Task` + ~200 `USMLE_Topic` = ~227
  - LCME: 12 `LCME_Standard` + 93 `LCME_Element` = 105
  - ACGME: 6 `ACGME_Domain` + 21 `ACGME_Subdomain` = 27
  - AAMC: 6 `AAMC_Domain` + 49 `AAMC_Competency` = 55
  - UME: 6 `UME_Competency` + 49 `UME_Subcompetency` = 55 + 6 ALIGNS_WITH bridge edges
  - EPA: 13 nodes
  - Bloom: 6 `BloomLevel`, Miller: 4 `MillerLevel`
- All labels per NODE_REGISTRY v1.0 (SCREAMING_SNAKE for framework labels, PascalCase for concepts)
- Uniqueness constraints per NODE_REGISTRY §Constraints
- JSON seed files already exist: `lcme_standards.json` (105), `epa-ume-competencies.json` (84)

**Supabase DDL (from SUPABASE_DDL v1.0):**
- Core tables only for Phase 1: `institutions`, `user_profiles`, `uploads`, `content_chunks`, `content_chunk_embeddings` (1024-dim, HNSW index), `assessment_items` (with 6-field Toulmin JSONB), `options`, `generation_logs`
- RLS scoped by `institution_id`
- Auth: Supabase Auth with JWT carrying `{ role, institution_id, is_course_director }`
- Roles enabled: `faculty`, `institutional_admin` (others deferred)

**`packages/shared-types/src/graph.ts`:**
- TypeScript types matching NODE_REGISTRY v1.0 exactly

**CopilotKit ↔ LangGraph.js Integration Spike (2–3 days):**
- Minimal LangGraph.js `StateGraph` with ONE node on Express
- Node updates a single string field in state via UIEventEmitter
- CopilotKit Runtime configured, SSE streaming operational
- `useCoAgent` consumes STATE_DELTA in a minimal React page
- **Test:** STATE_DELTA renders in frontend. TEXT_MESSAGE streams to chat.
- **This is the highest-risk technical validation in the entire project.** If CopilotKit + LangGraph.js doesn't work cleanly over SSE, the entire frontend architecture needs a fallback (custom chat UI with SSE — significantly more code).

**Exit Criteria:**
- `MATCH (n:USMLE_System) RETURN count(n)` → 16
- `MATCH (n:LCME_Element) RETURN count(n)` → 93
- `MATCH (n:BloomLevel) RETURN count(n)` → 6
- Total Layer 2: ~492
- Seeder idempotent (run twice, same count)
- CopilotKit spike: STATE_DELTA renders, TEXT_MESSAGE streams

---

### Week 3–4: Ingestion for ONE Course

Don't build the full 7-stage Inngest pipeline. Build a **manual ingestion path** for a single course — MEDI 531 (Organ Systems I), Dr. Osei's course. Prove the content pipeline works before scaling.

**Build:**
- File upload endpoint (Supabase Storage, WORM pattern, `raw-uploads` bucket)
- PDF parser for one real syllabus (pdfplumber or markitdown)
- Semantic chunker: 800-token chunks, 100-token overlap, density-based cleaning
- Embedding service: Voyage AI voyage-large-2, 1024-dim, stored in `content_chunk_embeddings` with HNSW index
- AI concept extraction: Claude Haiku extracts SubConcepts from chunks with confidence scores
- DualWriteService: Supabase first → Neo4j second → `sync_status` column tracks state
- Framework alignment: Haiku tags SubConcepts → USMLE_System + USMLE_Discipline via `MAPS_TO` relationships
- TEACHES relationships created (AI_VERIFIED authority, not yet TEACHES_VERIFIED)

**Result:** ~50–200 SubConcepts with framework mappings for one course. Enough to generate from.

**What's deliberately skipped:**
- Full Inngest background pipeline (build in Phase 3)
- TEACHES_VERIFIED promotion workflow (build in Phase 2)
- SLO extraction and SLO → ILO FULFILLS linking (build in Phase 3)
- LOD enrichment / StandardTerm nodes (build in Phase 4)
- SlideSection handling (deprecated — slides become ContentChunks with source_type: "slide")

**Exit Criteria:**
- One real MSM syllabus parsed, chunked, embedded, and concept-extracted
- SubConcepts visible in Neo4j with MAPS_TO → USMLE_System relationships
- Dual-write sync_status = "synced" for all records
- pgvector semantic search returns relevant chunks for a test query

---

### Week 5–6: Generation Pipeline (Critical Path Nodes)

Build LangGraph.js on Express with the critical path — enough to produce a question end-to-end.

**Pipeline (7 of 14 nodes):**

```
init → context_compiler → vignette_builder → stem_writer → distractor_generator → validator → graph_writer
```

| Node | Model | What It Does |
|------|-------|-------------|
| `init` | — | Load session, course context, coverage state |
| `context_compiler` | Haiku (refiner) | Graph traversal (SubConcept → ContentChunk → full text from Supabase) + pgvector semantic search → Reciprocal Rank Fusion → Context Refiner filters to 4,000-token budget |
| `vignette_builder` | Sonnet | Generate 150-200 word clinical vignette (streamed via STATE_DELTA) |
| `stem_writer` | Sonnet | Generate NBME-style question stem |
| `distractor_generator` | Sonnet | Phase 1: reasoning artifact. Phase 2: 1 correct + 4 diagnostic distractors (sequential emit via STATE_DELTA) |
| `validator` | Rule-based | Start with 10 of 30 NBME rules (the most impactful structural rules) |
| `graph_writer` | — | Dual-write to Neo4j + Supabase: AssessmentItem, Options, TARGETS → SubConcept, AT_BLOOM → BloomLevel |

**Skipped nodes (added in Phase 2):** tagger, dedup_detector, critic_agent, review_router, load_review_question, apply_edit, revalidate

**Key identifiers (per R-011, R-038):**
- Agent ID: `journey_generation`
- Inngest event prefix: `journey/`
- Endpoint: `POST /api/v1/generate`

**Exit Criteria:**
- Faculty message "Generate a question about atherosclerosis for MEDI 531" → pipeline runs → question appears
- Vignette, stem, and options stream progressively via STATE_DELTA
- Generated item persisted in both Supabase and Neo4j with `sync_status: "synced"`
- TARGETS → SubConcept relationship created in Neo4j

---

### Week 7–8: Workbench MVP

Wire the pipeline into the faculty-facing UI.

**Build:**
- CopilotKit integration: CopilotChat (left panel, 45%) + question preview (right panel, 55%)
- Single generation mode only (no bulk, no review mode)
- Progressive rendering: vignette streams → stem appears → options populate one at a time
- Approve/reject buttons that write `status` to `assessment_items`
- Basic login (Supabase Auth) + course selection
- Basic question bank view: browse generated items, filter by course
- Functional UI — cream/white surfaces, readable typography. Not full design system polish yet.

**Exit Criteria:**
- A real MSM faculty member can log in, select their course, ask for a question, and get an NBME-style item generated from their actual syllabus content
- The question renders progressively in the workbench
- Faculty can approve or reject
- Item persists in Neo4j + Supabase with framework relationships

**Phase 1 ships.** Faculty has a working tool.

---

### Phase 1: What's Deliberately Deferred

Bulk generation, review mode, Critic Agent, dedup detection, ECD TaskShells, topic modeling, TEACHES_VERIFIED distinction, full 30-rule NBME validation, full design system polish, notifications, onboarding wizard, SLO extraction, coverage analytics, LCME compliance, student anything.

---

## PHASE 2: "The Quality Engine"

**Weeks 9–16 · Consumer: Faculty + Course Director · Proves: Exam-ready quality at scale**

Faculty trusts the questions enough to put them on a real exam. Course Directors can run bulk generation and review a queue.

---

### Week 9–10: Quality Pipeline Completion

Add the remaining pipeline nodes:

| Node | Model | What It Does |
|------|-------|-------------|
| `tagger` | Haiku | Auto-tag: Bloom, USMLE system/discipline, difficulty, ACGME, EPA |
| `dedup_detector` | Voyage AI | Embedding → pgvector HNSW nearest neighbor (0.85 flag / 0.95 auto-reject) |
| `validator` (upgrade) | Rule-based + Sonnet | Full 30 rules (22 NBME core + 8 extended), including "Cover the Options" |
| `critic_agent` | Opus | 6-metric scoring: Faithfulness ≥ 0.9, Contextual Recall ≥ 0.8, Answer Relevancy ≥ 0.95, Distractor Plausibility ≥ 0.6, Bloom Alignment pass/fail, Clinical Accuracy ≥ 0.95 |
| `review_router` | Rule-based | Routes: auto_approve / auto_reject+retry / faculty_review |

Self-correction loops: on validation failure, re-invoke with modified prompt (not just retry — change the instruction to address the specific failure), up to 2 attempts.

**Exit Criteria:**
- Full 14-node pipeline operational (11 generation + 3 review)
- Critic Agent scores every generated item
- Auto-approve and auto-reject routing works

---

### Week 11–12: Review Mode + Bulk Generation + Conversational Refinement

**Review mode:**
- Review mode in workbench (`/generate?mode=review`): load question → approve/edit/reject
- `load_review_question → apply_edit → revalidate → critic_agent` pipeline
- Conversational refinement: faculty says "make the vignette shorter" or "change to a pediatric setting" → system identifies which pipeline node to re-invoke → re-runs from that point → revalidates

**Bulk generation:**
- Inngest batch orchestration: up to 5 parallel, `journey/batch.*` events
- Per-item STATE_DELTA via SSE (AG-UI, per R-024) updates `bulk_queue[i]`
- Socket.io delivers "batch complete" notification
- BulkQueueView: progress tracking per item, faculty intervention on failures
- Course Director role gate: `is_course_director: true` required for bulk (R-023)

**Exit Criteria:**
- Faculty can modify a generated question through chat and see it update
- Bulk generation of 20+ questions completes with per-item tracking
- Review mode loads existing questions for approve/edit/reject

---

### Week 13–14: ECD + TaskShells

Build the Evidence-Centered Design layer:

- context_compiler ECD sub-steps: Evidence Design → Task Family Selection → Instance Specification → Agentic RAG
- Seed 10–15 TaskShell nodes in Neo4j (clinical vignette, mechanism explanation, drug comparison, diagnostic reasoning, lab interpretation, etc.) with `bloom_range`, `concept_family`, `constraints` properties
- ProficiencyVariable nodes: 1:1 with SubConcept, linked via MAPPED_TO
- Toulmin argument structure generated on every item (6 fields: claim, data, warrant, backing, rebuttal, qualifier — stored as JSONB per R-030)
- ProficiencyVariable → ASSESSED_BY → TaskShell relationships

**Exit Criteria:**
- Generation pipeline uses TaskShell templates to constrain question type
- Every generated item has a Toulmin JSONB with all 6 fields populated
- ProficiencyVariable nodes exist for all seeded SubConcepts

---

### Week 15–16: Data Quality + Faculty Trust

Build the infrastructure that makes faculty trust the system:

- **TEACHES → TEACHES_VERIFIED workflow:** Faculty review UI for AI-extracted concept mappings. Approve promotes to TEACHES_VERIFIED; reject removes; edit corrects. Only TEACHES_VERIFIED participates in the canonical coverage chain.
- **Data linting:** First 5 KaizenML rules as Inngest cron jobs (orphan nodes, missing embeddings, sync drift, empty SubConcepts, broken relationships)
- **Golden dataset:** 25 manually verified items for regression testing — nightly pipeline run, alert on quality drop > 0.05
- **Generation history:** `/generate/history` — past sessions with metrics, timing, costs

**Phase 2 Exit Criteria:**
- Critic Agent auto-handles ≥ 60% of generated items
- Faculty has generated and approved ≥ 50 items from real curriculum content
- At least one bulk generation run of 20+ questions completes successfully
- Conversational refinement works end-to-end
- Zero broken dual-write sync states
- TEACHES_VERIFIED workflow operational

---

## PHASE 3: "The Coverage Map"

**Weeks 17–24 · Consumer: Course Director + Associate Dean · Proves: Institutional intelligence**

Journey OS stops being "a better question generator" and becomes "an operating system." The coverage chain is live and queryable. The knowledge graph delivers insights no question bank can.

---

### Week 17–18: Multi-Course Ingestion

Scale from one course to the full curriculum:

- Full Inngest ingestion pipeline (7 stages, production-grade): UPLOAD → PARSE → CLEAN → CHUNK → EMBED → EXTRACT → DUAL-WRITE → REVIEW QUEUE
- Parse all 9 MSM syllabi through the 6-type parser taxonomy
- SubConcept dedup at 0.92 cosine threshold (critical now — same concepts appear across Pharmacology, Pathology, and Organ Systems)
- SLO extraction: Haiku identifies session-level learning objectives → SLO nodes in Neo4j
- SLO → ILO FULFILLS linking (HUMAN_APPROVED authority — faculty reviews)
- Framework alignment at scale: all SubConcepts tagged to USMLE_System, USMLE_Discipline, and ACGME_Domain

**Exit Criteria:**
- All 9 MSM syllabi ingested
- SubConcepts deduplicated across courses
- SLO → ILO FULFILLS relationships created and faculty-reviewed

---

### Week 19–20: USMLE Gap Detection

The signature analytical capability:

- 16×7 heatmap (USMLE_System × USMLE_Discipline) computed at query time via double-match Cypher (~10-50ms with indexes)
- Priority scoring: `(1 - coverage_pct) × usmle_weight × centrality_score × recency_decay`
- PageRank + betweenness centrality on SubConcept graph (weekly Inngest recalculation)
- Gap-to-generation closed loop: click underserved cell → pre-fill workbench with context → generate
- USMLE_Topic drill-down: click System cell → see which specific Topics have zero SubConcepts (true blind spots)
- Nightly gap scan: Inngest `journey/gap.scan` recomputes all 112 cells, identifies cells below 0.3 threshold, generates notification cards

**Exit Criteria:**
- Heatmap renders with real data from ingested syllabi
- Faculty can click a gap cell and generate questions to fill it
- Gap alerts appear on dashboard

---

### Week 21–22: Faculty Dashboard + Coverage Visualization

Build the institutional intelligence layer:

- Faculty dashboard (`/dashboard`): activity feed, generation stats, gap alerts, quick actions, course overview, KPI strip
- CoverageMapView (D3): force-directed SubConcept graph colored by coverage level, click gap node → generate
- Course detail view (`/courses/[id]`): structure, outcomes, uploaded content, coverage status
- Full design system applied: Cream `#f5f3ef` background, Parchment `#faf9f6` panels, White `#ffffff` content focus, Lora headings, Source Sans body, collapsible sidebar (72px → 240px), white header with frosted glass on scroll (R-039)

**Exit Criteria:**
- Dashboard shows real-time coverage state
- Coverage map visualizes concept graph with gaps highlighted
- Design system consistently applied across all screens

---

### Week 23–24: LCME Compliance MVP

The accreditation value proposition:

- LCME Dashboard: 12-row heatmap (one per Standard), elements colored by coverage level (green ≥ 3 ILOs with assessment, yellow 1–2, red 0)
- Coverage chain query live: `LCME_Element ←[:ADDRESSES_LCME]← ILO ←[:FULFILLS]← SLO ←[:ASSESSES]← AssessmentItem`
- Evidence export: CSV + structured data per element (which ILOs, which courses, how many items, which assessments)
- Not full narrative report generation yet — raw evidence is the immediate value

**Phase 3 Exit Criteria:**
- All 9 MSM syllabi ingested, concepts extracted and deduplicated
- USMLE heatmap identifies real gaps with real data
- Faculty can click a gap and generate questions to fill it
- LCME dashboard shows coverage status for all 12 standards / 93 elements
- Associate Dean can export evidence for any LCME element in under 60 seconds

---

## PHASE 4: "The Item Bank + Exam Assembly"

**Weeks 25–32 · Consumer: Faculty + Course Director · Proves: Assessment instruments, not just questions**

Faculty assembles a real exam from the item bank. The first real exam using Journey OS-generated questions is administered.

---

### Week 25–26: Item Bank + Management

- Item bank view (`/items`): filterable by course, Bloom level, USMLE system, difficulty, status, date
- Rich item editor: edit vignette/stem/options with re-validation on save
- Tag management UI
- Per-item analytics page (generation metadata, Critic scores, Toulmin argument, source provenance)
- Legacy import pipeline: bring in existing MSM exam questions → embed → tag → dual-write

### Week 27–28: Exam Assembly

- Exam builder (`/exams/new`): set constraints (N items, Bloom distribution, USMLE coverage, time budget)
- MIP solver (Python FastAPI service, PuLP/OR-Tools): constraint satisfaction from approved item pool
- Exam preview, manual swap, finalize
- Basic exam delivery: timed assessment with answer recording (standardized, not adaptive)
- Response data starts accumulating (feeds Phase 5)

### Week 29–30: LOD Enrichment + StandardTerm

- StandardTerm nodes: UMLS API calls for CUI codes, SNOMED, MeSH lookups
- `SubConcept -[:GROUNDED_IN]-> StandardTerm` relationships
- `StandardTerm -[:SAME_AS]-> StandardTerm` (cross-ontology)
- Convenience properties preserved on SubConcept (umls_cui, lod_enriched)
- Enriches search, dedup quality, and interoperability

### Week 31–32: Admin + Onboarding + Notifications

- SuperAdmin: institution management, waitlist flow
- Institutional Admin: user management, course management, framework settings
- Notifications: in-app via Supabase `notifications` table + Socket.io real-time push (generation complete, review needed, data lint alerts, gap alerts)
- Faculty onboarding wizard: upload syllabus → watch extraction → generate first question → dashboard tour
- Data integrity admin view

**Phase 4 Exit Criteria:**
- ≥ 200 approved items in the bank across multiple courses
- At least one real exam assembled and administered using the MIP solver
- Legacy MSM questions imported and tagged
- Full admin flow operational
- LOD enrichment running on all SubConcepts

---

## PHASE 5: "The Student Experience"

**Weeks 33–48 · Consumer: Students + Advisors · Proves: Closed loop**

Students log in, practice against curriculum-aligned questions, and see their mastery evolve. Advisors get early-warning alerts. The full thesis is proven.

---

### Week 33–34: Student App Foundation

- Student auth + onboarding (student role in Supabase Auth)
- Student dashboard: mastery overview, upcoming exams, practice launcher
- Practice mode: select course/topic/weak areas → timed session → item delivery → answer recording
- Student app route structure: `/dashboard`, `/practice`, `/practice/session`, `/practice/review`, `/practice/history`, `/courses`

### Week 35–36: Mastery Tracking (BKT v1)

- ConceptMastery nodes in Neo4j: `Student -[:HAS_MASTERY]-> ConceptMastery -[:FOR_CONCEPT]-> SubConcept`
- AttemptRecord linked list: `AttemptRecord -[:ON_ITEM]-> AssessmentItem`, `AttemptRecord -[:NEXT]-> AttemptRecord`
- BKT with domain-specific defaults: P(L₀) = 0.1, P(T) = 0.3, P(G) = 0.25, P(S) = 0.1 (calibrate as data accumulates)
- Event-driven mastery updates < 500ms: answer submitted → Supabase Realtime trigger → parallel consumers (Neo4j BKT update + dashboard stats update)
- Post-question review: correct answer, ECD explanation, misconception feedback
- USMLE mastery heatmap (student-facing)

### Week 37–38: Practice Intelligence

- Weak areas view: top N SubConcepts with lowest mastery + linked practice sets
- Practice history: past sessions, trend charts, mastery trajectory
- "Why Am I Struggling?" drill-down: trace from failing mastery nodes backward through PREREQUISITE_OF to find foundational gaps
- Exam prep mode: simulated exam using MIP solver with student-specific constraints (weight weak areas)

### Week 39–40: IRT Calibration + Adaptive Foundation

- Python FastAPI service (`services/python-api/`): IRT parameter estimation (2PL: difficulty, discrimination)
- Calibrate from accumulated response data (need ~100+ responses per item minimum)
- Item lifecycle promotion: Uncalibrated → Provisional → Calibrated (based on response count and parameter stability)
- Fisher Information item selection: choose items maximizing information gain at student's current θ, weighted by centrality
- Agent Working Memory: session-scoped + graph-scoped

### Week 41–42: Advisor Dashboard + At-Risk Alerts

- Advisor dashboard: cohort overview, per-student mastery heatmaps
- At-risk detection: flag students whose mastery trajectory predicts below-threshold performance 2–4 weeks before exam
- Root-cause analysis: trace backward through PREREQUISITE_OF to find foundational gaps (not just surface failures)
- Intervention recommendations: specific SubConcepts + linked practice sets

### Week 43–44: LCME Compliance Reporting (Full)

- Narrative report generation: Claude generates compliance narratives from graph evidence
- PDF/DOCX report builder with programmatic evidence citations
- Scope limitation documented: covers curriculum-to-assessment chain, not student surveys or clinical site agreements

### Week 45–48: Hardening + Expansion

- E2E tests: full user flows for all 5 persona types
- Performance benchmarks against architecture targets (< 45s full generation, < 500ms mastery update)
- Expand beyond pilot to 3–5 courses
- GNN spike: prototype hidden prerequisite prediction (Tier 3 preview)
- Domain embedding fine-tuning evaluation

**Phase 5 Exit Criteria:**
- Students actively practicing with concept-level mastery tracking
- BKT updating in real-time, mastery trends visible
- At least one at-risk student flagged 2+ weeks before exam
- Advisor can see root-cause gaps and recommend targeted practice
- ≥ 500 items with IRT parameters
- Full LCME compliance reports generatable

---

## Timeline Summary

| Phase | Weeks | Consumer Moment | Proves | Exit Gate |
|---|---|---|---|---|
| 1: Question Factory | 1–8 | Faculty generates first real question | Generation quality | 1 question from real syllabus |
| 2: Quality Engine | 9–16 | Faculty trusts output for real exams | Quality at scale | ≥ 50 approved, 60% auto-handled |
| 3: Coverage Map | 17–24 | Course Directors see gaps, LCME evidence in minutes | Institutional intelligence | 9 syllabi ingested, heatmap live |
| 4: Item Bank + Exams | 25–32 | First real exam assembled and administered | Assessment instruments | ≥ 200 items, exam delivered |
| 5: Student Experience | 33–48 | Students practice with mastery tracking | Closed loop | At-risk flagging works |

---

## What's Deliberately Deferred Beyond Week 48

These are real capabilities from Architecture v10.0 that don't make the "quickest path to value" cut:

- **Topic modeling (BERTopic)** — Tier 3. Faculty manual selection works. Unsupervised thematic analysis is enrichment, not core.
- **GNN** for hidden prerequisites, gap prediction, student risk classification — Tier 3. BKT + rules get 80% of the value.
- **Multi-institution / Consortium** — Tier 3. Prove at MSM first. Deep hierarchy supports it architecturally.
- **ONNX quantization** — Premature optimization. Standard API latency is fine for pilot.
- **Fine-tuned domain embeddings** — Voyage general embeddings are sufficient to prove concept.
- **Hetionet integration** — Selective 2-hop enrichment can wait. LOD enrichment in Phase 4 covers the core need.
- **A2A (Agent-to-Agent) protocol** — Future multi-agent coordination. Not needed for single-pipeline architecture.
- **Full 78-screen design system** — Build screens as needed per phase. Don't front-load 70 screens nobody uses yet.

---

## Gap Closure Specifications

Every open question from the Gap Analysis v2.0 is resolved here with a concrete specification and a phase assignment. Nothing is left as "TBD."

---

### Gap 1: USMLE_Topic Seed Data (~200 nodes, no JSON file)

**Phase:** 1, Week 1–2 (part of seeding)
**Resolution:** Extract from the USMLE Step 1 Content Description and Outline PDF. This is a one-time data entry task, not a pipeline.

**Approach:**
1. Download the current USMLE Step 1 Content Description from NBME/USMLE.org
2. Use Claude to extract the granular content-outline entries under each of the 16 organ systems
3. Produce `usmle_topics.json` matching the existing seed file pattern:
```json
{
  "topics": [
    { "id": "usmle-topic-cv-001", "system_id": "usmle-sys-cardiovascular", "name": "Congestive heart failure", "outline_section": "1.1.1" },
    { "id": "usmle-topic-cv-002", "system_id": "usmle-sys-cardiovascular", "name": "Ischemic heart disease", "outline_section": "1.1.2" }
  ]
}
```
4. Seed via `services/kg-seeder/` with `USMLE_System -[:HAS_TOPIC]-> USMLE_Topic` relationships
5. Validation: `MATCH (n:USMLE_Topic) RETURN count(n)` → ~200 (±10%)

**Owner:** Pre-build data preparation task. Can be done before any code is written.

---

### Gap 2: PREREQUISITE_OF Edge Creation Methodology

**Phase:** 2/3 boundary (Week 17, during multi-course ingestion)
**Resolution:** Three-stage approach, progressively more accurate.

**Stage A — AI-inferred (Phase 2, automatic):**
When Haiku extracts SubConcepts during ingestion, it also identifies prerequisite relationships by analyzing:
- Explicit syllabus language ("requires prior knowledge of...", "builds on...")
- Bloom level sequencing (lower Bloom concepts in earlier sessions → higher Bloom in later sessions for the same topic family)
- Course prerequisite chains (if Course A is prerequisite for Course B, SubConcepts from A that appear in B's context are candidates)

Creates `PREREQUISITE_OF` edges with `authority: "AI_VERIFIED"`, `confidence: 0.0-1.0`, `source: "extraction"`.

**Stage B — Faculty curation (Phase 3, review UI):**
During the TEACHES_VERIFIED review workflow, faculty also see suggested prerequisite relationships and can confirm, reject, or add new ones. Confirmed edges upgrade to `authority: "HUMAN_APPROVED"`.

A simple UI element in the concept review screen: "This concept depends on: [suggested prerequisites]. Correct? Add others?"

**Stage C — Graph inference (Phase 5, automatic):**
Once student response data exists, analyze response patterns: if students who fail Concept X also consistently fail Concept Y, and X appears earlier in the curriculum, infer a prerequisite relationship. Validate with faculty.

**The honest truth:** Stage A gets you 60-70% of prerequisites. Stage B gets you to 85%. Stage C is the optimization layer. The system works without perfect prerequisites — it just works *better* with them.

---

### Gap 3: Pre-Reconciliation Seed Document Validation

**Phase:** 1, Week 1 (before seeding)
**Resolution:** Don't use the 4,079-line seed document as-is. Use it as a reference while writing new seed scripts from NODE_REGISTRY v1.0.

**Approach:**
1. The `services/kg-seeder/` scripts are written from scratch using NODE_REGISTRY v1.0 as the schema authority
2. The 4,079-line document serves as a content reference (what institutional data, what course names, what ILO text)
3. Every label, relationship type, and property name comes from NODE_REGISTRY, not the old seed document
4. A validation script (`pnpm kg:validate`) runs the SEED_VALIDATION_SPEC queries after each phase

**Cost:** 2-4 hours to audit the old document for content, zero risk of stale schema creeping in.

---

### Gap 4: Lecture / PPTX Ingestion

**Phase:** 3, Week 17–18 (during multi-course ingestion)
**Resolution:** PPTX ingestion is a variant of the syllabus pipeline, not a separate system.

**Approach:**
1. PPTX parser extracts: slide text, speaker notes, slide titles, embedded images (OCR if text-in-image)
2. Each slide becomes a ContentChunk with `source_type: "slide"`, `chunk_index` = slide number, `heading_context` = slide title
3. Speaker notes concatenated with slide text for the chunk body
4. If a slide has minimal text but a complex diagram, flag for manual review (don't try to extract concepts from images in Phase 3)
5. Same downstream pipeline: embed → extract SubConcepts → dual-write → TEACHES relationships

**Libraries:** `python-pptx` for extraction (in `services/kg-seeder/` or a new `services/pptx-parser/`)

**Audio/video transcripts:** Deferred beyond Phase 5. The architecture supports `source_type: "transcript"` but the transcription pipeline (Whisper or similar) is not in scope.

**Why this works in Phase 3 and not Phase 1:** Phase 1 needs ONE course with ONE syllabus to prove generation quality. Lecture slides add breadth, not proof-of-concept.

---

### Gap 5: Conversational Refinement Mechanics

**Phase:** 2, Week 11–12
**Resolution:** Map faculty chat intents to specific pipeline node re-invocations.

**Mechanism:**
When faculty types a modification request during or after generation, the system:

1. **Intent classification** (Haiku, < 200ms): Classify the request into one of:
   - `modify_vignette` → re-invoke `vignette_builder` with constraints
   - `modify_stem` → re-invoke `stem_writer`
   - `modify_options` → re-invoke `distractor_generator`
   - `change_difficulty` → re-invoke from `context_compiler` with new Bloom target
   - `change_topic` → re-invoke from `init` (effectively new generation)
   - `accept` / `reject` → route to `graph_writer`

2. **Constraint injection:** The classified intent becomes a constraint object injected into the re-invoked node's prompt. Example:
   ```json
   {
     "refinement": "modify_vignette",
     "constraint": "Shorten to under 100 words. Keep the same clinical scenario.",
     "preserve": ["stem", "options"]
   }
   ```

3. **Partial re-run:** Only the targeted node and everything downstream re-runs. Nodes upstream of the modification point keep their outputs. After the targeted node, `validator` and `critic_agent` re-run (via the existing `revalidate` review node).

4. **AG-UI event:** STATE_DELTA patches update only the changed fields in the WorkbenchState. The right panel re-renders the modified elements.

**Example flow:**
```
Faculty: "Make the vignette about a pediatric patient instead"
→ Intent: modify_vignette
→ Re-invoke vignette_builder with constraint: "Patient is a 7-year-old child"
→ vignette_builder produces new vignette (streamed)
→ stem_writer re-runs (stem may need adjustment for pediatric context)
→ distractor_generator re-runs
→ validator re-runs
→ Question preview updates via STATE_DELTA
```

---

### Gap 6: TaskShell Template Design (10–15 templates)

**Phase:** 2, Week 13–14
**Resolution:** Here are the 12 TaskShell templates to implement. Each defines a question archetype with generation constraints.

| # | TaskShell Name | Bloom Range | Question Pattern | Distractor Strategy |
|---|---|---|---|---|
| 1 | Clinical Vignette – Diagnosis | Analyze-Evaluate | Vignette → "most likely diagnosis?" | Common differentials for presenting symptoms |
| 2 | Clinical Vignette – Next Step | Apply-Analyze | Vignette → "most appropriate next step?" | Premature treatments, wrong test orders |
| 3 | Clinical Vignette – Mechanism | Understand-Apply | Vignette → "mechanism of action?" | Related but different mechanisms |
| 4 | Pharmacology – Drug Selection | Apply-Analyze | Clinical scenario → "most appropriate drug?" | Same class wrong indication, right class wrong drug |
| 5 | Pharmacology – Adverse Effect | Remember-Understand | Drug exposure → "most likely adverse effect?" | Effects of related drugs |
| 6 | Pathophysiology – Mechanism | Understand-Analyze | Normal/abnormal process → "underlying mechanism?" | Mechanisms of related conditions |
| 7 | Anatomy – Structure ID | Remember-Apply | Clinical scenario → "structure most likely affected?" | Adjacent structures, similar innervation |
| 8 | Microbiology – Organism ID | Apply-Analyze | Infection presentation → "most likely organism?" | Organisms causing similar syndromes |
| 9 | Biostatistics – Study Design | Analyze-Evaluate | Study description → "greatest threat to validity?" | Common statistical misapplications |
| 10 | Ethics – Best Action | Evaluate | Ethical dilemma → "most appropriate action?" | Actions that violate one principle while honoring another |
| 11 | Preventive Medicine | Apply | Patient demographics → "most appropriate screening?" | Wrong age group, wrong risk factor |
| 12 | Lab Interpretation | Apply-Analyze | Lab values + scenario → "most likely condition?" | Conditions with overlapping lab patterns |

**Properties per TaskShell node:**
```json
{
  "id": "ts-clinical-dx",
  "name": "Clinical Vignette – Diagnosis",
  "bloom_range": ["Analyze", "Evaluate"],
  "vignette_required": true,
  "option_count": 5,
  "distractor_strategy": "differential_diagnosis",
  "clinical_setting_options": ["ED", "outpatient", "inpatient", "ICU"],
  "constraints": {
    "vignette_word_range": [120, 200],
    "stem_ends_with": "most likely diagnosis"
  }
}
```

---

### Gap 7: Critic Agent Threshold Calibration Strategy

**Phase:** 2, Week 9–10 (built into quality pipeline)
**Resolution:** Ship with the specified thresholds as initial values. Calibrate empirically during Phase 2.

**Calibration protocol:**
1. Generate 50 questions across 5 TaskShell types during Week 9-10 development
2. Record Critic Agent scores for all 6 metrics on each item
3. Compute distribution: mean, median, standard deviation, min, max per metric
4. Adjust thresholds based on distributions:
   - If mean Faithfulness is 0.97 with σ=0.02, a 0.9 threshold is too permissive → tighten to 0.93
   - If mean Distractor Plausibility is 0.55 with σ=0.15, a 0.6 threshold rejects 60% → loosen to 0.45
5. Store thresholds in Supabase `system_settings` table (not hardcoded) so they can be adjusted without deployment
6. Log all Critic scores to `generation_logs` for ongoing monitoring
7. Re-calibrate monthly during Phase 3-4 as item count grows

**Phase A reality:** Initial thresholds will be wrong. That's fine. The routing logic (auto_approve / auto_reject / faculty_review) means the worst case is "too many items go to faculty review." That's safe — it just slows throughput. Over-rejection is preferable to under-rejection in medical education.

---

### Gap 8: Self-Correction Loop Mechanism

**Phase:** 2, Week 9–10
**Resolution:** Three escalation strategies, not just "try again."

**On validator failure:**
1. **Attempt 1:** Re-invoke the failing node with the validation error message injected into the prompt:
   ```
   "Your previous output failed validation rule NBME-07 (stem contains absolute terms). 
    The problematic text was: '...always causes...'. 
    Regenerate the stem avoiding absolute terms like 'always', 'never', 'all', 'none'."
   ```
2. **Attempt 2:** If same rule fails again, escalate the model (Haiku → Sonnet, or Sonnet → Opus for the specific failing node) with the same error-injected prompt.
3. **After 2 failures:** Route to `faculty_review` with the validation report attached. Don't retry indefinitely.

**On Critic Agent rejection:**
1. **Attempt 1:** Re-invoke from `context_compiler` with expanded context (increase token budget from 4,000 to 6,000) and the specific low-scoring metric identified:
   ```
   "Previous generation scored 0.72 on Faithfulness. Ensure all clinical details 
    in the vignette are directly supported by the source material."
   ```
2. **Attempt 2:** Re-invoke from `init` with a different SubConcept from the same USMLE cell (generate a different question, not the same one again).
3. **After 2 failures:** Route to `faculty_review` with all attempts and scores visible.

**Key principle:** Every retry changes something — the prompt, the model, the context budget, or the target concept. Identical retries are forbidden.

---

### Gap 9: MIP Solver Infeasibility Handling

**Phase:** 4, Week 27–28
**Resolution:** Progressive constraint relaxation with transparency.

**When the solver can't satisfy all constraints:**
1. **Detect infeasibility** — PuLP returns `infeasible` status
2. **Relax in priority order** (least important first):
   - Time budget ±10%
   - Bloom distribution ±1 item per level
   - USMLE system coverage: allow 0 items in systems with < 3 approved items total
   - Total items: ±2 from target
3. **Report relaxations to faculty:** "This exam couldn't meet all constraints. I relaxed: Bloom distribution (-1 Analyze, +1 Apply) and excluded Hematology (only 2 items available). Approve or adjust?"
4. **Never relax:** Minimum 1 item per Bloom level represented. No duplicate items. No items the student has already seen (if specified).

---

### Gap 10: LCME Narrative Generation Strategy

**Phase:** 5, Week 43–44
**Resolution:** Template-driven generation with graph data injection, not open-ended narrative.

**Approach:**
1. **Narrative templates per LCME standard** — pre-written narrative structures with placeholders:
   ```
   "Standard {{standard.number}}: {{standard.name}}

   Element {{element.number}} ({{element.name}}) is addressed through 
   {{ilo_count}} institutional learning objectives across {{course_count}} courses.
   
   Specifically, {{top_ilo.description}} ({{top_ilo.course_code}}) demonstrates 
   coverage through {{item_count}} validated assessment items spanning 
   {{bloom_levels}} cognitive levels..."
   ```
2. **Graph traversal populates data:** The coverage chain query extracts ILOs, courses, item counts, Bloom distributions, concept coverage per element
3. **Claude (Sonnet) generates connecting narrative:** Takes the structured data + template and produces readable compliance prose. This is a summarization task, not a creative writing task.
4. **Faculty review required:** Generated narratives are drafts. Faculty edit before submission.

**Scope limitation (documented explicitly in the UI):** "Journey OS generates evidence for the curriculum-to-assessment chain (Standards 6-8 primarily). Student survey data, teaching evaluations, clinical site agreements, and administrative policies require separate evidence sources."

---

### Gap 11: Generation Prompt Templates

**Phase:** 1, Week 5–6 (built as part of pipeline nodes)
**Resolution:** Each pipeline node gets a documented prompt template with system prompt, user prompt structure, and output schema.

**Example — vignette_builder:**

*System prompt:*
```
You are a medical education assessment specialist generating NBME-style clinical 
vignettes for Morehouse School of Medicine. You write vignettes that are:
- Clinically accurate and evidence-based
- 120-200 words
- Include age, sex, relevant history, presenting complaint, key findings
- Set in a specific clinical context (ED, clinic, hospital, etc.)
- Written in present tense, third person
- Free of cueing (don't hint at the diagnosis in the vignette)

You ONLY use facts from the provided source material. Never invent clinical details 
not supported by the source context.
```

*User prompt structure:*
```
Generate a clinical vignette for this assessment context:

TARGET CONCEPT: {{subconcept.name}} ({{subconcept.description}})
BLOOM LEVEL: {{target_bloom}}
TASK SHELL: {{taskshell.name}}
CLINICAL SETTING: {{taskshell.clinical_setting}}

SOURCE MATERIAL:
{{context_chunks}}  // 4,000 token budget, from context_compiler

CONSTRAINTS:
{{refinement_constraints}}  // Empty on first generation, populated on refinement
```

*Output schema (structured output):*
```json
{
  "vignette_text": "string (120-200 words)",
  "clinical_setting": "string",
  "patient_demographics": { "age": "number", "sex": "string" },
  "key_findings": ["string"],
  "source_chunk_ids": ["string"]  // provenance tracking
}
```

**Deliverable:** A `prompts/` directory in `apps/server/` with one file per pipeline node containing the system prompt, user prompt template, output schema, and 2-3 few-shot examples. These are authored during Week 5-6 as part of building each node.

---

### Gap 12: Entity Embedding Pipeline (beyond content chunks)

**Phase:** Spread across phases as entities are created
**Resolution:** Every entity with a text representation gets embedded at creation time.

| Entity | When Embedded | Phase | Embedding Source Text |
|---|---|---|---|
| ContentChunk | At ingestion (CHUNK stage) | 1 | `chunk.text` |
| SubConcept | At extraction | 1 | `subconcept.name + ": " + subconcept.description` |
| SLO | At extraction | 3 | `slo.text` |
| AssessmentItem | At graph_writer | 1 | `item.stem + " " + item.vignette` (combined) |

All use the same model (Voyage AI voyage-large-2, 1024-dim) and storage pattern (dedicated `*_embeddings` table with HNSW index in Supabase).

The SubConcept embedding is critical for the 0.92 dedup threshold. The question embedding is critical for the 0.85/0.95 dedup tiers. These must be generated as part of the creation pipeline, not as a separate batch job.

---

### Gap 13: Parser Quality Testing Strategy

**Phase:** 1, Week 3–4 (built into ingestion)
**Resolution:** Golden parse test for each syllabus type.

**Approach:**
1. For the Phase 1 syllabus (MEDI 531), manually annotate a "golden parse" — what the correct output should be:
   - Expected number of content chunks (±10%)
   - 5-10 expected SubConcepts that MUST be extracted
   - 3-5 expected framework mappings that MUST be correct
2. Run the parser → compare against golden parse
3. If extraction misses > 20% of expected SubConcepts, the parser needs work before proceeding
4. Store the golden parse in `services/kg-seeder/fixtures/golden-parse-medi531.json`
5. In Phase 3 (multi-course), create golden parses for 2-3 additional syllabus types before bulk ingestion

**This is the "garbage in, garbage out" firewall.** If parsing quality is bad, stop and fix it before generating questions from bad data.

---

## Critical Path Risks

**Risk 1: Syllabus parsing quality.** If MSM syllabi are structurally messy, the Week 3–4 parser could take longer. *Mitigation:* Start with the cleanest syllabus (Type 3 / MEDI 611 if applicable). Don't try all 9 in Phase 1.

**Risk 2: Generation quality doesn't impress faculty.** If first questions feel generic or medically inaccurate, trust collapses before Phase 2. *Mitigation:* Invest heavily in context_compiler quality. The RAG context is everything — garbage context in, garbage questions out. Test with a real faculty member in Week 8, not Week 16.

**Risk 3: CopilotKit + LangGraph.js integration friction.** Relatively new integration pattern. AG-UI + SSE plumbing could have rough edges. *Mitigation:* Week 1–2 spike validates this before anything depends on it. If it fails, fallback is custom chat UI with SSE (more code, same capability).

**Risk 4: Dual-write sync failures.** Neo4j Aura free tier has latency constraints. Silent failures = graph/Supabase divergence. *Mitigation:* sync_status column from day one + data linter in Phase 2 catches drift.

**Risk 5: Faculty adoption.** The biggest real risk isn't technical. If faculty don't see this as saving them time, the project dies regardless of architecture quality. *Mitigation:* Phase 1 delivers value to ONE real faculty member. Get their feedback before scaling.

**Risk 6: Solo build reality.** Full-time job + CLE + SAFE GA. At 15–20 hours/week, 48 weeks = 720–960 hours. Phase 1 alone (8 weeks × 15–20 hours) = 120–160 hours. That's tight but achievable if scope stays disciplined.

---

## The 6-Week Minimum Viable Demo (If Time Is Scarce)

If even Phase 1 at 8 weeks is too ambitious:

| Week | Build | Skip |
|---|---|---|
| 1 | Monorepo + Supabase DDL + Neo4j seed (Layers 1–2) + CopilotKit spike | Docker Compose, full CI |
| 2 | Auth + Express API + DualWriteService | Full CRUD, admin screens |
| 3 | Manual concept seed for ONE course (skip ingestion entirely) | Parsers, chunking, embeddings |
| 4–5 | LangGraph.js 4-node pipeline (context_compiler → generate → validate → save) | 10 remaining nodes |
| 6 | CopilotKit workbench + basic question bank | Design system, dashboard |

Faculty can't upload syllabi. But they can generate questions from pre-seeded graph data, review them, and see the value proposition: *"AI generates NBME-quality questions grounded in your curriculum's knowledge graph."*

Content ingestion becomes Sprint 2.

---

## Source of Truth Hierarchy

1. **NODE_REGISTRY v1.0** — labels, relationships, properties
2. **SUPABASE_DDL v1.0** — tables, columns, indexes
3. **Architecture v10.0** — system design, pipeline, data flow
4. **Gap Analysis v2.0** — subsystem readiness, open questions
5. **This document** — build sequence, phase scope, exit criteria

When documents contradict, lower numbers win.

---

*Sequenced by value, not by layer. Every phase ends with a real person using a real tool.*