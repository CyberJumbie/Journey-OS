Role Definitions
JWT claim role values and what each role can access



Role
Who they are
Access scope
Faculty
faculty
Basic science or clinical faculty generating items for their courses
Own items, own courses, workbench, item bank, history, batches, review queue
Course Director
course_director
Senior faculty with admin control over courses (includes all faculty access)
All faculty access + course management, concept verification, SLO→ILO linking, LCME drill-down
Student
student
M1/M2 medical student
Own practice sessions, own mastery, own exam sessions, student dashboard
Admin
admin
Platform superadmin — institution-wide access
All screens, all institutions, user invite/deactivate, system health, LCME export, UMLS, lint, data integrity
Institutional Admin
institution_admin
Department chair / Associate Dean scoped to one institution
Own institution data: all courses, all faculty, institutional analytics, LCME compliance, accreditation
Advisor
advisor
Academic advisor — monitors student cohort (Phase 5)
Cohort overview, per-student mastery, at-risk detection, narrative report generation



1. Authentication & Onboarding
Entry points and first-run setup flows



1.1  Login   Phase 1
Route: /login
Phase 1
Public (Unauthenticated)
Universal entry point for all roles. Email + password authentication via Supabase Auth. On success, JWT issued with role and institution_id claims. User redirected to role-appropriate home screen.
Key Functions
Email + password sign-in via Supabase signInWithPassword()
Role-based redirect: faculty→/dashboard, student→/student-dashboard, admin→/admin, advisor→/dashboard
Magic link support for first-time invited users
Forgot password → Supabase reset email flow
Note: Phase 1: faculty only. Student + admin login activated in Phases 4–5.


1.2  Faculty Registration   Phase 1
Route: /register/faculty
Phase 1
Public (Unauthenticated)
Self-registration for faculty. Collects name, email, department, title. Creates Supabase user + profile. Sets role = faculty.
Key Functions
Collects name, email, password, department (15 MSM options), title
Creates auth.users + user_profiles rows; sets JWT role = faculty
Redirects to /onboarding on success
Note: Superseded by admin invite workflow (Phase 4) but remains as backup.


1.3  Faculty Onboarding Wizard   Phase 4
Route: /onboarding
Phase 4
Faculty
6-step first-login wizard shown when onboarding_completed = false. Guides from profile setup through first syllabus upload and first question. Progress persisted server-side — refresh resumes from last saved step.
Key Functions
Step 1: confirm display name, title, department
Step 2: select course (from admin-configured list)
Step 3: drag-drop syllabus upload with live Inngest pipeline progress
Step 4: review 5 extracted SubConcepts
Step 5: pre-filled workbench — auto-sends first generation message
Step 6: celebration screen + link to dashboard
Steps 1–2 mandatory; steps 3–5 have "Skip for now"
PATCH /users/me/onboarding persists step on every advance


1.4  Student Registration   Phase 5
Route: /register/student
Phase 5
Public (Unauthenticated)
Student self-registration. Collects student ID, year level (M1/M2), course enrollments. Sets role = student.
Key Functions
Name, email, password, student_id, year_level, enrolled courses (multi-select)
Sets role = student in JWT
Redirects to /onboarding/student
Note: Phase 5 only.


1.5  Student Onboarding   Phase 5
Route: /onboarding/student
Phase 5
Student
Brief student onboarding: confirms enrollment, sets practice preferences, explains BKT mastery tracking with a worked example.
Key Functions
Confirms enrolled courses and year level
Sets daily practice goal (minutes)
Explains BKT mastery system
Redirects to /student-dashboard on completion
Note: Phase 5 only.



2. Faculty Screens
Phases 1–4: question generation, review, and course management




2.1  Dashboard & Navigation



2.1.1  Faculty Dashboard   Phase 3
Route: /dashboard
Phase 3
Faculty + Course Dir
Primary home screen. Real-time KPIs (items, approval rate, coverage), sparkline trends, per-course coverage sorted ascending (lowest = shown first), top-5 gap alerts, and recent activity feed. All data in one GET /dashboard call (< 500ms target).
Key Functions
KPI tiles: Total Items, Approved Items, Approval Rate, Coverage Score — each with 7-day sparkline
Course cards sorted by coverage % ascending (most at-risk first)
"High-priority gaps" callout → /analytics/gaps
Recent activity feed (last 10 generation events)
60-second polling — no socket needed for dashboard
Note: Mock data in Phase 1. Real data wired in Phase 3 (P3-011).


2.1.2  Course List   Phase 1
Route: /courses
Phase 1
Faculty + Course Dir
List of courses the logged-in faculty member is assigned to. Entry point for per-course workflows.
Key Functions
Filter by status: active / archived / draft; search by name or code
Coverage % badge (green ≥ 80%, amber 50–79%, red < 50%)
Quick-action buttons: Upload Syllabus, View Dashboard per course
Note: Coverage = 0 until Phase 3 ingestion. student_count = 0 until Phase 5.


2.1.3  Course Detail Dashboard   Phase 3
Route: /courses/:id
Phase 3
Faculty + Course Dir
Per-course view: coverage gauge, weekly syllabus breakdown with topic lists and question counts vs targets, recent question activity.
Key Functions
Coverage percentage gauge (this course only)
Per-week: topics, question_count vs target_count (default target = 5/week), coverage badge (green/amber/red)
"Generate for this week" → /workbench?courseId=X&weekNumber=N
Link to USMLE heatmap filtered to this course



2.2  Syllabus & Lecture Ingestion



2.2.1  Upload Syllabus   Phase 1
Route: /courses/:id/upload-syllabus
Phase 1
Faculty + Course Dir
Drag-and-drop upload for PDF/DOCX syllabi. Stores file in Supabase Storage (WORM). Fires Inngest ingestion pipeline. Phase 3 adds PPTX lecture deck support.
Key Functions
Drag-and-drop + file picker; accepts PDF, DOCX (Phase 1), adds PPTX (Phase 3)
File size: 50MB PDF/DOCX, 100MB PPTX
On upload: creates uploads row, fires journey/ingest.requested
Redirects to /courses/:id/processing
Note: Phase 1: synchronous pipeline. Phase 3: async 7-stage Inngest pipeline.


2.2.2  Upload Lecture Slides   Phase 3
Route: /courses/:id/upload-lecture
Phase 3
Faculty + Course Dir
PPTX-only upload for lecture decks. Uses same Inngest pipeline with PptxParser. Extracts per-slide text + speaker notes.
Key Functions
PPTX only (PDF redirects to upload-syllabus)
Slide text + speaker notes extracted with [Slide N] markers
Image-only slides skipped with warning
Same processing status screen as syllabus
Note: Phase 3 only (P3-002).


2.2.3  Processing Status   Phase 1
Route: /courses/:id/processing
Phase 1
Faculty + Course Dir
Live pipeline progress shown while file is being ingested. Polls every 3 seconds. Shows all 7 stages of the Inngest pipeline.
Key Functions
Stage tracker: validate_file → parse → chunk → classify → embed → extract_concepts → dual_write
Progress bar (0–100%) per stage
Retry button on failure; error message display
On completion: "Concept Review" CTA → /courses/:id/review-mapping


2.2.4  Review Syllabus Mapping   Phase 1
Route: /courses/:id/review-mapping
Phase 1
Faculty + Course Dir
Post-ingestion concept review. Faculty approves or rejects AI-extracted topics before they enter the knowledge graph as TEACHES edges.
Key Functions
AI-extracted topics with confidence scores (0–100%)
Accept / Reject per topic; batch-accept all > 80% confidence
"Unmapped topics" section
Submit → creates TEACHES edges in Neo4j
Note: Phase 2 (P2-018) upgrades to full TEACHES vs TEACHES_VERIFIED distinction.


2.2.5  SubConcept Verification (TEACHES_VERIFIED)   Phase 2
Route: /courses/:id/concept-review
Phase 2
Course Director
Queue for promoting AI-inferred TEACHES edges to TEACHES_VERIFIED — the only edges counted in LCME compliance chains.
Key Functions
Queue of SubConcepts with TEACHES (unverified) status
ConceptMappingCard: concept name, source excerpt, USMLE system badge, confidence
"Verify" → creates TEACHES_VERIFIED edge in Neo4j
Skip / Flag as incorrect options
Progress counter: N verified / total
Note: Course Director only. Regular faculty cannot create TEACHES_VERIFIED edges. See CLAUDE.md Rule 15.



2.3  Question Generation (Workbench)



2.3.1  QUEST Workbench   Phase 1
Route: /workbench
Phase 1
Faculty + Course Dir
THE core generation interface. Left panel (45%) = CopilotKit chat; right panel (55%) = live question rendering via STATE_DELTA streaming from LangGraph pipeline. Pipeline: context_compiler → vignette_builder → stem_writer → distractor_generator → dedup_detector → validator → graph_writer → critic_agent → tagger → toulmin_generator → review_router.
Key Functions
Left: CopilotKit <CopilotChat> with conversation history
Right: useCoAgent hook renders vignette → stem → options progressively
Options appear one-by-one as distractors generate
Validation pass/fail badges inline; Critic 6-metric breakdown on completion
Approve / Reject / Edit buttons on final question
Gap pre-fill: URL params ?system=X&discipline=Y auto-send first prompt (P3-010)
Review mode: ?mode=review&itemId=X loads existing item for refinement (P2-009)
Note: NOT a REST form. CopilotKit + LangGraph AG-UI streaming. Must be rebuilt from scratch — prototype form version is incompatible.


2.3.2  Batch Queue   Phase 2
Route: /batches
Phase 2
Faculty + Course Dir
List of all bulk generation batches. Status, item counts, progress bars.
Key Functions
Batches sorted by created_at DESC; status badge (queued/running/completed/failed)
Per-batch: total, completed, failed, elapsed time
30-second polling for running batches
"New Batch" modal; "View Details" → /batches/:id


2.3.3  Batch Detail   Phase 2
Route: /batches/:id
Phase 2
Faculty + Course Dir
Per-batch item-level results. Socket.io real-time updates.
Key Functions
Summary: total / completed / approved / rejected / failed
Per-item: stem excerpt, status, critic score, auto_route
"Retry Failed" per item and "Retry All Failed" bulk action
Real-time via Socket.io room user:{userId}; filter by status


2.3.4  Generation History   Phase 2
Route: /history
Phase 2
Faculty + Course Dir
Complete log of all generation events. Stats bar, filters, pagination.
Key Functions
Stats bar: total, approved, approval rate, avg critic score
Log: timestamp, course, prompt excerpt, status, critic score
Filter by course, date range, route (single/bulk/review)
Pagination 20/page; "View Question" link per row



2.4  Question Review & Management



2.4.1  Faculty Review Queue   Phase 2
Route: /questions/review
Phase 2
Faculty + Course Dir
Queue of questions flagged auto_route = faculty_review. Faculty approves or rejects each item.
Key Functions
Items sorted created_at; filter by USMLE system, difficulty, batch_id, status
Per-item: stem excerpt, system/difficulty/critic badges, validation issues
Approve: PATCH /items/:id {status:approved}; Reject with reject_reason
"Refine in workbench" → /workbench?mode=review&itemId=X


2.4.2  Question Detail View   Phase 2
Route: /items/:id
Phase 2
Faculty + Course Dir
Full per-item analytics page. 5 collapsible panels.
Key Functions
Panel 1 — Question: vignette, stem, 5 options (correct highlighted), explanation, "Edit" button
Panel 2 — Quality Scores: Recharts RadarChart of 6 Critic metrics, composite badge, 30-rule validation accordion
Panel 3 — Evidence Chain: Toulmin 6-field display, TaskShell used, USMLE system/discipline
Panel 4 — Provenance: source chunk excerpt (200 chars), ingestion job ID, pipeline version, retry count
Panel 5 — UMLS Grounding: SubConcept → StandardTerm CUI + SNOMED CT + MeSH (after P3-018)
Version history dropdown to view/revert any prior version


2.4.3  Rich Item Editor   Phase 4
Route: /items/:id/edit
Phase 4
Faculty + Course Dir
Inline editor for any field with auto re-validation + Critic re-score on save. Immutable version saved before every save.
Key Functions
Edit: vignette, stem, lead_in, all 5 options, explanation
Client-side 30-rule validation on blur (before backend hit)
Save → full validator + Cover the Options (Sonnet) + Critic re-score (Opus) on backend
Response: new validation_results, critic_composite_score, auto_route decision
"Revert to version" dropdown; correct-answer change requires confirmation modal
Enforces exactly 1 correct option
Note: NEW screen — not in prototype. Must be built from scratch (P4-002).


2.4.4  Item Bank Browser   Phase 4
Route: /repository/item-bank
Phase 4
Faculty + Course Dir
Production item bank with 8-dimension filtering, bulk actions, CSV export.
Key Functions
Filters: USMLE system, difficulty, Bloom, status, auto_route, critic_min, has_toulmin, source (ai/legacy)
Sort: created_at, critic_composite_score, bloom_level, usmle_system
Item cards: stem excerpt, all badges, critic score pill, Toulmin indicator
Bulk select → "Add to Exam" (→ /exams/new?itemIds=X,Y)
"Export CSV" streams current filtered set; pagination 20/page


2.4.5  Basic Question Bank   Phase 1
Route: /repository
Phase 1
Faculty + Course Dir
Phase 1 lightweight bank. Search + status filter only. Superseded by /repository/item-bank in Phase 4.
Key Functions
Search by stem text; filter by status (pending/approved/rejected)
"View" link → /items/:id
Note: Route /repository redirects to /repository/item-bank after Phase 4 ships.



2.5  Analytics (Faculty-Facing)



2.5.1  USMLE Coverage Heatmap   Phase 3
Route: /analytics/usmle-heatmap
Phase 3
Faculty + Course Dir
16×7 interactive heatmap (16 USMLE Systems × 7 Disciplines = 112 cells). Colored by coverage density. Clicking a gap cell opens the pre-filled workbench.
Key Functions
Color: green ≥ 2 items, amber = 1 item, red = 0 items (gap)
Cell hover: item count tooltip
Click cell → /workbench?system=X&discipline=Y&courseId=Z (auto-sends generation prompt)
Course filter; optional toggle between item count and concept coverage %


2.5.2  Gap Priorities List   Phase 3
Route: /analytics/gaps
Phase 3
Faculty + Course Dir
Top 20 coverage gaps ranked by priority score: coverage × USMLE Step 1 weight × concept centrality × recency.
Key Functions
Per-gap: USMLE System + Discipline, priority score (0–1), item count, score breakdown
"Fill this gap" → /workbench?system=X&discipline=Y
Score breakdown tooltip: 4 component weights


2.5.3  D3 Coverage Map   Phase 3
Route: /analytics/coverage-map
Phase 3
Faculty + Course Dir
Force-directed graph of all SubConcept nodes, colored by coverage, sized by PageRank centrality. Reveals curriculum shape and dark spots.
Key Functions
D3.js force simulation; nodes = SubConcepts, edges = MAPS_TO relationships
Color: green (#69A338) ≥ 2 items, amber (#F59E0B) = 1, red (#D32F2F) = 0
Node size ∝ PageRank score; drag/zoom/pan
Hover: tooltip (name, question count, USMLE system); click: side panel + "Generate question" pre-fill
USMLE System filter; max 500 nodes (top by PageRank)
Note: NEW screen — not in prototype. D3.js required (npm install d3 in frontend).


2.5.4  Blueprint Coverage   Phase 3
Route: /analytics/blueprint-coverage
Phase 3
Faculty + Course Dir
Per-course USMLE system coverage bars, weekly generation trends, difficulty donut chart, topic frequency chart.
Key Functions
Weekly generation trend (Recharts BarChart); difficulty donut (Easy/Medium/Hard)
USMLE system coverage bars (covered vs total concepts per system)
Topic frequency chart; course selector for multi-course faculty



3. Exam Screens
Assembly, delivery, and results — Phases 4–5



3.1  Exam Builder (Blueprint Form)   Phase 4
Route: /exams/new
Phase 4
Faculty + Course Dir
Step 1 of exam assembly. Define blueprint constraints; backend sends to Python MIP solver (PuLP/FastAPI on port 8001) which selects the optimal question set.
Key Functions
Exam name + course selection
Total questions slider (1–200); time limit (minutes)
Bloom distribution sliders (6 levels, must sum to 100%)
Difficulty mix sliders (Easy/Medium/Hard, must sum to 100%)
USMLE System distribution (optional; blank = unconstrained)
Exclude past exams (prevents question reuse); min critic score (default 3.5)
"Generate Exam" → POST /exams → MIP solver → "Solving constraints…" spinner
Greedy fallback if MIP solver unavailable (transparent to user)


3.2  Exam Preview & Manual Swap   Phase 4
Route: /exams/:id
Phase 4
Faculty + Course Dir
Step 2: review the generated question list, reorder via drag-and-drop, swap individual questions for alternatives, then finalize.
Key Functions
Ordered list with @dnd-kit/core drag handles
Per-question: position, stem excerpt, system/Bloom/difficulty badges, critic score
"Swap" → SwapQuestionModal: top 5 alternatives matching same Bloom + system
"Add Question" → item bank side sheet (compatible items)
Blueprint validation panel: system_distribution + difficulty_balance with pass/warn/fail
"Finalize Exam" → PATCH /exams/:id {status:published}
"Export Blueprint" → PDF/CSV for accreditation records


3.3  Exam Assignment   Phase 4
Route: /exams/:id/assign
Phase 4
Faculty + Course Dir
Assign a finalized exam to students. Sets start/end times and duration.
Key Functions
Student multi-select (enrolled in this course)
Start time + end time pickers; duration in minutes
POST /exams/:id/assign → creates exam_sessions rows (one per student)
Students notified via exam:assigned (Socket.io + Supabase Realtime)


3.4  Exam Delivery (Student)   Phase 4
Route: /exams/:sessionId/take
Phase 4
Student
Student-facing timed exam. One question at a time. Answers auto-saved on selection. Auto-submits at timer expiry.
Key Functions
Countdown timer (browser-side, Date.now())
Question navigator sidebar: grid colored by answered/unanswered
A–E option buttons; answer auto-saved on click (PATCH /responses)
No explicit Save button — selection = save
Submit → confirmation modal → POST /submit → server-side scoring
Auto-submit at timer = 0 (frontend + server-side fallback check)
Score returned immediately: rawScore, pctScore, correctCount, totalQuestions
Note: Student only. Faculty cannot access exam delivery screens. NEW screen — not in prototype.


3.5  Legacy Exam Import   Phase 4
Route: /exams/retired-upload
Phase 4
Admin + Inst Admin
Upload CSV of existing MSM exam questions. Each row goes through full Inngest pipeline: tag → validate → critic → dual-write.
Key Functions
CSV format: stem, option_a–e, correct_option, explanation, course_code, bloom_level, usmle_system
Row-level failure tolerance — one bad row never fails batch
Missing tags filled by Haiku tagger; validator flags but does NOT auto-reject legacy items
Critic scores every imported item; progress at GET /imports/:id
Note: Admin + Inst Admin only.



4. Admin & Institutional Admin Screens
System management, compliance, and reporting




4.1  Admin



4.1.1  Admin Dashboard   Phase 4
Route: /admin
Phase 4
Admin
System-wide overview: all institutions, all faculty, all items. Quick-action buttons for system maintenance tasks.
Key Functions
KPI tiles: Total Users, System Health %, Total Items, Coverage Score
Recent users list: name, email, role, status, joined date
System alerts panel (lint failures, sync errors)
Course stats by department
Quick actions: Invite Faculty, Run Lint, Trigger UMLS Backfill, Compute PageRank


4.1.2  User Management   Phase 4
Route: /admin/users
Phase 4
Admin
Full CRUD user management across all institutions.
Key Functions
User table with role badge, institution, status, last login
Filter by role, institution, status; search by name/email
"Invite User" → modal with email, role, institution_id, courseIds — fires Supabase magic link
Deactivate (soft delete); change role dropdown


4.1.3  Knowledge Browser   Phase 4
Route: /admin/knowledge
Phase 4
Admin
Navigate the knowledge graph. SubConcept hierarchy with USMLE groupings, teaching chunk counts, item counts, UMLS grounding.
Key Functions
Tree/list of SubConcepts grouped by USMLE System; filter + search
Per-node: name, teaching chunks, assessment items, child concepts
Click → SubConceptDetail: full graph connections, GROUNDED_IN term, generation history


4.1.4  Data Integrity Dashboard   Phase 4
Route: /admin/data-integrity
Phase 4
Admin
System health monitor. 5 panels: sync failures, lint results, LOD enrichment, graph health, generation health. One-click triggers for all repair actions.
Key Functions
Sync Status: failed items per table + "Reconcile" button
KaizenML Lint: last 7 days, pass/fail per rule, sparklines (6 rules in Phase 4)
LOD Enrichment: SubConcepts grounded %, LCME elements aligned, "Run Backfill"
Graph Health: Neo4j node counts, orphan SubConcepts, PageRank last computed
Generation Health: items missing tags/critic, stale running logs
Auto-refresh 60s; all actions fire Inngest jobs (returns jobId immediately)


4.1.5  ILO Management   Phase 4
Route: /admin/ilos
Phase 4
Admin
CRUD for Institutional Learning Outcomes — top-level objectives that SLOs must fulfil and LCME elements map to.
Key Functions
List all ILOs with SLO count and LCME element alignment
Create/Edit/Archive ILO; framework selector (ACGME / LCME / Custom)
Link to SLO → ILO suggestion queue


4.1.6  FULFILLS Review Queue   Phase 4
Route: /admin/fulfills-review
Phase 4
Admin + Inst Admin
Queue of pending SLO → ILO FULFILLS relationships awaiting admin confirmation.
Key Functions
Pending suggestions with similarity score; Accept / Reject per suggestion
Batch accept all ≥ 0.90 similarity; creates FULFILLS edge in Neo4j on accept



4.2  LCME Compliance



4.2.1  LCME Compliance Heatmap   Phase 3
Route: /admin/lcme-compliance-heatmap
Phase 3
Admin + Inst Admin
12-standard × 93-element heatmap showing assessment evidence coverage. Primary accreditation-readiness view for the Associate Dean.
Key Functions
12 LCME Standards × 93 Elements grid; 10-minute Redis cache
Color: gray = 0%, red < 50%, amber 50–79%, green ≥ 80%
Click element → /admin/lcme-element-drill-down?elementId=X
"Export Evidence" triggers full export job; last-updated timestamp shown


4.2.2  LCME Element Drill-Down   Phase 3
Route: /admin/lcme-element-drill-down
Phase 3
Admin + Inst Admin
Full 5-hop evidence chain per element: Element → ILO → SLO → SubConcept → AssessmentItem.
Key Functions
Chain view: ILOs → SLOs (by course) → SubConcepts → approved items
"Missing links" section: ILOs with no SLO, SLOs with no SubConcept
Per-item: stem excerpt, status, critic score; UMLS CUI shown next to SubConcepts (post P3-018)
Coverage % and item count summary


4.2.3  Evidence Export / Accreditation Reports   Phase 3
Route: /institution/accreditation
Phase 3
Admin + Inst Admin
Evidence export and accreditation reporting. Phase 3: CSV/JSON. Phase 5: Claude-generated narrative DOCX.
Key Functions
"Export All Evidence" → GET /admin/lcme/export?format=csv|json
CSV: one row per item (standard, element, ILO, SLO, SubConcept, stem excerpt, critic score, date)
< 60 second SLA for all 93 elements; Inngest async if > 5s
Phase 5: "Generate Narrative Report" → Claude writes LCME narrative sections as DOCX



4.3  Institutional Admin



4.3.1  Institutional Admin Dashboard   Phase 3
Route: /institution
Phase 3
Inst Admin
Institution-scoped overview for Associate Dean / Department Chair.
Key Functions
KPIs: enrolled students, active faculty, active courses, total items, coverage score
Trend indicators per KPI; alerts panel (accreditation warnings, at-risk courses)
Coverage overview by department; links to LCME heatmap and accreditation reports
Note: RLS enforces data isolation — only own institution data visible.


4.3.2  Framework Configuration   Phase 3
Route: /institution/frameworks
Phase 3
Inst Admin
Enable or disable assessment framework families per institution. Controls tag sets in the generation pipeline.
Key Functions
Toggle per framework: USMLE, ACGME, LCME, NBME, Custom
Enable → tagger and generator use those tags; disable → existing preserved, new items skip


4.3.3  SLO → ILO Linking Queue   Phase 3
Route: /admin/ilo-management
Phase 3
Admin + Inst Admin
Review queue for linking extracted SLOs to ILOs. AI suggests top 3 ILO matches per SLO.
Key Functions
Pending SLOs per course with top 3 suggested ILOs and similarity scores
Accept → creates FULFILLS edge; "Create New ILO" when no match adequate
Batch accept all ≥ 0.90; completion counter



5. Student Screens
Phase 5: practice, mastery tracking, and exam delivery



5.1  Student Dashboard   Phase 5
Route: /student-dashboard
Phase 5
Student
Primary student home. Mastery overview across enrolled courses, upcoming practice, daily streak, recent activity.
Key Functions
KPI tiles: Questions Answered, Accuracy Rate, Streak (days), Study Time — each with 7-day sparkline
Course progress cards: progress %, next topic, due date
Upcoming practice panel: queued sessions with question count and priority
Note: Phase 5 only. faculty dashboard active_students = 0 until this phase ships.


5.2  Practice Session   Phase 5
Route: /student/practice/session
Phase 5
Student
Core practice interface. Question display → answer selection → immediate per-question feedback with explanation and misconception analysis.
Key Functions
Vignette + stem + A–E options; answer selection gives immediate correct/incorrect feedback
Correct answer highlight; explanation text; distractor rationale (why each wrong answer is wrong)
Toulmin "Evidence Chain" panel showing the ECD argument for the correct answer
BKT mastery update visible after each answer (animated progress bar)
POST /student/sessions/:id/answers with {question_id, selected_option, time_spent}


5.3  Practice Topic Selection   Phase 5
Route: /student/practice
Phase 5
Student
Pre-session setup: select topic, difficulty, question count, time limit.
Key Functions
Browse by USMLE System or by Course
Difficulty: Easy/Medium/Hard/Mixed; question count: 5/10/20/Custom; timed or untimed
"Start Practice" creates session → /student/practice/session


5.4  Practice Results   Phase 5
Route: /student/practice/results
Phase 5
Student
End-of-session summary: accuracy, time per question, mastery changes.
Key Functions
Session summary: total, correct, accuracy %, total time
Per-question breakdown: answer selected, correct answer, correct/incorrect badge
Mastery change panel: concepts improved vs regressed
"Review Missed" loads incorrect answers; "Practice Again" with same settings


5.5  Student Mastery Progress   Phase 5
Route: /student/progress
Phase 5
Student
Personal BKT mastery values per SubConcept across all enrolled courses. Student-facing coverage map colored by mastery.
Key Functions
Overall mastery % per course; SubConcept mastery breakdown (value 0–1, question count, accuracy)
USMLE system-level mastery heatmap (student version of P3-007)
Mastery trend chart (30-day); recommended next topics (lowest mastery, highest USMLE weight)


5.6  Student Analytics   Phase 5
Route: /student/analytics
Phase 5
Student
Detailed performance analytics: accuracy trends, Bloom level breakdown, weak/strong areas.
Key Functions
Accuracy trend (30-day rolling); time per question trend
Bloom level accuracy breakdown (how well at each cognitive level)
Weakest SubConcepts by accuracy; Strongest SubConcepts for confidence



6. Advisor Screens
Phase 5: cohort monitoring and early-warning detection



6.1  Advisor Dashboard   Phase 5
Route: /advisor/dashboard
Phase 5
Advisor
Cohort-level oversight for academic advisors. Aggregate mastery health and at-risk detection across all assigned students.
Key Functions
Cohort KPIs: total students, avg mastery %, at-risk count, avg accuracy
Per-student cards: name, year, mastery %, streak, at-risk flag
At-risk flag: mastery trajectory declining for 2+ consecutive weeks
Sort by mastery asc, at-risk first, or name
"View Student" → /advisor/students/:id
"Generate Report" → narrative PDF/DOCX of cohort status
Note: Phase 5 only. Advisors see no generation or item bank screens.


6.2  At-Risk Student Detail   Phase 5
Route: /advisor/students/:id
Phase 5
Advisor
Per-student deep-dive using PREREQUISITE_OF graph traversal to identify root-cause mastery gaps.
Key Functions
Student profile: name, year, courses, streak, overall mastery
Mastery trajectory chart (30-day BKT values per top concept)
Root-cause analysis: PREREQUISITE_OF graph edges identify foundational gaps causing downstream failures
Recommended interventions: SubConcepts to practice, ordered by impact
"Flag for Faculty Review" sends notification to course director
Note: Phase 5 only. NEW screen — not in prototype.


6.3  LCME Narrative Report   Phase 5
Route: /institution/accreditation
Phase 5
Admin + Inst Admin
Phase 5 extension: Claude-generated narrative sections for LCME self-study report (added to the Phase 3 accreditation screen).
Key Functions
"Generate Narrative" → Claude (Sonnet) writes formal prose for each LCME Standard from current evidence chain data
Tone: formal accreditation language ("The institution provides evidence that…")
Human review/edit step before finalizing; export as PDF or DOCX
Note: Phase 5 only (P5-017). Requires Claude API server-side access.



7. Notifications
Real-time and persistent notification system — all roles



7.1  Notification Bell (Header)   Phase 2
Route: /  — global header
Phase 2
All Authenticated
Bell icon in app header with unread badge count. Popover shows last 5 notifications.
Key Functions
Unread badge driven by Supabase Realtime subscription (Phase 4+)
Popover: last 5 with icon, title, body, timestamp, read/unread
Mark as read on click; "View all" → /notifications
Phase 2: Socket.io only. Phase 4: also Supabase Realtime (persistent across sessions)


7.2  Notifications Page   Phase 4
Route: /notifications
Phase 4
All Authenticated
Full notification history with filtering and bulk mark-read.
Key Functions
Full history paginated newest-first; filter by type and read/unread
"Mark all read"; click → navigates to relevant screen
Event types: batch:completed, review:needed, exam:assigned, exam:submitted, import:completed, umls:enrichment_complete, sync:failed



8. Deferred Screens
In the prototype but no current roadmap coverage — leave on mock data



Route
Component
Reason deferred
/home
Home
Static marketing — no backend needed
/register
Registration
Superseded by role-specific routes
/faculty/communications
FacultyCommunicationHub
No roadmap mention
/student/support
StudentSupportCenter
No roadmap mention
/admin/announcements
AnnouncementSystem
No roadmap mention
/templates
QuestionTemplates
Generation unified in workbench
/bulk-operations
BulkOperations
Bulk via workbench + Inngest
/uploads/faculty-questions
FacultyQuestionUpload
Superseded by legacy import P4-004
/generate/test, /generate/quiz
Generate*
Unified in QuestWorkbench
/admin/settings
SystemConfigurationDashboard
Not spec'd in any story
/analytics/questions
QuestionPerformanceMetrics
IRT analytics — no story yet



9. Route Consolidation
Duplicate prototype routes to redirect on backend wiring



Canonical (keep)
Redirect from (deprecate)
/dashboard
/faculty-dashboard, /faculty/dashboard
/student-dashboard
/student, /student/dashboard
/institution
/institution/dashboard
/admin
/admin/dashboard
/questions/review
/faculty/questions/review
/repository
/faculty/repository, /faculty/questions/repository
/exams/new
/exams/assembly, /faculty/exams/assembly
/exams/:id/assign
/exams/assign, /faculty/exams/assignment
/email-verification
/verify-email
/courses
/faculty/courses

