# Journey OS — MSM Design System Migration Progress

## ✅ Phase 1: Foundation (COMPLETE)

- ✅ `/src/styles/fonts.css` - Updated with Lora, Source Sans 3, DM Mono
- ✅ `/src/styles/theme.css` - Complete MSM design system tokens
  - True Blues (70%) + Evergreens (30%) color palette
  - Typography scale (serif headings, sans body, mono labels)
  - Spacing system (8px grid)
  - Border radius tokens
  - Shadow system (warm-toned, subtle)
  - Motion/animation timings
  - Chart color sequences
  - Utility classes

## ✅ Phase 2: Core UI Components (COMPLETE)

Successfully updated all foundational components with MSM design tokens:

- ✅ Button (primary=navy-deep, secondary, outline, ghost, destructive)
- ✅ Card (parchment bg, hover borders, proper typography)
- ✅ Badge (monospace labels, semantic+persona variants)
- ✅ Input (focus states, MSM colors, proper sizing)
- ✅ Label (monospace uppercase, tracked, proper color)
- ✅ Textarea (matching input styles)
- ✅ Select (complete dropdown with MSM colors)
- ✅ Table (cream header, proper typography, hover states)
- ✅ Alert (left border semantic colors, proper backgrounds)
- ✅ Dialog (modal with MSM styling, serif titles)
- ✅ Breadcrumb (slash separator, proper colors)
- ✅ Tabs (navy-deep active, parchment container)

## 🔄 Phase 3: Layout Components (IN PROGRESS)

Need to update layout components to use MSM design tokens:

- [ ] TopNavigation (navy-deep background, white text, logo)
- [ ] AdminSidebar (cream background, persona accents)
- [ ] DashboardLayout (proper spacing, white content area)
- [ ] AdminDashboardLayout
- [ ] AdminLayout

## 🔄 Phase 4: Screen Updates (PENDING)

Systematically update all 76 screens by category:

### Auth & Onboarding (12 screens)
- [ ] RoleSelection
- [ ] Login
- [ ] Registration (generic + 3 role-specific)
- [ ] ForgotPassword
- [ ] EmailVerification
- [ ] Onboarding (generic + 3 role-specific)

### Student (6 screens)
- [ ] StudentDashboard
- [ ] StudentPractice
- [ ] StudentQuestionView
- [ ] StudentResults
- [ ] StudentProgress
- [ ] StudentAnalytics

### Faculty (39 screens)
- [ ] FacultyDashboard
- [ ] Courses (14 screens)
- [ ] Generation (7 screens)
- [ ] Questions (7 screens)
- [ ] Exams (3 screens)
- [ ] Repository (2 screens)
- [ ] Analytics (4 screens)
- [ ] Uploads (1 screen)

### Admin (12 screens)
- [ ] AdminDashboard
- [ ] Setup & Foundation (6 screens)
- [ ] Faculty Management (1 screen)
- [ ] Compliance & Outcomes (4 screens)

### Shared (8 screens)
- [ ] Profile
- [ ] Settings
- [ ] Notifications
- [ ] Help
- [ ] QuestionTemplates
- [ ] BulkOperations
- [ ] Collaborators
- [ ] NotFound

## 📋 Design System Checklist Per Screen

For each screen, verify:
- [ ] Uses Lora for H1/H2 headings
- [ ] Uses Source Sans 3 for body text, buttons, UI
- [ ] Uses DM Mono for labels, tags, technical text
- [ ] Primary color is navy-deep (#002c76), not yellow
- [ ] Interactive states use blue-mid (#2b71b9) for hover/focus
- [ ] Success states use green (#69a338)
- [ ] Backgrounds follow white → parchment → cream hierarchy
- [ ] Borders use border-default (#e2dfd8) and border-light (#edeae4)
- [ ] Shadows use warm-toned subtle MSM shadows
- [ ] Spacing follows 8px grid (space-1 through space-24)
- [ ] Border radius matches tokens (sm: 3px, md: 6px, lg: 8px, xl: 10px, 2xl: 12px)
- [ ] Charts use MSM color sequences (blues for sequential, blues+greens for categorical)
- [ ] Persona accents applied correctly (faculty=green, admin=blue, advisor=blue-light, student=blue-mid)

## 🎯 Current Status

**Completed:** Foundation files (fonts + theme), Core UI Components
**Next Up:** Update layout components, then systematically update screens
**Estimated Completion:** 2-3 hours of focused work

## 🚀 After Migration

Once all 76 screens are updated:
- Test all workflows for visual consistency
- Verify accessibility (WCAG 2.1 AA compliance with new colors)
- Validate responsive behavior
- Document any MSM-specific component patterns
- Create component showcase/storybook