#!/bin/bash
# Journey-OS File Reorganization Script
# This script moves all role-specific screens to their proper role folders

set -e  # Exit on error

echo "===================================="
echo "Journey-OS File Reorganization"
echo "===================================="

# Create new directory structure
echo "Creating directory structure..."
mkdir -p /root/src/app/pages/faculty/courses
mkdir -p /root/src/app/pages/faculty/generation
mkdir -p /root/src/app/pages/faculty/questions
mkdir -p /root/src/app/pages/faculty/exams
mkdir -p /root/src/app/pages/faculty/repository
mkdir -p /root/src/app/pages/faculty/analytics

# ==========================================
# FACULTY - Move files
# ==========================================
echo "Moving Faculty files..."

# Faculty Dashboard
mv /root/src/app/pages/dashboard/FacultyDashboard.tsx /root/src/app/pages/faculty/FacultyDashboard.tsx

# Faculty - Courses (14 files)
mv /root/src/app/pages/courses/AllCourses.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/CourseDashboard.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/CreateCourse.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/LectureUpload.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/LectureProcessing.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/UploadSyllabus.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/SyllabusEditor.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/SyllabusProcessing.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/ReviewSyllabusMapping.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/SubConceptReviewQueue.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/OutcomeMapping.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/WeekView.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/WeekMaterialsUpload.tsx /root/src/app/pages/faculty/courses/
mv /root/src/app/pages/courses/CourseReady.tsx /root/src/app/pages/faculty/courses/

# Faculty - Generation (7 files)
mv /root/src/app/pages/generation/GenerationSpecificationWizard.tsx /root/src/app/pages/faculty/generation/
mv /root/src/app/pages/generation/BatchProgress.tsx /root/src/app/pages/faculty/generation/
mv /root/src/app/pages/generation/GenerateQuestionsTopic.tsx /root/src/app/pages/faculty/generation/
mv /root/src/app/pages/generation/GenerateQuestionsSyllabus.tsx /root/src/app/pages/faculty/generation/
mv /root/src/app/pages/generation/GenerateTest.tsx /root/src/app/pages/faculty/generation/
mv /root/src/app/pages/generation/GenerateQuiz.tsx /root/src/app/pages/faculty/generation/
mv /root/src/app/pages/generation/GenerateHandout.tsx /root/src/app/pages/faculty/generation/

# Faculty - Questions (7 files)
mv /root/src/app/pages/questions/FacultyReviewQueue.tsx /root/src/app/pages/faculty/questions/
mv /root/src/app/pages/questions/QuestionReviewList.tsx /root/src/app/pages/faculty/questions/
mv /root/src/app/pages/questions/ItemDetail.tsx /root/src/app/pages/faculty/questions/
mv /root/src/app/pages/questions/QuestionDetailView.tsx /root/src/app/pages/faculty/questions/
mv /root/src/app/pages/questions/QuestionHistory.tsx /root/src/app/pages/faculty/questions/
mv /root/src/app/pages/questions/AIRefinement.tsx /root/src/app/pages/faculty/questions/
mv /root/src/app/pages/questions/ConversationalRefinement.tsx /root/src/app/pages/faculty/questions/

# Faculty - Exams (3 files)
mv /root/src/app/pages/exams/ExamAssembly.tsx /root/src/app/pages/faculty/exams/
mv /root/src/app/pages/exams/ExamAssignment.tsx /root/src/app/pages/faculty/exams/
mv /root/src/app/pages/exams/RetiredExamUpload.tsx /root/src/app/pages/faculty/exams/

# Faculty - Repository (2 files)
mv /root/src/app/pages/repository/Repository.tsx /root/src/app/pages/faculty/repository/
mv /root/src/app/pages/repository/ItemBankBrowser.tsx /root/src/app/pages/faculty/repository/

# Faculty - Analytics (4 files)
mv /root/src/app/pages/analytics/Analytics.tsx /root/src/app/pages/faculty/analytics/
mv /root/src/app/pages/analytics/CourseAnalytics.tsx /root/src/app/pages/faculty/analytics/
mv /root/src/app/pages/analytics/BlueprintCoverage.tsx /root/src/app/pages/faculty/analytics/
mv /root/src/app/pages/analytics/PersonalDashboard.tsx /root/src/app/pages/faculty/analytics/

# Faculty - Question Upload (1 file)
mv /root/src/app/pages/uploads/FacultyQuestionUpload.tsx /root/src/app/pages/faculty/FacultyQuestionUpload.tsx

# ==========================================
# STUDENT - Move Dashboard
# ==========================================
echo "Moving Student Dashboard..."
mv /root/src/app/pages/dashboard/StudentDashboard.tsx /root/src/app/pages/student/StudentDashboard.tsx

# ==========================================
# ADMIN - Dashboard already in place, remove old one
# ==========================================
echo "Removing old Dashboard.tsx (Admin dashboard already exists)..."
rm /root/src/app/pages/dashboard/Dashboard.tsx

# ==========================================
# Clean up empty directories
# ==========================================
echo "Removing empty directories..."
rmdir /root/src/app/pages/courses 2>/dev/null || true
rmdir /root/src/app/pages/generation 2>/dev/null || true
rmdir /root/src/app/pages/questions 2>/dev/null || true
rmdir /root/src/app/pages/exams 2>/dev/null || true
rmdir /root/src/app/pages/repository 2>/dev/null || true
rmdir /root/src/app/pages/analytics 2>/dev/null || true
rmdir /root/src/app/pages/uploads 2>/dev/null || true
rmdir /root/src/app/pages/dashboard 2>/dev/null || true

# ==========================================
# Swap routes file
# ==========================================
echo "Updating routes file..."
mv /root/src/app/routes.ts /root/src/app/routes-old.ts
mv /root/src/app/routes-new.ts /root/src/app/routes.ts

echo "===================================="
echo "Reorganization Complete!"
echo "===================================="
echo ""
echo "Summary:"
echo "- Moved 47 files to role-specific folders"
echo "- Faculty: 39 files"
echo "- Student: 1 file (dashboard)"
echo "- Admin: Files already in place"
echo "- Updated routes.ts with new import paths"
echo ""
echo "Old routes backed up to: routes-old.ts"
echo ""
echo "New structure:"
echo "  /src/app/pages/faculty/     (all faculty screens)"
echo "  /src/app/pages/student/      (all student screens)"
echo "  /src/app/pages/admin/        (all admin screens)"
echo ""
