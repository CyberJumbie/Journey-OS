#!/usr/bin/env python3
import re
import sys

# Read file
with open(sys.argv[1], 'r') as f:
    content = f.read()

# Replace all incorrect color classes with correct ones
replacements = {
    'border-border-subtle': 'border-border',
    'text-primary-color': 'text-primary',
    'bg-primary-color': 'bg-primary',
    'border-primary-color': 'border-primary',
    'text-success-color': 'text-success',
    'bg-success-color': 'bg-success',
    'text-error-color': 'text-destructive',
    'bg-error-color': 'bg-destructive',
    'text-warning-color': 'text-warning',
    'bg-warning-color': 'bg-warning',
    'text-info-color': 'text-info',
    'bg-info-color': 'bg-info',
}

for old, new in replacements.items():
    content = content.replace(old, new)

# Write back
with open(sys.argv[1], 'w') as f:
    f.write(content)

print(f"Fixed: {sys.argv[1]}")
