# Journey-OS Dashboard Navigation Map

## FACULTY NAVIGATION DOMAINS

All dashboards now use `useNavigate` and `useLocation` from react-router to match the original information architecture.

### Sidebar Navigation

| Nav Item | Icon | Route | Description |
|----------|------|-------|-------------|
| Dashboard | ◈ | `/dashboard` | Faculty main dashboard |
| Courses | ◆ | `/courses` | All courses view |
| Generate | ✦ | `/generation/wizard` | Question generation wizard |
| Assessments | ◇ | `/questions/review` | Question review queue |
| Students | ▢ | `/student/progress` | Student progress tracking |
| Analytics | ▣ | `/analytics` | Analytics dashboard |

### Settings & Profile

| Action | Icon | Route | Description |
|--------|------|-------|-------------|
| Settings | ⚙ | `/settings` | User settings |
| Profile | (user avatar) | `/profile` | User profile |
| Notifications | 🔔 | `/notifications` | Notification center |

### Quick Actions

| Action | Icon | Route | Description |
|--------|------|-------|-------------|
| Generate Items | ◆ | `/generation/wizard` | Start generation |
| Create Exam | ◇ | `/exams/assembly` | Exam assembly |
| Map Curriculum | ◈ | `/courses/outcome-mapping` | Outcome mapping |
| View Reports | ▣ | `/analytics` | Reports view |

### Course Cards

Each course card routes to:
- Click: `/courses/{courseId}` → CourseDashboard

### Active Navigation Detection

The sidebar automatically highlights the active section based on URL path:

```tsx
useEffect(() => {
  const path = location.pathname;
  if (path.startsWith("/courses")) setActiveNav("courses");
  else if (path.startsWith("/generation") || path.startsWith("/generate")) setActiveNav("generate");
  else if (path.startsWith("/questions") || path.startsWith("/assessments")) setActiveNav("assessments");
  else if (path.startsWith("/student")) setActiveNav("students");
  else if (path.startsWith("/analytics")) setActiveNav("analytics");
  else if (path === "/dashboard" || path === "/faculty-dashboard") setActiveNav("dashboard");
}, [location.pathname]);
```

---

## STUDENT NAVIGATION DOMAINS

### Sidebar Navigation

| Nav Item | Icon | Route | Description |
|----------|------|-------|-------------|
| Dashboard | ◈ | `/student-dashboard` | Student main dashboard |
| My Courses | ◆ | `/courses` | Enrolled courses |
| Practice | ✦ | `/student/practice` | Practice sessions |
| Progress | ◇ | `/student/progress` | Progress tracking |
| Resources | ▢ | `/repository` | Study resources |
| Help | ▣ | `/help` | Help center |

---

## ADMIN NAVIGATION DOMAINS

### Sidebar Navigation

| Nav Item | Icon | Route | Description |
|----------|------|-------|-------------|
| Dashboard | ◈ | `/admin` | Admin dashboard |
| Setup | ◆ | `/admin/setup` | Setup wizard |
| Frameworks | ✦ | `/admin/frameworks` | Framework management |
| Faculty | ◇ | `/admin/faculty` | Faculty management |
| Knowledge | ▢ | `/admin/knowledge` | Knowledge browser |
| Data Integrity | ▣ | `/admin/data-integrity` | Data integrity dashboard |

---

## CROSS-ROLE SHARED ROUTES

These routes are accessible across all roles:

- `/profile` - User profile
- `/settings` - User settings
- `/notifications` - Notifications
- `/help` - Help center

---

## IMPLEMENTATION PATTERN

All dashboards now follow this pattern:

```tsx
import { useNavigate, useLocation } from "react-router";

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeNav, setActiveNav] = useState("dashboard");
  
  // Auto-detect active nav from URL
  useEffect(() => {
    // Set activeNav based on location.pathname
  }, [location.pathname]);
  
  const navItems = [
    { key: "dashboard", label: "Dashboard", icon: "◈", path: "/dashboard" },
    // ... more items
  ];
  
  // Sidebar nav buttons
  <button onClick={() => {
    setActiveNav(item.key);
    navigate(item.path);
    if (!isDesktop) setSidebarOpen(false);
  }}>
  
  // Course cards
  <div onClick={() => navigate(`/courses/${course.id}`)}>
  
  // Quick actions
  <button onClick={() => navigate("/generation/wizard")}>
}
```

---

## DESIGN CONSISTENCY RULES

All navigation elements follow:

1. **Active State**: `background: C.parchment`, `color: C.navyDeep`, `fontWeight: 600`
2. **Inactive State**: `background: transparent`, `color: C.textSecondary`, `fontWeight: 400`
3. **Hover**: Smooth transitions (0.15s-0.2s)
4. **Icons**: Serif font, 14px, opacity 0.5 inactive / 1.0 active
5. **Mobile**: Auto-close sidebar after navigation

---

## COMPLETED DASHBOARDS

✓ **Dashboard.tsx** (Faculty) - Full navigation implemented  
✓ **FacultyDashboard.tsx** - Full navigation implemented  
✓ **StudentDashboard.tsx** - Full navigation implemented  
⏳ **AdminDashboard.tsx** - TODO: Implement navigation

All navigation matches the original information architecture from `/src/app/routes.ts`.
