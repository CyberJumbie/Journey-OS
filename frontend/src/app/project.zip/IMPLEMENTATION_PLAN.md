# Journey-OS Screen Implementation Plan

## Reference Implementation
Your Faculty Dashboard (provided) is the gold standard. Every screen must match this quality level.

## Implementation Tracker

### TIER 1: CRITICAL PATH (Days 1-2)
Priority: Immediate - Most visited screens

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 1 | FacultyDashboard | COMPLETE | P0 | Reference provided |
| 2 | Login | IN PROGRESS | P0 | Updating now |
| 3 | DashboardLayout | NEXT | P0 | Base for 52 screens |
| 4 | StudentDashboard | NEXT | P0 | Second most common entry |
| 5 | AdminDashboard | NEXT | P0 | Admin entry point |

### TIER 2: AUTH & ONBOARDING (Days 3-4)
Priority: High - User acquisition funnel

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 6 | RoleSelection | TODO | P1 | Auth funnel start |
| 7 | FacultyRegistration | TODO | P1 | Missing design |
| 8 | StudentRegistration | TODO | P1 | Missing design |
| 9 | AdminRegistration | TODO | P1 | Missing design |
| 10 | FacultyOnboarding | TODO | P1 | Needs Next button |
| 11 | StudentOnboarding | TODO | P1 | Needs Next button |
| 12 | AdminOnboarding | TODO | P1 | Needs Next button |
| 13 | ForgotPassword | TODO | P1 | Auth flow |

### TIER 3: HIGH-TRAFFIC WORKFLOWS (Days 5-7)
Priority: High - Core user journeys

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 14 | AllCourses | TODO | P1 | Primary nav destination |
| 15 | CourseDashboard | TODO | P1 | Course detail view |
| 16 | QuestionReviewList | TODO | P1 | Core workflow |
| 17 | FacultyReviewQueue | TODO | P1 | Core workflow |
| 18 | ItemDetail | TODO | P1 | Question detail |
| 19 | Repository | TODO | P1 | Repository home |
| 20 | ItemBankBrowser | TODO | P1 | Advanced search |

### TIER 4: GENERATION WORKFLOW (Days 8-9)
Priority: Medium - Key feature

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 21 | GenerationSpecificationWizard | TODO | P2 | Multi-step wizard |
| 22 | GenerateQuestionsSyllabus | TODO | P2 | Generation flow |
| 23 | GenerateQuestionsTopic | TODO | P2 | Generation flow |
| 24 | GenerateTest | TODO | P2 | Test builder |
| 25 | GenerateQuiz | TODO | P2 | Quiz builder |
| 26 | BatchProgress | TODO | P2 | Progress tracking |

### TIER 5: COURSE MANAGEMENT (Days 10-11)
Priority: Medium - Setup workflows

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 27 | CreateCourse | TODO | P2 | Course wizard |
| 28 | UploadSyllabus | TODO | P2 | Upload interface |
| 29 | SyllabusProcessing | TODO | P2 | Processing status |
| 30 | SyllabusEditor | TODO | P2 | Structure editor |
| 31 | ReviewSyllabusMapping | TODO | P2 | AI mapping review |
| 32 | CourseReady | TODO | P2 | Completion screen |
| 33 | WeekView | TODO | P2 | Weekly overview |

### TIER 6: ANALYTICS (Days 12-13)
Priority: Medium - Reporting

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 34 | Analytics | TODO | P2 | Analytics home |
| 35 | CourseAnalytics | TODO | P2 | Course-level stats |
| 36 | PersonalDashboard | TODO | P2 | Personal analytics |
| 37 | BlueprintCoverage | TODO | P2 | Coverage heatmap |

### TIER 7: ADMIN TOOLS (Days 14-15)
Priority: Low - Administrative

| # | Screen | Status | Priority | Notes |
|---|--------|--------|----------|-------|
| 38 | SetupWizard | TODO | P3 | Institution setup |
| 39 | FrameworkManagement | TODO | P3 | USMLE frameworks |
| 40 | FacultyManagement | TODO | P3 | Faculty admin |
| 41 | KnowledgeBrowser | TODO | P3 | Knowledge graph |
| 42 | ILOManagement | TODO | P3 | Learning outcomes |
| 43 | DataIntegrityDashboard | TODO | P3 | System health |
| 44 | LCMEComplianceHeatmap | TODO | P3 | Compliance tracking |

### TIER 8: SUPPORTING SCREENS (Days 16-20)
Priority: Low - Utilities and edge cases

Remaining 34 screens including:
- Settings, Profile, Notifications
- Help, Collaborators, Templates
- Exam management
- Student practice flows
- Upload utilities
- Error pages

---

## Design System Checklist (Apply to Every Screen)

### Surface Layering
- [ ] Content area background is `cream` (#f5f3ef)
- [ ] Cards on cream use white background
- [ ] Nested elements on white use parchment background
- [ ] Inputs on white cards use parchment background
- [ ] Max ONE inverted navyDeep section per page (bookmark)

### Typography
- [ ] Page titles use serif font
- [ ] Card titles use serif font
- [ ] Body text uses sans-serif
- [ ] Labels use mono font + UPPERCASE
- [ ] Correct letter spacing on mono labels (0.08em)

### Components
- [ ] Every card has SectionMarker (dot + mono label)
- [ ] WovenField texture on inverted sections (opacity 0.015-0.02)
- [ ] AscendingSquares where appropriate
- [ ] Responsive breakpoints (mobile/tablet/desktop)
- [ ] Staggered fade-in animations (0.05s-0.3s delays)

### Interaction
- [ ] Card hover: border lightBlue + subtle shadow
- [ ] Button hover: navyDeep to blue
- [ ] Input focus: blueMid border + focus ring
- [ ] Row hover: parchment background
- [ ] Smooth transitions (0.15s-0.25s)

### Layout
- [ ] Sidebar: 240px white with borderLight right edge
- [ ] Top bar: sticky, frosted glass (white 95% + blur)
- [ ] Main grid: responsive (1 col mobile, 2-4 cols desktop)
- [ ] Card padding: 20-24px sides, 16-20px vertical
- [ ] Content padding: 28px 32px desktop, 20px 16px mobile

---

## Implementation Pattern (Copy This for Every Screen)

```tsx
import { useState, useEffect, useRef } from "react";

// TOKENS
const C = {
  navyDeep: "#002c76", navy: "#003265", blue: "#004ebc",
  blueMid: "#2b71b9", blueLight: "#00a8e1", bluePale: "#a3d9ff",
  greenDark: "#5d7203", green: "#69a338",
  ink: "#1b232a", warmGray: "#d7d3c8", cream: "#f5f3ef",
  parchment: "#faf9f6", white: "#ffffff",
  textPrimary: "#1b232a", textSecondary: "#4a5568", textMuted: "#718096",
  border: "#e2dfd8", borderLight: "#edeae4",
};

const sans = "'Source Sans 3', -apple-system, sans-serif";
const serif = "'Lora', Georgia, serif";
const mono = "'DM Mono', Menlo, monospace";

// HOOKS
function useBreakpoint() { /* ... */ }

// COMPONENTS (inline for now, will extract later)
function WovenField({ color, opacity, density }) { /* ... */ }
function AscSquares({ colors, size, gap }) { /* ... */ }
function SectionMarker({ label, color = "navy" }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ width: 5, height: 5, borderRadius: 1, background: color === "green" ? C.greenDark : C.navyDeep }} />
      <span style={{ fontFamily: mono, fontSize: 9, color: C.textMuted, letterSpacing: "0.08em", textTransform: "uppercase" }}>
        {label}
      </span>
    </div>
  );
}

// MAIN COMPONENT
export default function ScreenName() {
  const bp = useBreakpoint();
  const isMobile = bp === "mobile";
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => { setMounted(true); }, []);
  
  const fadeIn = (d = 0) => ({
    opacity: mounted ? 1 : 0,
    transform: mounted ? "translateY(0)" : "translateY(8px)",
    transition: `opacity 0.45s ease ${d}s, transform 0.45s ease ${d}s`,
  });

  return (
    <div style={{ fontFamily: sans, minHeight: "100vh", background: C.cream }}>
      {/* Sidebar + Top Bar + Content */}
    </div>
  );
}
```

---

## Next Steps

1. Complete Login page update
2. Create reusable DashboardLayout matching reference quality
3. Update StudentDashboard using DashboardLayout
4. Update AdminDashboard using DashboardLayout
5. Proceed through tiers systematically

---

## Success Criteria

A screen is "COMPLETE" when:
1. Matches reference dashboard visual quality exactly
2. All design system checklist items pass
3. Responsive on mobile/tablet/desktop
4. Proper surface layering (cream/white/parchment)
5. Animations working (staggered fade-in)
6. Typography correct (serif/sans/mono)
7. Interactive states working (hover/focus)
8. No inline colors - only token variables
