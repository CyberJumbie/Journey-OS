/**
 * LOGIN PAGE — UNIFIED DESIGN SYSTEM EXAMPLE
 * 
 * This is a reference implementation showing:
 * - Split panel template (Template C)
 * - Shared molecules (WovenField, AscendingSquares, LogoWordmark)
 * - Correct surface layering (white brand panel, cream form side, white card)
 * - Typography hierarchy (serif headings, mono labels uppercase)
 * - useBreakpoint hook for responsive behavior
 * 
 * Use this as a pattern for all auth pages.
 */

import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { Eye, EyeOff } from "lucide-react";
import { Card, CardContent } from "../../components/ui/card";
import { WovenField } from "../../components/shared/woven-field";
import { AscendingSquares } from "../../components/shared/ascending-squares";
import { LogoWordmark } from "../../components/shared/logo-wordmark";
import { useBreakpoint } from "../../hooks/useBreakpoint";

const ROLES = [
  { id: "faculty", label: "Faculty", desc: "Instructors & educators" },
  { id: "student", label: "Student", desc: "Med school learners" },
  { id: "admin", label: "Admin", desc: "Institutional admins" },
  { id: "advisor", label: "Advisor", desc: "Academic advisors" }
];

export default function LoginPageUnified() {
  const navigate = useNavigate();
  const breakpoint = useBreakpoint();
  const isMobile = breakpoint === "mobile";
  const isTablet = breakpoint === "tablet";

  const [activeRole, setActiveRole] = useState("faculty");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email || !password) {
      setError("Please fill in all fields");
      return;
    }

    // Route based on role
    const routes = {
      faculty: "/dashboard",
      student: "/student-dashboard",
      admin: "/admin",
      advisor: "/dashboard"
    };

    navigate(routes[activeRole as keyof typeof routes] || "/dashboard");
  };

  return (
    <div className="flex min-h-screen bg-[--cream]" style={{ flexDirection: isMobile ? "column" : "row" }}>
      {/* ═══════════════ LEFT: BRAND PANEL (white) ═══════════════ */}
      <div
        className="relative overflow-hidden bg-white border-r border-[--border-light]"
        style={{
          flex: isMobile ? "none" : isTablet ? "0 0 340px" : "0 0 480px",
          minHeight: isMobile ? "auto" : "100vh",
          padding: isMobile ? "32px 24px" : isTablet ? "40px 32px" : "48px 44px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          borderRight: isMobile ? "none" : undefined,
          borderBottom: isMobile ? "1px solid var(--border-light)" : undefined
        }}
      >
        <WovenField color="var(--navy-deep)" opacity={0.02} density={14} />

        {/* Top Section */}
        <div style={{ position: "relative", zIndex: 1 }}>
          <LogoWordmark size={isMobile ? "sm" : "md"} className="mb-6" />

          <AscendingSquares
            colors={["var(--navy-deep)", "var(--blue)", "var(--blue-mid)", "var(--green)"]}
            size={isMobile ? 10 : 14}
            gap={4}
            className="mb-6"
          />

          <h1
            className="font-serif font-bold text-[--navy-deep] tracking-[-0.015em] mb-4"
            style={{
              fontSize: isMobile ? "26px" : isTablet ? "28px" : "36px",
              lineHeight: 1.2,
              maxWidth: 360
            }}
          >
            Every thread of your curriculum, woven together.
          </h1>

          <p
            className="text-[--text-secondary] leading-[1.75]"
            style={{
              fontSize: isMobile ? "14px" : "15px",
              maxWidth: 340,
              marginBottom: isMobile ? 0 : 32
            }}
          >
            AI-powered assessment generation, curriculum mapping, and student mastery tracking — all connected in one knowledge graph.
          </p>
        </div>

        {/* Bottom Section — Pillar Grid (desktop only) */}
        {!isMobile && (
          <div style={{ position: "relative", zIndex: 1 }} className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              {[
                { color: "var(--navy-deep)", label: "Structural" },
                { color: "var(--blue)", label: "Interactive" },
                { color: "var(--blue-mid)", label: "Connected" },
                { color: "var(--green)", label: "Educational" }
              ].map((pillar, i) => (
                <div
                  key={i}
                  className="rounded-[--radius-lg] p-3 border border-[--border-light] backdrop-blur-sm"
                  style={{ background: `${pillar.color}08` }}
                >
                  <div
                    className="w-3 h-3 rounded-sm mb-2"
                    style={{ background: pillar.color }}
                  />
                  <span className="font-mono text-[9px] uppercase tracking-wider text-[--text-muted]">
                    {pillar.label}
                  </span>
                </div>
              ))}
            </div>

            <p className="font-mono text-[8px] uppercase tracking-wider text-[--text-muted] text-center pt-2">
              Morehouse School of Medicine
            </p>
          </div>
        )}
      </div>

      {/* ═══════════════ RIGHT: FORM PANEL (cream) ═══════════════ */}
      <div
        className="flex-1 flex items-center justify-center"
        style={{
          padding: isMobile ? "24px 20px" : isTablet ? "32px 24px" : "48px 32px"
        }}
      >
        <div style={{ width: "100%", maxWidth: 400 }}>
          {/* White card on cream background */}
          <Card variant="default" className="p-8 shadow-[--shadow-panel]">
            <CardContent className="p-0 space-y-6">
              {/* Header */}
              <div>
                <h2 className="font-serif text-[28px] font-bold text-[--navy-deep] tracking-[-0.01em] mb-2">
                  Sign In
                </h2>
                <p className="text-[--text-secondary] text-[14px]">
                  Choose your role and enter your credentials
                </p>
              </div>

              {/* Role Tabs */}
              <div
                className="flex gap-0.5 bg-[--parchment] rounded-[--radius-lg] p-1 border border-[--border-light]"
              >
                {ROLES.map((role) => (
                  <button
                    key={role.id}
                    onClick={() => setActiveRole(role.id)}
                    className={`
                      flex-1 px-3 py-2 rounded-[--radius-md] font-sans text-[13px] font-medium
                      transition-all duration-[--transition-default]
                      ${
                        activeRole === role.id
                          ? "bg-white text-[--navy-deep] shadow-[--shadow-subtle]"
                          : "bg-transparent text-[--text-muted] hover:text-[--text-secondary]"
                      }
                    `}
                  >
                    {role.label}
                  </button>
                ))}
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Email Field */}
                <div>
                  <label
                    htmlFor="email"
                    className="block font-mono text-[10px] uppercase tracking-[--letter-spacing-wide] text-[--text-muted] mb-1.5"
                  >
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@msm.edu"
                    className="w-full bg-[--parchment] border border-[--border] rounded-[--radius-lg] px-4 py-3
                             font-sans text-[15px] text-[--ink] placeholder:text-[--text-muted]
                             focus:border-[--blue-mid] focus:shadow-[--shadow-focus] focus:outline-none
                             transition-all duration-[--transition-default]"
                  />
                </div>

                {/* Password Field */}
                <div>
                  <label
                    htmlFor="password"
                    className="block font-mono text-[10px] uppercase tracking-[--letter-spacing-wide] text-[--text-muted] mb-1.5"
                  >
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[--parchment] border border-[--border] rounded-[--radius-lg] px-4 py-3 pr-12
                               font-sans text-[15px] text-[--ink] placeholder:text-[--text-muted]
                               focus:border-[--blue-mid] focus:shadow-[--shadow-focus] focus:outline-none
                               transition-all duration-[--transition-default]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[--text-muted] hover:text-[--text-secondary] transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {/* Remember Me + Forgot Password */}
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded border-[--border] text-[--navy-deep] 
                               focus:ring-2 focus:ring-[--blue-mid] focus:ring-offset-0"
                    />
                    <span className="text-[14px] text-[--text-secondary] group-hover:text-[--ink] transition-colors">
                      Remember me
                    </span>
                  </label>

                  <Link
                    to="/forgot-password"
                    className="text-[14px] text-[--blue-mid] hover:text-[--navy-deep] transition-colors font-medium"
                  >
                    Forgot password?
                  </Link>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="bg-[--danger-bg] border border-[--danger]/20 rounded-[--radius-md] p-3">
                    <p className="text-[13px] text-[--danger]">{error}</p>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full bg-[--navy-deep] text-white py-3 rounded-[--radius-md]
                           font-sans text-[15px] font-semibold
                           hover:bg-[--blue] active:scale-[0.98]
                           transition-all duration-[--transition-default]
                           shadow-[--shadow-subtle] hover:shadow-[--shadow-card]"
                >
                  Sign In
                </button>
              </form>

              {/* Sign Up Link */}
              <div className="text-center pt-4 border-t border-[--border-light]">
                <p className="text-[14px] text-[--text-secondary]">
                  Don't have an account?{" "}
                  <Link
                    to="/role-selection"
                    className="text-[--blue-mid] hover:text-[--navy-deep] font-medium transition-colors"
                  >
                    Sign up
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
