# Journey-OS Complete Screen Update Plan
## Applying the 6-Rule Dashboard Mental Model to All 78 Screens

---

## THE 6 CORE RULES (from Dashboard Reference)

```
1. CREAM BACKGROUND        → Content area is cream (#f5f3ef), not white
2. ONE BOOKMARK            → Max ONE navyDeep inverted section per page  
3. SURFACE HIERARCHY       → Cards white on cream, nested elements parchment on white
4. CONSISTENT CARD ANATOMY → SectionMarker (dot + mono label) + serif title on every card
5. TYPE TRIO               → Serif for titles, sans for body, mono for labels (UPPERCASE)
6. SEMANTIC COLOR REUSE    → Green/blue/warning mean the same thing everywhere
```

---

## COMPLETED SCREENS (3/84)

✓ **Dashboard.tsx** (Faculty) - Reference implementation
✓ **StudentDashboard.tsx** - Self-contained dashboard pattern  
✓ **AdminDashboard.tsx** - Self-contained dashboard pattern
✓ **Login.tsx** - Split panel auth pattern

---

## SYSTEMATIC UPDATE SCHEDULE

### PHASE 1: AUTH & ONBOARDING (Priority: P0 - User Acquisition)
**Pattern:** Split panel (white brand left, cream form right) OR centered flow

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| RoleSelection.tsx | TODO | Split panel | Add WovenField, AscSquares, 4 role cards on cream |
| FacultyRegistration.tsx | TODO | Split panel | White card on cream, parchment inputs |
| StudentRegistration.tsx | TODO | Split panel | White card on cream, parchment inputs |
| AdminRegistration.tsx | TODO | Split panel | White card on cream, access code field |
| ForgotPassword.tsx | TODO | Split panel | White card on cream, email input |
| EmailVerification.tsx | TODO | Centered | White card on cream, status display |
| FacultyOnboarding.tsx | TODO | Centered flow | Add Next button, progress dots, cream bg |
| StudentOnboarding.tsx | TODO | Centered flow | Add Next button, progress dots, cream bg |
| AdminOnboarding.tsx | TODO | Centered flow | Add Next button, progress dots, cream bg |

**Estimated:** 2 days (9 screens)

---

### PHASE 2: COURSE MANAGEMENT (Priority: P1 - Core Workflow)
**Pattern:** Dashboard shell (sidebar + top bar + cream content)

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| AllCourses.tsx | TODO | Dashboard | Grid of white cards on cream, SectionMarkers |
| CourseDashboard.tsx | TODO | Dashboard | KPI strip bookmark + white cards |
| CreateCourse.tsx | TODO | Wizard | Centered white card on cream, step indicator |
| UploadSyllabus.tsx | TODO | Upload | White card on cream, drag-drop zone parchment |
| SyllabusProcessing.tsx | TODO | Status | White card on cream, progress indicator |
| SyllabusEditor.tsx | TODO | Editor | White card on cream, parchment text areas |
| ReviewSyllabusMapping.tsx | TODO | Review | White card on cream, mapping rows |
| CourseReady.tsx | TODO | Success | White card on cream, celebration state |
| WeekView.tsx | TODO | Dashboard | Week overview with white cards |
| WeekMaterialsUpload.tsx | TODO | Upload | White card on cream, file list parchment |
| LectureUpload.tsx | TODO | Upload | White card on cream, slide preview |
| LectureProcessing.tsx | TODO | Status | White card on cream, AI processing |
| OutcomeMapping.tsx | TODO | Mapping | White card on cream, SLO rows |
| SubConceptReviewQueue.tsx | TODO | Review | White card on cream, concept cards |

**Estimated:** 3 days (14 screens)

---

### PHASE 3: QUESTION WORKFLOWS (Priority: P1 - Core Feature)
**Pattern:** Dashboard shell with review/detail layouts

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| QuestionReviewList.tsx | TODO | List | White card on cream, filter tabs |
| FacultyReviewQueue.tsx | TODO | Queue | White card on cream, question cards parchment |
| ItemDetail.tsx | TODO | Detail | White card on cream, question display |
| QuestionDetailView.tsx | TODO | Detail | White card on cream, full question |
| AIRefinement.tsx | TODO | Editor | White card on cream, refinement UI |
| ConversationalRefinement.tsx | TODO | Chat | White card on cream, message bubbles parchment |
| QuestionHistory.tsx | TODO | Timeline | White card on cream, version history |

**Estimated:** 2 days (7 screens)

---

### PHASE 4: GENERATION WIZARDS (Priority: P1 - Key Feature)
**Pattern:** Multi-step wizard, centered white card on cream

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| GenerationSpecificationWizard.tsx | TODO | Wizard | Step progress, white card, parchment selects |
| GenerateQuestionsSyllabus.tsx | TODO | Wizard | Topic selection, white card on cream |
| GenerateQuestionsTopic.tsx | TODO | Wizard | Knowledge browser, white card on cream |
| GenerateTest.tsx | TODO | Wizard | Blueprint builder, white card on cream |
| GenerateQuiz.tsx | TODO | Wizard | Quick quiz, white card on cream |
| GenerateHandout.tsx | TODO | Wizard | Handout config, white card on cream |
| BatchProgress.tsx | TODO | Status | White card on cream, live progress |

**Estimated:** 2 days (7 screens)

---

### PHASE 5: REPOSITORY & ITEM BANK (Priority: P2 - Supporting Feature)
**Pattern:** Dashboard shell with search/filter

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| Repository.tsx | TODO | Dashboard | Grid/list view, white cards on cream |
| ItemBankBrowser.tsx | TODO | Browser | Advanced search, white card filters |

**Estimated:** 1 day (2 screens)

---

### PHASE 6: ANALYTICS & REPORTING (Priority: P2 - Insights)
**Pattern:** Dashboard shell with charts/graphs

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| Analytics.tsx | TODO | Dashboard | KPI strip + chart cards white on cream |
| CourseAnalytics.tsx | TODO | Dashboard | Course-specific charts, white cards |
| BlueprintCoverage.tsx | TODO | Heatmap | White card on cream, coverage grid |
| PersonalDashboard.tsx | TODO | Dashboard | Personal stats, white cards |

**Estimated:** 1.5 days (4 screens)

---

### PHASE 7: STUDENT SCREENS (Priority: P2 - Student Experience)
**Pattern:** Dashboard shell, student-focused UI

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| StudentProgress.tsx | TODO | Dashboard | Progress tracking, white cards |
| StudentPractice.tsx | TODO | Practice | Question interface, white card |
| StudentQuestionView.tsx | TODO | Question | Full-screen question, white card |
| StudentResults.tsx | TODO | Results | Score breakdown, white cards |
| StudentAnalytics.tsx | TODO | Dashboard | Performance charts, white cards |

**Estimated:** 1.5 days (5 screens)

---

### PHASE 8: ADMIN TOOLS (Priority: P3 - Administrative)
**Pattern:** Dashboard shell, admin-specific layouts

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| SetupWizard.tsx | TODO | Wizard | Institution setup, white cards |
| FrameworkManagement.tsx | TODO | Management | Framework config, white cards |
| ILOManagement.tsx | TODO | Management | Learning outcomes, white cards |
| FacultyManagement.tsx | TODO | Management | User admin, white cards |
| KnowledgeBrowser.tsx | TODO | Browser | Knowledge graph, white cards |
| DataIntegrityDashboard.tsx | TODO | Dashboard | System health, white cards |
| LCMEComplianceHeatmap.tsx | TODO | Heatmap | Compliance grid, white card |
| LCMEElementDrillDown.tsx | TODO | Detail | Element detail, white card |
| SubConceptDetail.tsx | TODO | Detail | Concept detail, white card |
| FULFILLSReviewQueue.tsx | TODO | Review | Mapping queue, white cards |

**Estimated:** 2 days (10 screens)

---

### PHASE 9: EXAM MANAGEMENT (Priority: P3 - Supporting)
**Pattern:** Dashboard shell with assembly/assignment UI

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| ExamAssembly.tsx | TODO | Builder | Exam construction, white cards |
| ExamAssignment.tsx | TODO | Form | Student assignment, white card |
| RetiredExamUpload.tsx | TODO | Upload | Retired exam import, white card |

**Estimated:** 1 day (3 screens)

---

### PHASE 10: SUPPORTING SCREENS (Priority: P4 - Utilities)
**Pattern:** Various, apply 6 rules to each

| File | Status | Pattern | Key Changes |
|------|--------|---------|-------------|
| Collaborators.tsx | TODO | Management | Team management, white cards |
| QuestionTemplates.tsx | TODO | Library | Template gallery, white cards |
| BulkOperations.tsx | TODO | Bulk | Batch operations, white card |
| FacultyQuestionUpload.tsx | TODO | Upload | Question import, white card |
| Help.tsx | TODO | Help | Help articles, white cards |
| Profile.tsx | TODO | Form | User profile, white card |
| Settings.tsx | TODO | Settings | App settings, white cards |
| Notifications.tsx | TODO | List | Notification feed, white cards |
| NotFound.tsx | TODO | Error | 404 page, white card on cream |

**Estimated:** 2 days (9 screens)

---

## IMPLEMENTATION CHECKLIST (Copy for Each Screen)

Before marking a screen as complete, verify:

### Surface Layering
- [ ] Content area background is `cream` (#f5f3ef)
- [ ] Cards on cream use `white` background
- [ ] Nested elements on white use `parchment` background  
- [ ] Inputs on white cards use `parchment` background
- [ ] Max ONE inverted `navyDeep` section per page

### Typography
- [ ] Page titles use `serif` font
- [ ] Card titles use `serif` font
- [ ] Body text uses `sans` font
- [ ] All labels use `mono` font + UPPERCASE
- [ ] Correct letter spacing on mono (0.08em for labels)

### Components
- [ ] Every card has SectionMarker (5px dot + mono label)
- [ ] WovenField texture on navyDeep sections (opacity 0.015)
- [ ] AscendingSquares where appropriate (inverted sections)
- [ ] Responsive breakpoints (mobile/tablet/desktop)
- [ ] Staggered fade-in animations (0.05s-0.3s delays)

### Interaction
- [ ] Card hover: borderLight → blueMid + subtle shadow
- [ ] Button primary: navyDeep bg, hover → blue
- [ ] Input focus: blueMid border + 3px focus ring
- [ ] Row hover: parchment background
- [ ] Smooth transitions (0.15s-0.25s)

### Layout
- [ ] Dashboard: Sidebar 240px white, top bar frosted glass
- [ ] Auth: Split panel OR centered white card on cream
- [ ] Cards: Padding 20-24px sides, 16-20px vertical
- [ ] Content: Max-width 1200px, padding 28px 32px desktop
- [ ] Mobile: Sidebar overlay, reduced padding

---

## PATTERN LIBRARY REFERENCE

### Dashboard Pattern (52 screens)
```tsx
// Self-contained: sidebar + top bar + cream content
<div style={{ fontFamily: sans, minHeight: "100vh", background: C.cream }}>
  {sidebar}
  {overlay}
  <div style={{ marginLeft: isDesktop ? 240 : 0 }}>
    <header style={{ position: "sticky", background: `${C.white}F2` }}>
      {/* Top bar */}
    </header>
    <main style={{ padding: "28px 32px", maxWidth: 1200 }}>
      {/* KPI strip bookmark (navyDeep) */}
      {/* White cards on cream */}
    </main>
  </div>
</div>
```

### Auth Pattern (9 screens)
```tsx
// Split panel: white brand left, cream form right
<div style={{ display: "flex", minHeight: "100vh", background: C.cream }}>
  <div style={{ flex: "0 0 480px", background: C.white }}>
    <WovenField />
    <Logo />
    <AscendingSquares />
    {/* Brand content */}
  </div>
  <div style={{ flex: 1 }}>
    <div style={{ maxWidth: 400 }}>
      <div style={{ background: C.white, borderRadius: 12, padding: 32 }}>
        {/* Form */}
      </div>
    </div>
  </div>
</div>
```

### Wizard Pattern (14 screens)
```tsx
// Centered: white card on cream, progress indicator
<div style={{ minHeight: "100vh", background: C.cream }}>
  <div style={{ maxWidth: 640, margin: "0 auto", padding: "48px 24px" }}>
    {/* Progress dots */}
    <div style={{ background: C.white, borderRadius: 12, padding: 32 }}>
      {/* Step content */}
    </div>
    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 24 }}>
      <button>Back</button>
      <button>Next</button>
    </div>
  </div>
</div>
```

---

## ESTIMATED TIMELINE

- Phase 1 (Auth): 2 days
- Phase 2 (Courses): 3 days
- Phase 3 (Questions): 2 days
- Phase 4 (Generation): 2 days
- Phase 5 (Repository): 1 day
- Phase 6 (Analytics): 1.5 days
- Phase 7 (Student): 1.5 days
- Phase 8 (Admin): 2 days
- Phase 9 (Exams): 1 day
- Phase 10 (Supporting): 2 days

**Total:** ~18 working days for 81 remaining screens

---

## SUCCESS METRICS

A screen passes quality check when:
1. All 20 checklist items verified
2. Visual comparison matches Dashboard reference quality
3. Responsive behavior tested (mobile/tablet/desktop)
4. No inline hex colors (only C.tokenName variables)
5. Proper component hierarchy (no Layout wrappers for dashboards)

---

## NEXT ACTIONS

1. Complete AdminDashboard (in progress)
2. Start Phase 1: Auth & Onboarding (9 screens, 2 days)
3. Move through phases systematically
4. Update this tracker as screens complete
5. Mark each screen ✓ when all 20 checklist items pass
