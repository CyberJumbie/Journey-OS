# Journey-OS Surface Layering System — Visual Reference

## The Three-Layer Mental Model

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   LAYER 3: WHITE (#ffffff)                                          │
│   • Primary reading surfaces                                        │
│   • Active tabs, selected states                                    │
│   • Question content areas                                          │
│   • Modal bodies                                                    │
│   • Cards on CREAM backgrounds                                      │
│                                                                     │
│     ┌─────────────────────────────────────────────────────────┐     │
│     │                                                           │     │
│     │   LAYER 2: PARCHMENT (#faf9f6)                            │     │
│     │   • Cards on WHITE backgrounds                            │     │
│     │   • Form panels                                           │     │
│     │   • Input field backgrounds                               │     │
│     │   • Sidebar active item backgrounds                       │     │
│     │   • Table header rows                                     │     │
│     │   • Things that "float" on white                          │     │
│     │                                                           │     │
│     │     ┌─────────────────────────────────────────────┐       │     │
│     │     │                                               │       │     │
│     │     │   LAYER 1: CREAM (#f5f3ef)                    │       │     │
│     │     │   • Page backgrounds                          │       │     │
│     │     │   • Dashboard content areas                   │       │     │
│     │     │   • The "desk surface"                        │       │     │
│     │     │   • Visible between cards                     │       │     │
│     │     │   • Lowest elevation                          │       │     │
│     │     │                                               │       │     │
│     │     └─────────────────────────────────────────────┘       │     │
│     │                                                           │     │
│     └─────────────────────────────────────────────────────────┘     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Surface Decision Matrix

| Parent Surface | Card Variant    | Card Background      | Input Background | Button Background |
|----------------|-----------------|----------------------|------------------|-------------------|
| cream          | `default`       | white                | parchment        | navyDeep          |
| white          | `elevated`      | parchment            | white            | navyDeep          |
| parchment      | `default`       | white                | cream            | navyDeep          |
| navyDeep       | `inverted`      | white/0.06 (frosted) | white/0.1        | white             |

---

## Real-World Examples

### Example 1: Faculty Dashboard

```
STRUCTURE:
┌─────────────────────────────────────────────────────┐
│ DashboardLayout (sidebar: white)                    │
├─────────────────────────────────────────────────────┤
│ Content Area (cream background)                     │
│                                                     │
│   ┌─────────────────────────────────────────┐       │
│   │ KPI Strip (navyDeep — THE BOOKMARK)     │       │
│   │   • Inverted cards (frosted white)      │       │
│   │   • WovenField texture                  │       │
│   └─────────────────────────────────────────┘       │
│                                                     │
│   ┌─────────────────────┐  ┌──────────────────┐    │
│   │ Card (white)        │  │ Card (white)     │    │
│   │   SectionMarker     │  │   SectionMarker  │    │
│   │   CardTitle         │  │   CardTitle      │    │
│   │   Content...        │  │   Table:         │    │
│   │                     │  │     • header: parchment
│   │   Nested panel:     │  │     • rows: white│    │
│   │   • parchment bg    │  │     • hover: parchment
│   └─────────────────────┘  └──────────────────┘    │
│                                                     │
└─────────────────────────────────────────────────────┘

CODE:
<DashboardLayout>
  <div className="p-6 bg-[--cream] space-y-6">
    {/* THE BOOKMARK */}
    <div className="bg-[--navy-deep] rounded-[--radius-2xl] p-6 relative">
      <WovenField />
      <StatCard variant="inverted" />
    </div>

    {/* Regular cards */}
    <div className="grid grid-cols-2 gap-6">
      <Card variant="default"> {/* white on cream */}
        <CardHeader>
          <SectionMarker label="Courses" />
          <CardTitle>My Courses</CardTitle>
        </CardHeader>
        <CardContent>
          {/* nested panel */}
          <div className="bg-[--parchment] p-4 rounded-lg">
            {/* parchment panel on white card */}
          </div>
        </CardContent>
      </Card>

      <Card variant="default">
        <CardContent>
          <table>
            <thead className="bg-[--parchment]">
              <tr><th>Column</th></tr>
            </thead>
            <tbody className="bg-white">
              <tr className="hover:bg-[--parchment]">
                <td>Data</td>
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  </div>
</DashboardLayout>
```

---

### Example 2: Login Page (Split Panel)

```
STRUCTURE:
┌──────────────────────┬────────────────────────────────┐
│ Brand Panel (white)  │ Form Panel (cream)             │
│                      │                                │
│ • WovenField         │   ┌────────────────────┐       │
│ • LogoWordmark       │   │ Card (white)       │       │
│ • AscendingSquares   │   │                    │       │
│ • Headline (serif)   │   │ • Role tabs        │       │
│ • Subtitle (sans)    │   │   (parchment bg)   │       │
│                      │   │ • Inputs           │       │
│ • Pillar grid        │   │   (parchment bg)   │       │
│ • Institution name   │   │ • Button           │       │
│                      │   │   (navyDeep)       │       │
│                      │   └────────────────────┘       │
│                      │                                │
└──────────────────────┴────────────────────────────────┘

CODE:
<div className="flex min-h-screen bg-[--cream]">
  {/* LEFT: white brand panel */}
  <div className="flex-[0_0_480px] bg-white relative">
    <WovenField />
    <LogoWordmark />
    <AscendingSquares />
    <h1>Headline</h1>
    <p>Subtitle</p>
  </div>

  {/* RIGHT: cream form panel */}
  <div className="flex-1 flex items-center justify-center p-12">
    <Card variant="default" className="max-w-md"> {/* white on cream */}
      {/* Role tabs with parchment background */}
      <div className="bg-[--parchment] p-1 rounded-lg">
        <button className="bg-white">Active</button>
        <button className="bg-transparent">Inactive</button>
      </div>

      {/* Inputs with parchment background */}
      <input className="bg-[--parchment]" />

      {/* Button */}
      <button className="bg-[--navy-deep] text-white">Submit</button>
    </Card>
  </div>
</div>
```

---

### Example 3: Question Detail (Focus Mode)

```
STRUCTURE:
┌──────┬────────────────────────────┬─────────────────┐
│ Side │ Primary Panel (white)      │ Context Panel   │
│ bar  │                            │ (parchment)     │
│      │ • Question stem (serif)    │                 │
│ (64) │ • Answer options           │ • Metadata      │
│ px   │ • Rationale                │ • Framework     │
│      │ • Editor                   │ • History       │
│      │                            │ • Chat          │
│      │ (Maximum reading contrast) │ (Secondary info)│
└──────┴────────────────────────────┴─────────────────┘

CODE:
<div className="flex min-h-screen">
  {/* Collapsed sidebar */}
  <div className="w-16 bg-white border-r border-[--border-light]">
    {/* icons only */}
  </div>

  {/* Primary panel — white bg for reading */}
  <div className="flex-1 bg-white p-8">
    <h2 className="font-serif text-[24px] text-[--navy-deep]">
      Question Stem
    </h2>
    {/* content */}
  </div>

  {/* Context panel — parchment bg for secondary info */}
  <div className="w-[360px] bg-[--parchment] border-l border-[--border-light] p-6">
    <SectionMarker label="Metadata" />
    {/* metadata, chat, etc. */}
  </div>
</div>
```

---

## Anti-Pattern Examples

### ❌ WRONG: Same color parent and child

```tsx
// NO! Parchment card on cream background
<div className="bg-[--cream]">
  <Card variant="elevated"> {/* parchment on cream — no contrast! */}
    ...
  </Card>
</div>

// NO! White card on white background
<div className="bg-white p-6">
  <Card variant="default"> {/* white on white — invisible! */}
    ...
  </Card>
</div>
```

### ❌ WRONG: Multiple bookmarks

```tsx
// NO! Two inverted sections on one page
<div className="bg-[--cream]">
  <div className="bg-[--navy-deep]">KPI Strip</div>  {/* bookmark 1 */}
  <Card variant="default">Regular card</Card>
  <div className="bg-[--navy-deep]">Another strip</div>  {/* bookmark 2 — NO! */}
</div>

// CORRECT: Only one bookmark
<div className="bg-[--cream]">
  <div className="bg-[--navy-deep]">KPI Strip</div>  {/* THE bookmark */}
  <Card variant="default">Card 1</Card>
  <Card variant="default">Card 2</Card>
  <Card variant="default">Card 3</Card>
</div>
```

### ❌ WRONG: Input backgrounds

```tsx
// NO! White input on white card
<Card variant="default"> {/* white */}
  <input className="bg-white" /> {/* NO! */}
</Card>

// CORRECT: Parchment input on white card
<Card variant="default"> {/* white */}
  <input className="bg-[--parchment]" /> {/* YES! */}
</Card>

// CORRECT: White input on parchment card
<Card variant="elevated"> {/* parchment */}
  <input className="bg-white" /> {/* YES! */}
</Card>
```

---

## Quick Reference Chart

```
SITUATION                          SOLUTION
────────────────────────────────────────────────────────────
Dashboard content area         →   bg-[--cream]
Cards on dashboard             →   <Card variant="default"> (white)
Bookmark section               →   bg-[--navy-deep] with inverted cards
Auth page left panel           →   bg-white with WovenField
Auth page right panel          →   bg-[--cream]
Auth form card                 →   <Card variant="default"> (white)
Table header row               →   bg-[--parchment]
Table body rows                →   bg-white, hover:bg-[--parchment]
Inputs on white card           →   bg-[--parchment]
Inputs on parchment card       →   bg-white
Nested panel on white card     →   bg-[--parchment]
Active tab                     →   bg-white on parchment tab bar
Inactive tab                   →   bg-transparent on parchment tab bar
Primary button                 →   bg-[--navy-deep], text-white
Secondary button               →   bg-transparent, border, text-[--navy-deep]
```

---

## Testing Your Layering

Ask yourself:

1. **Can I see a clear contrast between parent and child?**
   - If no → wrong variant

2. **Does the card "float" visually above its parent?**
   - If no → check border and background

3. **Are inputs clearly different from their card background?**
   - If no → wrong input background

4. **Is there exactly one inverted section per page?**
   - If more than one → remove extras

5. **Do all cards have section markers?**
   - If no → add them

6. **Are all labels uppercase mono?**
   - If no → fix immediately

---

This is the visual language of Journey-OS. Every screen follows these rules. No exceptions.
