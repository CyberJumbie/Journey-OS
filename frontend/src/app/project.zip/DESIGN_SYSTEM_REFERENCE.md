# Journey OS Design System Reference

## Quick Reference Guide for MSM Education Pillar

---

## 🎨 Color Palette

### Primary Colors (True Blues - 70% usage)
```css
--navy-deep: #002c76;     /* Primary brand, buttons, headers */
--navy: #003d8f;          /* Secondary brand */
--blue: #0052a3;          /* Links, interactive */
--blue-mid: #2b71b9;      /* Focus rings, hover */
--blue-light: #6ba5d6;    /* Info states, light accents */
--blue-pale: #a8c7e5;     /* Very light accents */
```

### Accent Colors (Evergreens - 30% usage)
```css
--green-dark: #2d5f3c;    /* Dark green accents */
--green: #3e7f4d;         /* Success, faculty persona */
--lime: #97b33d;          /* Warning, review needed */
```

### Neutrals
```css
--ink: #1a1a1a;           /* Primary text (90% black) */
--text-secondary: #4a4a4a; /* Body text (70% black) */
--text-muted: #7a7a7a;    /* Subtle text (50% black) */
--warm-gray: #d4cfc6;     /* Medium neutral */
--cream: #f5f3ef;         /* Light backgrounds */
--parchment: #faf9f6;     /* Card backgrounds */
--white: #ffffff;         /* Pure white */
```

### Semantic Colors
```css
--success: var(--green);           /* #3e7f4d */
--success-bg: #e8f5ea;             /* Light green background */
--warning: var(--lime);            /* #97b33d */
--warning-bg: #f5f8e8;             /* Light lime background */
--danger: #c1272d;                 /* MSM red */
--danger-bg: #fdeced;              /* Light red background */
--info: var(--blue-light);         /* #6ba5d6 */
--info-bg: #e8f2fa;                /* Light blue background */
```

### Persona Accents
```css
--faculty: var(--green);           /* #3e7f4d */
--admin: var(--blue);              /* #0052a3 */
--advisor: var(--blue-light);      /* #6ba5d6 */
--student: var(--blue-mid);        /* #2b71b9 */
```

### Border & Focus
```css
--border-default: #c4bfb6;         /* Standard borders */
--border-light: #e8e6e0;           /* Subtle dividers */
--border-focus: var(--blue-mid);   /* Focus outline color */
```

---

## 📐 Typography

### Font Families
```css
--font-serif: "Lora", Georgia, serif;              /* Headings */
--font-sans: "Source Sans 3", system-ui, sans-serif; /* UI/Body */
--font-mono: "DM Mono", "Courier New", monospace;  /* Labels */
```

### Typography Scale
```css
/* Headings (serif for H1-H2, sans for H3-H6) */
H1: 48px / Lora / Bold / Line 1.18 / Tracking -0.02em
H2: 32px / Lora / Bold / Line 1.25 / Tracking -0.01em
H3: 24px / Lora / Bold / Line 1.33 / Tracking 0
H4: 18px / Source Sans 3 / Bold / Line 1.44 / Tracking 0
H5: 16px / Source Sans 3 / Bold / Line 1.5 / Tracking 0
H6: 14px / Source Sans 3 / Bold / Line 1.57 / Tracking 0

/* Body Text (sans) */
Large: 18px / Source Sans 3 / Regular / Line 1.72
Base: 16px / Source Sans 3 / Regular / Line 1.625
Small: 14px / Source Sans 3 / Regular / Line 1.57
XSmall: 13px / Source Sans 3 / Regular / Line 1.54

/* Labels (mono, uppercase) */
Label: 10px / DM Mono / Regular / Line 1.6 / Tracking 0.08em / UPPERCASE
```

### Font Weights
```css
--weight-regular: 400;
--weight-medium: 500;
--weight-semibold: 600;
--weight-bold: 700;
```

---

## 📏 Spacing (8px Grid)

```css
--space-1: 4px;    /* 0.5 units */
--space-2: 8px;    /* 1 unit - BASE */
--space-3: 12px;   /* 1.5 units */
--space-4: 16px;   /* 2 units */
--space-5: 20px;   /* 2.5 units */
--space-6: 24px;   /* 3 units */
--space-8: 32px;   /* 4 units */
--space-10: 40px;  /* 5 units */
--space-12: 48px;  /* 6 units */
--space-16: 64px;  /* 8 units */
--space-20: 80px;  /* 10 units */
--space-24: 96px;  /* 12 units */
```

### Common Spacing Patterns
- **Padding (cards):** 20-24px (space-5 to space-6)
- **Gap (flex/grid):** 12-16px (space-3 to space-4)
- **Margin (sections):** 32-48px (space-8 to space-12)
- **Input height:** 42px (space-10 + 2px border)
- **Button height:** 42px default, 36px small, 48px large

---

## 🔲 Border Radius

```css
--radius-sm: 3px;     /* Badges, tags */
--radius-md: 6px;     /* Buttons, inputs */
--radius-lg: 8px;     /* Cards, dialogs */
--radius-xl: 10px;    /* Large cards */
--radius-2xl: 12px;   /* Hero sections */
--radius-full: 9999px; /* Pills, avatars */
```

### Usage Guide
- **Buttons/Inputs:** `--radius-md` (6px)
- **Cards:** `--radius-lg` (8px)
- **Badges/Tags:** `--radius-sm` (3px)
- **Large containers:** `--radius-xl` (10px)
- **Avatars/Pills:** `--radius-full`

---

## 🌑 Shadows

```css
/* Warm, navy-tinted shadows */
--shadow-xs: 0 1px 2px 0 rgba(0, 44, 118, 0.05);
--shadow-sm: 0 1px 3px 0 rgba(0, 44, 118, 0.1), 
             0 1px 2px -1px rgba(0, 44, 118, 0.1);
--shadow-md: 0 4px 6px -1px rgba(0, 44, 118, 0.1), 
             0 2px 4px -2px rgba(0, 44, 118, 0.1);
--shadow-lg: 0 10px 15px -3px rgba(0, 44, 118, 0.1), 
             0 4px 6px -4px rgba(0, 44, 118, 0.1);
--shadow-xl: 0 20px 25px -5px rgba(0, 44, 118, 0.1), 
             0 8px 10px -6px rgba(0, 44, 118, 0.1);

/* Special shadows */
--shadow-nav: 0 1px 3px 0 rgba(0, 44, 118, 0.15);
--shadow-card-hover: 0 8px 16px -4px rgba(0, 44, 118, 0.12), 
                     0 4px 8px -2px rgba(0, 44, 118, 0.08);
```

### Usage Guide
- **Navigation:** `--shadow-nav`
- **Buttons:** `--shadow-sm`
- **Cards:** `--shadow-md`
- **Dialogs:** `--shadow-lg`
- **Card hover:** `--shadow-card-hover`

---

## ⏱️ Motion & Timing

```css
--duration-fast: 150ms;     /* Hover states, toggles */
--duration-normal: 250ms;   /* Buttons, cards */
--duration-slow: 400ms;     /* Modals, complex transitions */

--ease-in: cubic-bezier(0.4, 0, 1, 1);
--ease-out: cubic-bezier(0, 0, 0.2, 1);
--ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
```

### Transition Patterns
```css
/* Standard transition */
transition: all var(--duration-normal) var(--ease-out);

/* Color transition */
transition: color var(--duration-fast) var(--ease-out),
            background-color var(--duration-fast) var(--ease-out);

/* Transform transition */
transition: transform var(--duration-fast) var(--ease-out);

/* Shadow transition */
transition: box-shadow var(--duration-normal) var(--ease-out);
```

---

## 🎯 Component Patterns

### Buttons
```tsx
/* Primary */
bg-[--navy-deep] text-white hover:bg-[--navy] h-[42px] px-6 rounded-[--radius-md]

/* Secondary */
bg-[--parchment] text-[--ink] hover:bg-[--cream] border border-[--border-default]

/* Outline */
bg-transparent text-[--navy-deep] border border-[--navy-deep] hover:bg-[--navy-deep]/5

/* Ghost */
bg-transparent text-[--text-secondary] hover:bg-[--parchment] hover:text-[--ink]

/* Destructive */
bg-[--danger] text-white hover:bg-[--danger]/90
```

### Cards
```tsx
/* Standard card */
bg-[--parchment] border border-[--border-light] rounded-[--radius-lg] p-6 shadow-[--shadow-md]

/* Hoverable card */
hover:border-[--blue-mid] hover:shadow-[--shadow-card-hover] transition-all duration-[--duration-normal]

/* Interactive card */
cursor-pointer hover:scale-[1.02] active:scale-[0.98]
```

### Form Inputs
```tsx
/* Input/Textarea */
h-[42px] px-4 bg-white border border-[--border-default] rounded-[--radius-md]
focus:outline focus:outline-[1.5px] focus:outline-[--border-focus] focus:outline-offset-2

/* Error state */
border-[--danger] focus:outline-[--danger]

/* Disabled state */
opacity-50 cursor-not-allowed bg-[--cream]
```

### Badges
```tsx
/* Label badge (mono) */
px-2 py-1 rounded-[--radius-sm] text-[10px] font-mono uppercase tracking-[0.08em]

/* Semantic badges */
Success: bg-[--success-bg] text-[--green-dark] border border-[--green]/20
Warning: bg-[--warning-bg] text-[--lime] border border-[--lime]/20
Danger: bg-[--danger-bg] text-[--danger] border border-[--danger]/20
Info: bg-[--info-bg] text-[--navy-deep] border border-[--blue]/20

/* Persona badges */
Faculty: bg-[--success-bg] text-[--green]
Admin: bg-[--info-bg] text-[--blue]
Student: bg-[--blue-mid]/10 text-[--blue-mid]
```

### Focus States
```tsx
/* Standard focus */
focus-visible:outline focus-visible:outline-[1.5px] focus-visible:outline-[--border-focus] focus-visible:outline-offset-2

/* Alternative focus (for dark backgrounds) */
focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[--navy-deep]
```

---

## 📱 Responsive Breakpoints

```css
/* Mobile-first approach */
sm: 640px   /* Small tablets */
md: 768px   /* Tablets */
lg: 1024px  /* Laptops */
xl: 1280px  /* Desktops */
2xl: 1536px /* Large desktops */
```

### Common Responsive Patterns
```tsx
/* Mobile: stack, Desktop: side-by-side */
flex flex-col lg:flex-row gap-4

/* Mobile: full width, Desktop: limited width */
w-full lg:max-w-4xl

/* Hide on mobile, show on desktop */
hidden lg:flex

/* Show on mobile, hide on desktop */
flex lg:hidden
```

---

## 🎨 Chart Colors

### Sequential (for single-variable gradients)
```css
--chart-1: #002c76;  /* navy-deep */
--chart-2: #0052a3;  /* blue */
--chart-3: #2b71b9;  /* blue-mid */
--chart-4: #6ba5d6;  /* blue-light */
--chart-5: #a8c7e5;  /* blue-pale */
```

### Categorical (for multi-variable comparisons)
```css
--chart-1: #002c76;  /* navy-deep */
--chart-2: #3e7f4d;  /* green */
--chart-3: #2b71b9;  /* blue-mid */
--chart-4: #97b33d;  /* lime */
--chart-5: #6ba5d6;  /* blue-light */
--chart-6: #2d5f3c;  /* green-dark */
--chart-7: #0052a3;  /* blue */
--chart-8: #c4bfb6;  /* warm-gray */
```

---

## 🚀 Journey OS Logo Pattern

```tsx
/* Standard logo */
<div className="flex items-center gap-1">
  <span className="text-[22px] font-serif font-bold text-[--navy-deep] tracking-tight">
    Journey
  </span>
  <span className="inline-flex items-center px-2 py-0.5 rounded-[--radius-sm] border border-[--navy-deep] text-[9px] font-mono text-[--navy-deep] uppercase tracking-wider">
    OS
  </span>
</div>

/* Large logo (auth pages) */
<div className="flex items-center gap-1">
  <span className="text-[32px] font-serif font-bold text-[--navy-deep] tracking-tight">
    Journey
  </span>
  <span className="inline-flex items-center px-2 py-1 rounded-[--radius-sm] border border-[--navy-deep] text-[10px] font-mono text-[--navy-deep] uppercase tracking-wider">
    OS
  </span>
</div>

/* White logo (for dark backgrounds) */
text-white border-white
```

---

## 📖 Usage Examples

### Section Header
```tsx
<div className="space-y-2">
  <h2 className="text-[32px] font-serif font-bold text-[--navy-deep] tracking-tight">
    Section Title
  </h2>
  <p className="text-[14px] font-sans text-[--text-secondary]">
    Description text goes here
  </p>
</div>
```

### Stats Card
```tsx
<div className="bg-[--parchment] border border-[--border-light] rounded-[--radius-lg] p-6">
  <div className="flex items-start justify-between">
    <div>
      <p className="text-[10px] font-mono uppercase tracking-[0.08em] text-[--text-muted] mb-1">
        Total Questions
      </p>
      <p className="text-[32px] font-serif font-bold text-[--navy-deep]">
        1,247
      </p>
    </div>
    <div className="size-10 rounded-[--radius-md] bg-[--success-bg] flex items-center justify-center">
      <CheckCircle className="size-5 text-[--green]" />
    </div>
  </div>
</div>
```

### Action Button Group
```tsx
<div className="flex items-center gap-3">
  <button className="h-[42px] px-6 bg-[--navy-deep] text-white rounded-[--radius-md] font-sans font-semibold text-[14px] hover:bg-[--navy] transition-colors duration-[--duration-fast]">
    Primary Action
  </button>
  <button className="h-[42px] px-6 bg-transparent text-[--navy-deep] border border-[--navy-deep] rounded-[--radius-md] font-sans font-semibold text-[14px] hover:bg-[--navy-deep]/5 transition-colors duration-[--duration-fast]">
    Secondary Action
  </button>
</div>
```

---

## 🔍 Quick Tips

1. **Always use design tokens** - Use CSS custom properties like `var(--navy-deep)` instead of hardcoded hex values
2. **Serif for impact** - Use Lora (serif) only for H1/H2 to maintain elegance without sacrificing readability
3. **Mono for metadata** - Use DM Mono (uppercase) for labels, tags, and categorical information
4. **70/30 color split** - True Blues should dominate (70%), Evergreens for accents (30%)
5. **Warm shadows** - All shadows are navy-tinted for brand consistency
6. **8px grid** - All spacing should be multiples of 8px (or 4px for tight spaces)
7. **1.5px focus outlines** - All interactive elements should have visible focus states
8. **Consistent transitions** - Use standard timing values (150ms/250ms/400ms)

---

**Last Updated:** February 16, 2026  
**Design System Version:** Journey OS 1.0 - MSM Education Pillar  
**Status:** Production Ready ✅
