# Journey-OS Complete Screen Inventory
**Total Screens: 74**

---

## 📚 AUTHENTICATION & ONBOARDING (10 Screens)

### Authentication (7 screens)

**1. RoleSelection** (`/`)
- Landing page where users choose their role: Student, Faculty, or Institutional Admin
- First step in the registration/login flow

**2. Login** (`/login`)
- Unified login page with role-specific tabs
- Email/password authentication
- Links to registration and password recovery

**3. Registration** (`/register`)
- Generic registration page (redirects to role-specific)

**4. StudentRegistration** (`/register/student`)
- Student-specific registration form
- Collects: name, email, password, medical school year
- Sends verification email

**5. FacultyRegistration** (`/register/faculty`)
- Faculty-specific registration form
- Collects: name, email, password, department, teaching areas
- Sends verification email

**6. AdminRegistration** (`/register/admin`)
- Institutional admin registration form
- Requires special access code
- Collects: name, email, password, institution details
- Sends verification email

**7. ForgotPassword** (`/forgot-password`)
- Password reset request form
- Sends recovery email with reset link

**8. EmailVerification** (`/email-verification`)
- Email verification page (accessed via email link)
- Confirms email address and activates account
- Redirects to role-specific onboarding

### Onboarding (3 screens)

**9. StudentOnboarding** (`/onboarding/student`)
- First-time student setup wizard
- Collects: study goals, target exam date, preferred subjects, daily time commitment
- Sets up personalized study plan

**10. FacultyOnboarding** (`/onboarding/faculty`)
- First-time faculty setup wizard
- Collects: teaching areas, question authoring preferences, courses taught
- Quick tour of key features

**11. AdminOnboarding** (`/onboarding/admin`)
- First-time admin setup wizard
- Overview of administrative tasks
- Links to setup wizard for institution configuration

---

## 🎓 STUDENT SCREENS (6 Screens)

### Dashboard & Practice

**12. StudentDashboard** (`/student-dashboard`)
- Student home page with overview of:
  - Recent activity and study streak
  - Performance metrics (accuracy, questions answered)
  - Recommended focus areas
  - Quick access to practice modes
  - Progress toward goals
  - Upcoming milestones

**13. StudentPractice** (`/student/practice`)
- Practice session configuration screen
- Select study mode: Practice (untimed), Timed (exam simulation), Challenge (daily), Weak Areas
- Choose subjects/systems (Cardiology, Pulmonary, etc.)
- Set question count
- Configure difficulty level
- Start practice session

**14. StudentQuestionView** (`/student/practice/session`)
- Active practice session interface
- Display USMLE-style multiple choice questions
- Timer (for timed mode)
- Question counter and progress bar
- Bookmark and flag functionality
- Navigation between questions
- Submit answer and get immediate feedback
- Detailed explanations with educational content

**15. StudentResults** (`/student/practice/results`)
- Post-session results summary
- Score and percentage correct
- Time spent per question
- Performance by subject/topic
- Comparison to previous sessions
- Incorrect questions review
- Explanations for all questions
- Recommendations for improvement

**16. StudentProgress** (`/student/progress`)
- Comprehensive progress tracking dashboard
- Performance over time (charts and graphs)
- Subject mastery levels
- Weak areas identification
- Study streak tracking
- Questions answered by category
- Improvement trends
- Goal progress

**17. StudentAnalytics** (`/student/analytics`)
- Detailed performance analytics
- Breakdown by:
  - Difficulty level (Easy, Medium, Hard)
  - Bloom's Taxonomy level (Remember, Understand, Apply, Analyze)
  - USMLE content areas (Organ Systems)
  - Question type
- Time analysis (average time per question)
- Accuracy trends
- Predictive scoring
- Recommendations based on data

---

## 👨‍🏫 FACULTY SCREENS (39 Screens)

### Dashboard

**18. FacultyDashboard** (`/dashboard` or `/faculty-dashboard`)
- Faculty home page with:
  - My Sections overview (courses taught)
  - Student count and enrollment
  - Items generated, pending review, approved
  - Review queue with priority items
  - Recent activity feed
  - Quick action cards for all workflows:
    - Content Upload
    - Question Generation
    - Outcome Mapping
    - Exam Assembly
    - Upload Existing Content
    - Analytics
  - Stats: sections, students, pending reviews, approved items

### Courses (14 screens)

**19. AllCourses** (`/courses`)
- List of all courses/sections taught by faculty
- Course cards showing: code, name, student count, items generated
- Filter and search courses
- Create new course button
- Quick actions per course

**20. CreateCourse** (`/courses/create`)
- Create new course/section form
- Input: course code, name, term, credits, student count
- Set learning objectives
- Upload initial materials

**21. CourseDashboard** (`/courses/:courseId`)
- Individual course home page
- Weekly schedule view
- Course materials library
- Student roster
- Questions generated for this course
- Performance analytics
- Quick actions: upload content, generate questions, view outcomes

**22. UploadSyllabus** (`/courses/:courseId/upload-syllabus`)
- Upload course syllabus (PDF/DOCX)
- File upload interface with drag-and-drop
- Preview uploaded document
- Submit for AI processing

**23. SyllabusProcessing** (`/courses/:courseId/processing`)
- Processing status screen
- Shows AI extraction progress:
  - Document parsing
  - Learning objective extraction
  - Topic identification
  - Week-by-week breakdown
- Progress indicators and estimated time

**24. SyllabusEditor** (`/courses/syllabus-editor`)
- Edit extracted syllabus structure
- Week-by-week editor
- Add/remove topics
- Edit learning objectives (SLOs)
- Reorder content
- Save changes

**25. ReviewSyllabusMapping** (`/courses/:courseId/review-mapping`)
- Review AI-generated SLO mappings
- Shows suggested mappings to:
  - Institution Learning Outcomes (ILOs)
  - LCME standards
  - ACGME competencies
- Approve, reject, or edit mappings
- Bulk approval options

**26. CourseReady** (`/courses/:courseId/ready`)
- Course setup complete confirmation
- Summary of:
  - Weeks configured
  - Learning objectives mapped
  - Content uploaded
  - Questions generated
- Next steps recommendations
- Launch course button

**27. WeekView** (`/courses/:courseId/week/:weekId`)
- Detailed view of single week in course
- Learning objectives for the week
- Uploaded materials (lectures, readings)
- Generated questions for this week
- Student performance on week's content
- Quick actions: upload materials, generate questions, view analytics

**28. WeekMaterialsUpload** (`/courses/:courseId/week/:weekId/upload-materials`)
- Upload weekly course materials
- Multiple file upload (PDFs, PPTs, videos)
- Organize by type (lecture, reading, lab)
- Add descriptions and metadata

**29. LectureUpload** (`/courses/upload-lecture`)
- Upload individual lecture (PowerPoint, PDF, video)
- Drag-and-drop interface
- Select associated course and week
- Add lecture metadata (title, date, topics)
- Submit for AI processing

**30. LectureProcessing** (`/courses/lecture-processing`)
- Lecture processing status
- AI extracting SubConcepts from lecture content
- Progress indicators
- When complete, redirect to SubConcept review

**31. SubConceptReviewQueue** (`/courses/subconcept-review`)
- Review AI-extracted SubConcepts from lectures
- List of SubConcepts with:
  - Extracted text/definition
  - Source (lecture slide number)
  - Suggested parent Concept
  - Suggested Domain
- Approve, reject, or edit each SubConcept
- Bulk operations
- AI confidence scores

**32. OutcomeMapping** (`/courses/outcome-mapping`)
- Map course SLOs to institutional ILOs
- Two-panel interface:
  - Left: Course learning objectives
  - Right: Available ILOs from institution
- Drag-and-drop or select to create mappings
- Map to accreditation frameworks (LCME, ACGME)
- Show coverage gaps
- Submit for admin review

### Question Generation (7 screens)

**33. GenerationSpecificationWizard** (`/generation/wizard`)
- 3-step question generation wizard
- **Step 1**: Select source
  - Course/syllabus
  - Specific topics
  - SubConcepts
  - Custom text
- **Step 2**: Configure specifications
  - Question count
  - Difficulty distribution
  - Bloom's level
  - USMLE blueprint alignment
  - Item format (MCQ, case-based)
- **Step 3**: Review and generate
  - Summary of specifications
  - Estimated generation time
  - Start generation button

**34. BatchProgress** (`/generation/progress` or `/generation/batch-progress`)
- Real-time generation progress
- Shows:
  - Questions generated so far
  - Progress bar
  - Estimated time remaining
  - Preview of generated items
- Cancel option
- When complete, redirect to review queue

**35. GenerateQuestionsTopic** (`/generate/topic`)
- Quick generation for specific topic
- Topic selection dropdown
- Basic parameters (count, difficulty)
- Generate button
- Simplified version of wizard

**36. GenerateQuestionsSyllabus** (`/courses/:courseId/week/:weekId/generate` or `/generation/syllabus`)
- Generate questions from syllabus/week content
- Auto-populated with week's learning objectives
- Configure parameters
- Generate aligned to course structure

**37. GenerateTest** (`/generate/test`)
- Generate practice test/exam
- Configure:
  - Test length (number of questions)
  - Time limit
  - Coverage (topics to include)
  - Difficulty
- Blueprint validation
- Generate full test

**38. GenerateQuiz** (`/generate/quiz`)
- Generate shorter quiz
- Quick assessment format
- Fewer questions than full test
- Topic-focused

**39. GenerateHandout** (`/generate/handout`)
- Generate study handout/review sheet
- Summary format (not questions)
- Key concepts and definitions
- Study guide for students

### Question Review & Refinement (7 screens)

**40. FacultyReviewQueue** (`/questions/review`)
- Main review queue for all pending questions
- List view with filters:
  - By course
  - By priority (high, medium, low)
  - By status (pending, flagged)
  - By type (SubConcept, question)
- Each item shows:
  - Preview text
  - Source/course
  - AI confidence score
  - Time submitted
- Bulk operations (approve multiple)
- Click to open detailed review

**41. QuestionReviewList** (`/courses/:courseId/questions`)
- Review queue filtered to specific course
- Same features as main queue
- Course-specific context

**42. ItemDetail** (`/questions/:questionId`)
- Detailed view of single question for review
- Shows:
  - Full question stem
  - Answer choices
  - Correct answer highlighted
  - Detailed explanation
  - Learning objective alignment
  - Framework mappings (USMLE, Bloom's)
  - Source content reference
- Actions:
  - Approve
  - Reject
  - Flag for revision
  - Open AI refinement
  - View history

**43. QuestionDetailView** (`/questions/:questionId/detail`)
- Alternative detailed view (more metadata-focused)
- Shows psychometric properties
- Preview as student would see it
- Educational content alignment

**44. ConversationalRefinement** (`/questions/:questionId/refine`)
- Chat-based AI refinement interface
- Conversational UI to improve question
- Faculty can request specific changes:
  - "Make the distractors more challenging"
  - "Adjust difficulty to match Bloom's level 3"
  - "Add more clinical context"
- AI responds with revised version
- Iterative refinement
- Accept changes when satisfied

**45. AIRefinement** (`/questions/:questionId/ai-refine`)
- Alternative AI refinement interface
- Form-based rather than chat
- Specify exact changes needed
- Side-by-side comparison of original vs. refined

**46. QuestionHistory** (`/questions/:questionId/history`)
- Version history of question
- Shows all revisions over time
- Who made changes and when
- Revert to previous version option
- Audit trail for compliance

### Exams (3 screens)

**47. ExamAssembly** (`/exams/assembly` or `/exams/builder`)
- Build complete exam from item bank
- Two-panel interface:
  - Left: Item bank with filters
  - Right: Current exam blueprint
- Drag questions to add to exam
- Real-time blueprint validation:
  - Content coverage
  - Difficulty distribution
  - Bloom's taxonomy balance
  - USMLE alignment
- Shows gaps and recommendations
- Save exam template

**48. ExamAssignment** (`/exams/assign` or `/exams/assignment`)
- Assign completed exam to student section(s)
- Select exam from saved templates
- Choose target section(s)
- Set:
  - Release date/time
  - Due date
  - Time limit
  - Attempt limit
  - Feedback timing (immediate vs. after due date)
- Assign and notify students

**49. RetiredExamUpload** (`/exams/retired-upload` or `/exams/upload-retired`)
- Upload previously used exams
- Parse retired exam questions into item bank
- Extract:
  - Questions and answers
  - Metadata
  - Performance data
- Add to repository
- Flag as "retired" (not for future exams, but for practice)

### Repository (2 screens)

**50. Repository** (`/repository`)
- Main item bank browser
- Grid or list view of all questions
- Advanced filters:
  - Subject/topic
  - Difficulty
  - Bloom's level
  - USMLE content area
  - Status (approved, pending, flagged)
  - Date created
  - Usage count
- Search functionality
- Sort options
- Bulk operations
- Export selected items

**51. ItemBankBrowser** (`/repository/item-bank`)
- Alternative view of item bank
- More detailed browsing interface
- Shows item relationships
- Tags and categorization
- Performance data per item

### Analytics (4 screens)

**52. Analytics** (`/analytics`)
- Faculty analytics dashboard
- Overview across all courses:
  - Total questions generated
  - Items in review vs. approved
  - Student performance summary
  - Most challenging questions
  - Coverage analysis
- Charts and visualizations
- Export reports

**53. CourseAnalytics** (`/analytics/course/:courseId`)
- Analytics for specific course
- Student performance by topic
- Question difficulty analysis
- Learning objective mastery
- Identify struggling students
- Identify problematic questions
- Recommendations

**54. BlueprintCoverage** (`/analytics/blueprint-coverage`)
- USMLE blueprint coverage analysis
- Heatmap showing:
  - Which content areas are well-covered
  - Which areas need more questions
  - Gap analysis
- Helps ensure comprehensive coverage
- Recommendations for generation

**55. PersonalDashboard** (`/analytics/personal`)
- Individual faculty member's statistics
- Questions authored
- Courses taught
- Student outcomes
- Time saved using AI
- Contributions to item bank

### Faculty Question Upload

**56. FacultyQuestionUpload** (`/uploads/faculty-questions` or `/questions/upload`)
- Manual question upload (faculty-created, not AI)
- Form to enter:
  - Question stem
  - Answer choices (A-E)
  - Correct answer
  - Explanation
  - Metadata (difficulty, topics, frameworks)
- Bulk upload via CSV/Excel
- Import from Word/PDF

---

## 🛡️ ADMIN SCREENS (12 Screens)

### Dashboard

**57. AdminDashboard** (`/admin`)
- Admin home page
- Setup progress checklist (10 steps, shows 6/10 complete):
  - ✅ Institution Setup
  - ✅ Course Catalog
  - ✅ Frameworks Imported
  - ✅ Faculty Onboarded
  - ✅ Knowledge Graph
  - ✅ Data Integrity
  - ⬜ ILO Management
  - ⬜ LOD Enrichment
  - ⬜ BKT Engine
  - ⬜ Assessment Layer
- Administrative workflow cards:
  - Institution Setup
  - Framework Management
  - Faculty Management
  - Knowledge Graph
  - Outcome Management
  - Compliance & Analytics
- System stats:
  - Total users
  - Active faculty
  - Total questions
  - Storage used
- User management table
- System health indicators

### Flow 1: Foundation & Setup (6 screens)

**58. SetupWizard** (`/admin/setup` or `/admin/setup-wizard`)
- Multi-step institution configuration wizard
- **Step 1**: Institution info (name, type, accreditation)
- **Step 2**: Program hierarchy
  - Define schools (e.g., School of Medicine)
  - Define programs (e.g., MD, DO)
  - Define years/phases
- **Step 3**: Academic calendar
  - Terms/semesters
  - Important dates
- **Step 4**: Departments and disciplines
- Save and initialize database

**59. CourseCatalog** (`/admin/course-catalog`)
- Manage institutional course catalog
- List all courses across institution
- Add new courses
- Edit course metadata:
  - Course code
  - Title
  - Credits
  - Description
  - Prerequisites
  - Learning objectives
- Assign faculty to courses
- Set course status (active, archived)
- Import courses from CSV

**60. FrameworkManagement** (`/admin/frameworks`)
- Import accreditation and taxonomy frameworks
- Upload and parse:
  - **LCME Standards** (medical school accreditation)
  - **ACGME Competencies** (residency accreditation)
  - **EPA Standards** (Entrustable Professional Activities)
  - **USMLE Content Outline** (board exam blueprint)
  - **Bloom's Taxonomy** (cognitive levels)
  - **Miller's Pyramid** (competency assessment)
- Shows import status for each framework
- Map framework relationships
- Update frameworks when new versions released

**61. KnowledgeBrowser** (`/admin/knowledge` or `/admin/knowledge-browser`)
- Browse institutional knowledge graph
- Hierarchical view:
  - **Domains** (e.g., Cardiovascular System)
    - **Concepts** (e.g., Heart Failure)
      - **SubConcepts** (e.g., Systolic Dysfunction)
- Search knowledge graph
- View relationships
- See which courses cover each node
- See which questions map to each node
- Edit knowledge structure
- Add/remove nodes

**62. SubConceptDetail** (`/admin/knowledge/:uuid` or `/admin/knowledge-browser/:id`)
- Detailed view of single SubConcept
- Shows:
  - Full definition
  - Parent Concept and Domain
  - Source material (where extracted from)
  - Related SubConcepts
  - Courses that cover it
  - Questions that test it
  - Learning objectives mapped to it
- Edit SubConcept details
- Merge duplicate SubConcepts
- Assign to different parent

**63. DataIntegrityDashboard** (`/admin/data-integrity`)
- Cross-database consistency checker
- Verifies data integrity across:
  - Vector database (semantic search)
  - Graph database (relationships)
  - Relational database (structured data)
- Shows:
  - Orphaned records
  - Duplicate entries
  - Missing relationships
  - Inconsistencies
- Run integrity checks
- Automated repair options
- Export integrity reports

### Flow 2: Faculty Management

**64. FacultyManagement** (`/admin/faculty` or `/admin/faculty-management`)
- Manage faculty pipeline
- Send magic link invitations to faculty
- Review self-registration requests
- Approve or deny registrations
- Assign roles and permissions
- Assign courses to faculty
- View faculty activity:
  - Questions authored
  - Reviews completed
  - Last login
- Deactivate faculty accounts
- Bulk import faculty from CSV

### Flow 6: Outcome Mapping & Compliance (5 screens)

**65. ILOManagement** (`/admin/ilos` or `/admin/ilo-management`)
- Manage Institution Learning Outcomes (ILOs)
- Upload ILOs (CSV, Excel, PDF)
- Parse and extract ILOs
- Organize ILOs by:
  - Program (MD, DO, etc.)
  - Competency domain
  - Level (year 1-4)
- Map ILOs to accreditation frameworks:
  - LCME standards
  - ACGME competencies
- Edit ILO text and metadata
- Version control for ILO changes

**66. FULFILLSReviewQueue** (`/admin/fulfills-review`)
- Review faculty-submitted SLO → ILO mappings
- Queue of all mappings waiting for admin approval
- Each item shows:
  - Course SLO
  - Proposed ILO mapping(s)
  - Faculty who submitted
  - Date submitted
  - AI confidence score
- Actions:
  - Approve mapping
  - Reject with feedback
  - Suggest alternative ILO
- Bulk approval options
- Filter by course, program, status

**67. LCMEComplianceHeatmap** (`/admin/lcme-compliance-heatmap` or `/admin/lcme-compliance`)
- Visual heatmap of LCME compliance
- Shows all LCME standards (elements)
- Color-coded by coverage:
  - 🟢 Green: Well covered (many courses map to this)
  - 🟡 Yellow: Partially covered
  - 🔴 Red: Not covered (gap!)
- Click any element to drill down
- Shows:
  - Which courses address each standard
  - Which ILOs map to each standard
  - Student learning evidence
- Export compliance report for accreditation
- Track over time

**68. LCMEElementDrillDown** (`/admin/lcme-element-drill-down` or `/admin/lcme-compliance/:id`)
- Detailed view of single LCME element
- Shows:
  - Full standard text
  - Related ILOs
  - Courses that address this standard
  - Student assessment data
  - Evidence artifacts
- Upload supporting documentation
- Add notes for accreditation review
- Track action items if gaps exist

---

## 🔧 SHARED/UTILITY SCREENS (9 Screens)

### Profile & Settings

**69. Profile** (`/profile`)
- User profile management
- Edit personal information:
  - Name
  - Email
  - Phone
  - Photo
  - Bio
- Change password
- View account activity
- Manage connected devices
- Account statistics (role-specific)

**70. Settings** (`/settings`)
- Application settings
- **General**: Language, timezone, theme (light/dark)
- **Notifications**: Email/in-app notification preferences
- **Privacy**: Data sharing preferences
- **Accessibility**: Font size, contrast, screen reader options
- **Integrations**: Connect external tools
- **API Access**: Generate API keys (faculty/admin only)

**71. Notifications** (`/notifications`)
- Notification center
- List of all notifications:
  - Questions ready for review
  - Course updates
  - Student messages (faculty)
  - System announcements
- Mark as read
- Filter by type
- Notification preferences link

### Help & Support

**72. Help** (`/help`)
- Help center and documentation
- Searchable knowledge base
- FAQs by role
- Video tutorials
- Contact support
- Feature requests
- Report bugs

### Collaboration & Operations

**73. QuestionTemplates** (`/templates`)
- Library of question templates
- Pre-built question formats:
  - Basic MCQ
  - Clinical vignette
  - Image-based
  - Data interpretation
  - Multi-step reasoning
- Use template to create new question
- Save custom templates

**74. BulkOperations** (`/bulk-operations`)
- Bulk operations interface (faculty/admin only)
- Mass actions:
  - Bulk approve questions
  - Bulk tag items
  - Bulk export
  - Bulk delete
  - Bulk assignment
- CSV import/export
- Batch processing status

**75. Collaborators** (`/collaborators`)
- Manage course collaborators (faculty only)
- Invite co-instructors to course
- Assign permissions:
  - View only
  - Can edit content
  - Can generate questions
  - Can review and approve
- View collaborator activity
- Remove collaborators

### Error Handling

**76. NotFound** (`/*` - 404)
- 404 error page
- "Page not found" message
- Helpful links to navigate back:
  - Home/Dashboard
  - Help center
  - Common pages
- Search functionality
- Report broken link

---

## 📊 SUMMARY BY ROLE

### Student: 6 screens
- Dashboard, Practice setup, Question view, Results, Progress, Analytics

### Faculty: 39 screens
- 1 Dashboard
- 14 Course management screens
- 7 Question generation screens
- 7 Question review & refinement screens
- 3 Exam screens
- 2 Repository screens
- 4 Analytics screens
- 1 Upload screen

### Admin: 12 screens
- 1 Dashboard
- 6 Foundation & setup screens
- 1 Faculty management screen
- 4 Outcome mapping & compliance screens

### Shared: 9 screens
- 7 Authentication & onboarding
- 2 Profile & settings & notifications & help
- 2 Operations & templates & collaboration
- 1 Error page

**TOTAL: 76 SCREENS** (includes Onboarding generic screen + Collaborators)

---

## 🎯 WORKFLOW MAPPING

### Flow 1: Foundation & Admin Setup
Screens 58-63 (Setup Wizard, Course Catalog, Frameworks, Knowledge Browser, SubConcept Detail, Data Integrity)

### Flow 2: Faculty Onboarding
Screen 64 (Faculty Management)

### Flow 3: Content Upload & Concept Review
Screens 29-32 (Lecture Upload, Processing, SubConcept Review, Syllabus components)

### Flow 4: SLO Extraction & ILO Mapping
Screens 24, 25, 32, 65-66 (Syllabus Editor, Review Mapping, Outcome Mapping, ILO Management, FULFILLS Review)

### Flow 5: Question Generation & Faculty Review
Screens 33-46 (Generation Wizard, Batch Progress, Review Queue, Item Detail, Refinement)

### Flow 6: Coverage Chain & Compliance
Screens 65-68 (ILO Management, FULFILLS Review, LCME Compliance Heatmap, Element Drill-Down)

### Flow 7: Exam Assembly & Assignment
Screens 47-48 (Exam Assembly, Exam Assignment)

### Flow 8: Retired Exams & Faculty Questions
Screens 49, 56 (Retired Exam Upload, Faculty Question Upload)

### Flow 9: Student Learning
Screens 12-17 (Student Dashboard through Analytics)

---

## 🎨 ALL SCREENS FOLLOW JOURNEY-OS DESIGN SYSTEM

- **Color Palette**: White backgrounds, #FFC645 primary (warm yellow/orange), semantic colors
- **Typography**: Inter font family
- **Spacing**: 8px-based spacing system
- **Shadows**: Subtle elevation with border + shadow
- **Interactions**: Hover states, smooth transitions (200-300ms)
- **Responsive**: All screens work on desktop and tablet
- **Accessible**: WCAG 2.1 AA compliant color contrasts

Every screen is production-ready and fully wired with navigation! 🚀
