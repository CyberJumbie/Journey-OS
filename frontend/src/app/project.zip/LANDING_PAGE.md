# Journey OS Landing Page

## Overview

The Journey OS landing page is now the home page (`/`) of the website. It features:

- **Responsive design** - Optimized for mobile, tablet, and desktop
- **Woven thread visual motif** - Canvas-based animated background
- **Interactive sections** - Persona-based workflows, step-through guides
- **Waitlist form** - Collects email, role, and institution

## Routes

- **`/`** - Landing page with waitlist (NEW)
- **`/role-selection`** - Role selection for registration (moved from `/`)
- **`/login`** - Login page
- **`/register/student`** - Student registration
- **`/register/faculty`** - Faculty registration
- **`/register/admin`** - Admin registration

## Design System Alignment

The landing page follows the MSM Education Pillar design system:

### Colors
- **Primary**: Navy Deep (#002c76)
- **Accent**: Green (#69a338), Blue Mid (#2b71b9)
- **Neutrals**: Cream (#f5f3ef), Parchment (#faf9f6), Warm Gray (#d7d3c8)

### Typography
- **Serif**: Lora (headings)
- **Sans**: Source Sans 3 (body, UI)
- **Mono**: DM Mono (labels, tags)

### Key Features

1. **Persona Tabs** - Switch between Faculty, Admin, Advisors, and Students to see role-specific benefits
2. **Interactive Step-Through** - 4-step workflow for each persona
3. **Animated Stats** - Counter animations when scrolling into view
4. **Coverage Chain** - Visual representation of the evidence chain
5. **Woven Background** - Canvas-based thread pattern animation

## Waitlist Form

The waitlist form collects:
- **Email** (required)
- **Role** (required): Institutional Leader, Faculty, Advisor, or Student
- **Institution** (optional)

### TODO: Backend Integration

The form currently logs data to console. To integrate with backend:

1. Update the `handleSubmit` function in `/src/app/pages/Landing.tsx`
2. Send POST request to your waitlist API endpoint
3. Example:

```typescript
async function handleSubmit(e: React.FormEvent) {
  e.preventDefault();
  if (email && role) {
    try {
      const response = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, role, institution }),
      });
      if (response.ok) {
        setSubmitted(true);
      }
    } catch (error) {
      console.error('Waitlist submission error:', error);
    }
  }
}
```

## Navigation Links

- **"Request Early Access"** - Scrolls to `#waitlist` section
- **"See How It Works"** - Scrolls to `#how-it-works` section
- **"Already have access? Sign in →"** - Links to `/login`

## Responsive Breakpoints

- **Mobile**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: > 1024px

The landing page adapts:
- Font sizes
- Layout grids (stacks on mobile, side-by-side on desktop)
- Navigation (hamburger menu on mobile)
- Visual elements (some decorative elements hidden on mobile)

## Accessibility

- **Semantic HTML** - Proper heading hierarchy, sections
- **Focus states** - All interactive elements have visible focus indicators
- **ARIA labels** - Menu button has aria-label
- **Keyboard navigation** - All interactive elements accessible via keyboard
- **Color contrast** - WCAG 2.1 AA compliant

## Performance Optimizations

- **Canvas animation** - Optimized with device pixel ratio capping (max 2x)
- **Intersection Observer** - Animations trigger only when elements enter viewport
- **Efficient re-renders** - useEffect dependencies properly managed
- **Font loading** - Google Fonts preconnect for faster loading

## Customization

To customize the landing page:

1. **Edit content** - Update text in `/src/app/pages/Landing.tsx`
2. **Modify personas** - Edit the `personas` object (lines 125-220)
3. **Change colors** - Update the `C` constant (lines 12-18)
4. **Adjust spacing** - Modify `sectionPad` variable (line 118)

## Browser Support

- **Chrome/Edge** - Full support
- **Firefox** - Full support
- **Safari** - Full support (iOS 14+)
- **Mobile browsers** - Full support

## Notes

- The landing page uses inline styles for simplicity and to avoid CSS conflicts
- Canvas-based background is performance-optimized
- All Google Fonts are loaded from CDN (consider self-hosting for production)
- Smooth scroll behavior is applied to anchor links

---

**Last Updated:** February 16, 2026  
**Status:** Production Ready ✅
