# File Reorganization Plan

## Current Structure → New Structure

### FACULTY (New folder: /src/app/pages/faculty/)

**Dashboard:**
- `dashboard/FacultyDashboard.tsx` → `faculty/FacultyDashboard.tsx`

**Courses:**
- `courses/AllCourses.tsx` → `faculty/courses/AllCourses.tsx`
- `courses/CourseDashboard.tsx` → `faculty/courses/CourseDashboard.tsx`
- `courses/CreateCourse.tsx` → `faculty/courses/CreateCourse.tsx`
- `courses/LectureUpload.tsx` → `faculty/courses/LectureUpload.tsx`
- `courses/LectureProcessing.tsx` → `faculty/courses/LectureProcessing.tsx`
- `courses/UploadSyllabus.tsx` → `faculty/courses/UploadSyllabus.tsx`
- `courses/SyllabusEditor.tsx` → `faculty/courses/SyllabusEditor.tsx`
- `courses/SyllabusProcessing.tsx` → `faculty/courses/SyllabusProcessing.tsx`
- `courses/ReviewSyllabusMapping.tsx` → `faculty/courses/ReviewSyllabusMapping.tsx`
- `courses/SubConceptReviewQueue.tsx` → `faculty/courses/SubConceptReviewQueue.tsx`
- `courses/OutcomeMapping.tsx` → `faculty/courses/OutcomeMapping.tsx`
- `courses/WeekView.tsx` → `faculty/courses/WeekView.tsx`
- `courses/WeekMaterialsUpload.tsx` → `faculty/courses/WeekMaterialsUpload.tsx`
- `courses/CourseReady.tsx` → `faculty/courses/CourseReady.tsx`

**Generation:**
- `generation/GenerationSpecificationWizard.tsx` → `faculty/generation/GenerationSpecificationWizard.tsx`
- `generation/BatchProgress.tsx` → `faculty/generation/BatchProgress.tsx`
- `generation/GenerateQuestionsTopic.tsx` → `faculty/generation/GenerateQuestionsTopic.tsx`
- `generation/GenerateQuestionsSyllabus.tsx` → `faculty/generation/GenerateQuestionsSyllabus.tsx`
- `generation/GenerateTest.tsx` → `faculty/generation/GenerateTest.tsx`
- `generation/GenerateQuiz.tsx` → `faculty/generation/GenerateQuiz.tsx`
- `generation/GenerateHandout.tsx` → `faculty/generation/GenerateHandout.tsx`

**Questions:**
- `questions/FacultyReviewQueue.tsx` → `faculty/questions/FacultyReviewQueue.tsx`
- `questions/QuestionReviewList.tsx` → `faculty/questions/QuestionReviewList.tsx`
- `questions/QuestionDetailView.tsx` → `faculty/questions/QuestionDetailView.tsx`
- `questions/ItemDetail.tsx` → `faculty/questions/ItemDetail.tsx`
- `questions/QuestionHistory.tsx` → `faculty/questions/QuestionHistory.tsx`
- `questions/AIRefinement.tsx` → `faculty/questions/AIRefinement.tsx`
- `questions/ConversationalRefinement.tsx` → `faculty/questions/ConversationalRefinement.tsx`

**Exams:**
- `exams/ExamAssembly.tsx` → `faculty/exams/ExamAssembly.tsx`
- `exams/ExamAssignment.tsx` → `faculty/exams/ExamAssignment.tsx`
- `exams/RetiredExamUpload.tsx` → `faculty/exams/RetiredExamUpload.tsx`

**Repository:**
- `repository/Repository.tsx` → `faculty/repository/Repository.tsx`
- `repository/ItemBankBrowser.tsx` → `faculty/repository/ItemBankBrowser.tsx`

**Analytics:**
- `analytics/Analytics.tsx` → `faculty/analytics/Analytics.tsx`
- `analytics/CourseAnalytics.tsx` → `faculty/analytics/CourseAnalytics.tsx`
- `analytics/BlueprintCoverage.tsx` → `faculty/analytics/BlueprintCoverage.tsx`
- `analytics/PersonalDashboard.tsx` → `faculty/analytics/PersonalDashboard.tsx`

**Uploads:**
- `uploads/FacultyQuestionUpload.tsx` → `faculty/FacultyQuestionUpload.tsx`

### STUDENT (Already exists: /src/app/pages/student/)

**Move Dashboard:**
- `dashboard/StudentDashboard.tsx` → `student/StudentDashboard.tsx`

**Already in student/:**
- `student/StudentPractice.tsx` ✓
- `student/StudentQuestionView.tsx` ✓
- `student/StudentResults.tsx` ✓
- `student/StudentProgress.tsx` ✓
- `student/StudentAnalytics.tsx` ✓

### ADMIN (Already exists: /src/app/pages/admin/)

**Remove old dashboard:**
- DELETE `dashboard/Dashboard.tsx` (AdminDashboard already exists in admin/)

**Already in admin/:**
- `admin/AdminDashboard.tsx` ✓
- `admin/SetupWizard.tsx` ✓
- `admin/FrameworkManagement.tsx` ✓
- `admin/FacultyManagement.tsx` ✓
- `admin/KnowledgeBrowser.tsx` ✓
- `admin/SubConceptDetail.tsx` ✓
- `admin/ILOManagement.tsx` ✓
- `admin/DataIntegrityDashboard.tsx` ✓
- `admin/FULFILLSReviewQueue.tsx` ✓
- `admin/LCMEComplianceHeatmap.tsx` ✓
- `admin/LCMEElementDrillDown.tsx` ✓
- `admin/CourseCatalog.tsx` ✓

### SHARED (Stay in current locations)

**Auth:**
- `auth/*` - ALL STAY

**Onboarding:**
- `onboarding/*` - ALL STAY

**Profile & Settings:**
- `profile/*` - STAY
- `settings/*` - STAY
- `notifications/*` - STAY
- `help/*` - STAY

**Operations & Templates:**
- `operations/*` - STAY (could be faculty, but shared)
- `templates/*` - STAY (could be faculty, but shared)
- `collaboration/*` - STAY (shared)

**Errors:**
- `errors/*` - STAY

## Summary

**Folders to DELETE after moving:**
- `/src/app/pages/courses/` - DELETE (move to faculty/courses/)
- `/src/app/pages/generation/` - DELETE (move to faculty/generation/)
- `/src/app/pages/questions/` - DELETE (move to faculty/questions/)
- `/src/app/pages/exams/` - DELETE (move to faculty/exams/)
- `/src/app/pages/repository/` - DELETE (move to faculty/repository/)
- `/src/app/pages/analytics/` - DELETE (move to faculty/analytics/)
- `/src/app/pages/uploads/` - DELETE (moved FacultyQuestionUpload)
- `/src/app/pages/dashboard/` - DELETE (dashboards moved to role folders)

**Folders to CREATE:**
- `/src/app/pages/faculty/`
- `/src/app/pages/faculty/courses/`
- `/src/app/pages/faculty/generation/`
- `/src/app/pages/faculty/questions/`
- `/src/app/pages/faculty/exams/`
- `/src/app/pages/faculty/repository/`
- `/src/app/pages/faculty/analytics/`
