# Journey-OS: User Flows & Roadmap Alignment

> **Generated:** March 3, 2026
> **Cross-references:** `BACKEND_DATA_CONTRACT.md`, Roadmap v3.0
> **Purpose:** Map every user journey between screens, show which roadmap phase activates each flow with real data, and identify gaps between the 107-route prototype and the 48-week build plan.

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Persona Journeys](#persona-journeys)
   - [Dr. Amara Osei (Faculty)](#persona-1-dr-amara-osei--faculty)
   - [Dr. Takahashi (Course Director / Institutional Admin)](#persona-2-dr-takahashi--course-director--institutional-admin)
   - [Marcus Williams (Student)](#persona-3-marcus-williams--student)
   - [Academic Advisor](#persona-4-academic-advisor)
   - [Super Admin (Platform)](#persona-5-super-admin--platform)
3. [Flow-by-Flow Screen Mapping](#flow-by-flow-screen-mapping)
   - [Flow A: First-Time Faculty Registration & Onboarding](#flow-a-first-time-faculty-registration--onboarding)
   - [Flow B: Faculty Course Setup (Syllabus-to-Graph)](#flow-b-faculty-course-setup-syllabus-to-graph)
   - [Flow C: Single Question Generation (The Core Loop)](#flow-c-single-question-generation-the-core-loop)
   - [Flow D: Question Review & Refinement](#flow-d-question-review--refinement)
   - [Flow E: Bulk Generation & Batch Review](#flow-e-bulk-generation--batch-review)
   - [Flow F: Gap Detection & Targeted Generation](#flow-f-gap-detection--targeted-generation)
   - [Flow G: Exam Assembly & Delivery](#flow-g-exam-assembly--delivery)
   - [Flow H: LCME Compliance Evidence](#flow-h-lcme-compliance-evidence)
   - [Flow I: Student Practice Session](#flow-i-student-practice-session)
   - [Flow J: Student Mastery Tracking](#flow-j-student-mastery-tracking)
   - [Flow K: Advisor At-Risk Intervention](#flow-k-advisor-at-risk-intervention)
   - [Flow L: Institutional Admin Setup](#flow-l-institutional-admin-setup)
   - [Flow M: Super Admin Platform Management](#flow-m-super-admin-platform-management)
4. [Roadmap Phase-to-Screen Matrix](#roadmap-phase-to-screen-matrix)
5. [Prototype Screens Without Roadmap Coverage](#prototype-screens-without-roadmap-coverage)
6. [Roadmap Features Without Prototype Screens](#roadmap-features-without-prototype-screens)
7. [Recommended Screen Build Sequence](#recommended-screen-build-sequence)

---

## Executive Summary

The prototype contains **107 routes / 89 unique components** — all running on mock data. The roadmap builds real backend infrastructure across **5 phases over 48 weeks**. The key finding:

- **Phase 1 (Weeks 1-8) needs only ~8 screens** with real data. The prototype has them, but buried among 80+ screens that won't have real backends for months.
- **~15 prototype screens have no corresponding roadmap work** (communications hub, templates, bulk operations UI, etc.) — they're speculative.
- **~6 roadmap features have no prototype screen yet** (CopilotKit workbench, D3 coverage map, MIP solver UI, advisor dashboard, at-risk alerts).
- The prototype front-loaded the full design system across all screens. The roadmap says "functional UI, not full design system polish" until Phase 3 Week 21-22.

The most critical alignment issue: **the roadmap's Phase 1 core loop (faculty generates a question via CopilotKit chat) maps to `/faculty/quest` (QuestWorkbench)**, but the prototype's generation flow is spread across 10+ screens (`GenerateQuestionsTopic`, `GenerationSpecificationWizard`, `BatchProgress`, etc.) that assume a form-based UI, not a conversational CopilotKit interface.

---

## Persona Journeys

### Persona 1: Dr. Amara Osei — Faculty

**Available from:** Phase 1 (Week 8)
**Primary screens:** 25-30 across all phases

```
PHASE 1 (Weeks 1-8): "I can generate a question from my syllabus"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /login ──→ /faculty/quest (QuestWorkbench)
                    │
                    ├── Chat: "Generate a question about atherosclerosis for MEDI 531"
                    │     → Vignette streams → Stem appears → Options populate
                    │
                    ├── Approve/Reject → Item saved to Neo4j + Supabase
                    │
                    └── Browse generated items (basic question bank)


PHASE 2 (Weeks 9-16): "I trust these for a real exam"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /faculty/quest ──→ Switch to Review Mode
       │                   │
       │                   ├── Load pending question → Approve / Edit / Reject
       │                   │
       │                   └── Chat: "Make the vignette shorter" → Partial re-run
       │
       ├── Bulk Generation (Course Director only)
       │     → /generation/progress (BatchProgress) → Per-item tracking
       │
       └── /questions/:id/refine (ConversationalRefinement)
             → Up to 5 iterations → Revalidate each time


PHASE 3 (Weeks 17-24): "I can see my coverage gaps"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /dashboard (FacultyDashboard) ──→ KPI strip + gap alerts
       │
       ├── Coverage Map (D3 force-directed graph) → Click gap → Pre-fill workbench
       │
       ├── /courses/:id (CourseDashboard) → Week view → Coverage per week
       │
       └── /analytics/blueprint-coverage → USMLE 16×7 heatmap
             → Click underserved cell → /faculty/quest with context


PHASE 4 (Weeks 25-32): "I can build an exam"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /repository (ItemBankBrowser) → Filter → Select items
       │
       └── /exams/assembly (ExamAssembly) → Set constraints → MIP solver
             │
             ├── Preview + Manual swap → Finalize
             │
             └── /exams/assign (ExamAssignment) → Assign to students
```

---

### Persona 2: Dr. Takahashi — Course Director / Institutional Admin

**Available from:** Phase 3 (Week 24)
**Primary screens:** 15-20

```
PHASE 3 (Weeks 17-24): "I can see the full curriculum picture"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /institution (InstitutionalAdminDashboard) → Overview metrics
       │
       ├── /institution/coverage (CoverageDashboard) → Cross-course coverage
       │
       ├── /institution/frameworks (FrameworkConfiguration) → Enable/configure
       │     USMLE, ACGME, EPA, Bloom's, Miller's, LCME
       │
       ├── /admin/lcme-compliance-heatmap → 12 standards × elements
       │     │
       │     └── /admin/lcme-element-drill-down → Evidence per element
       │
       └── /analytics → Institutional analytics


PHASE 4 (Weeks 25-32): "I can manage the institution"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /institution/users (UserManagement) → CRUD users
       │
       ├── /admin/faculty (FacultyManagement) → Manage faculty + courses
       │
       └── /institution/accreditation (AccreditationReports) → Export evidence


PHASE 5 (Weeks 43-44): "I can generate compliance reports"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /institution/accreditation → Generate narrative reports
       → Claude-generated compliance prose from graph evidence
       → PDF/DOCX export with citations
```

---

### Persona 3: Marcus Williams — Student

**Available from:** Phase 5 (Week 34)
**Primary screens:** 10-12

```
PHASE 5a (Weeks 33-34): "I can practice"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /role-selection → /register/student → /email-verification
       │
       └── /onboarding/student → Study goals, subjects, time
             │
             └── /student-dashboard (StudentDashboard)
                   │
                   ├── /student/practice → Select course/topic/weak areas
                   │     │
                   │     └── /student/practice/session (StudentQuestionView)
                   │           │  Answer question → See explanation + rationale
                   │           │
                   │           └── /student/practice/results (StudentResults)
                   │                 → Score breakdown by topic
                   │
                   └── /courses → Browse enrolled courses


PHASE 5b (Weeks 35-38): "I can see my mastery grow"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /student-dashboard → Updated KPIs with BKT mastery
       │
       ├── /student/progress → Concept-level mastery heatmap
       │     → Color-coded SubConcepts
       │     → "Why Am I Struggling?" drill-down (PREREQUISITE_OF traversal)
       │
       ├── /student/analytics → Performance trends over time
       │
       └── /student/practice → Adaptive: weak areas auto-prioritized
             → Spaced repetition resurfaces concepts at right intervals


PHASE 5c (Weeks 39-40): "Questions adapt to my level"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /student/practice → IRT-calibrated item selection
       → Fisher Information maximizes learning gain per question
       → Items selected at student's current θ (ability estimate)
```

---

### Persona 4: Academic Advisor

**Available from:** Phase 5 (Week 42)
**Primary screens:** 3-5

```
PHASE 5 (Weeks 41-42): "I can intervene before grades tell the story"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /dashboard (Advisor variant) → Cohort overview
       │
       ├── Student mastery heatmaps per student
       │     → At-risk flags (mastery trajectory prediction)
       │
       ├── Root-cause analysis per flagged student
       │     → Trace backward through PREREQUISITE_OF
       │     → "Student failing Cardiovascular Pharmacology because
       │        foundational Receptor Pharmacology is weak"
       │
       └── Intervention recommendations
             → Specific SubConcepts + linked practice sets
             → Track outcome after intervention
```

> **Note:** The prototype has no dedicated Advisor screens. The roadmap places this at Phase 5 Week 41-42. The `StudentAnalytics` and `StudentProgress` screens would need advisor-level views.

---

### Persona 5: Super Admin — Platform

**Available from:** Phase 4 (Week 32)
**Primary screens:** 15-18

```
PHASE 4 (Weeks 31-32): "I can manage the platform"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  /admin (AdminDashboard) → System KPIs, health, alerts
       │
       ├── /admin/institutions → Institution list → /admin/institutions/:id
       │
       ├── /admin/users (AdminUserDirectory) → All users across institutions
       │
       ├── /admin/applications (ApplicationReviewQueue) → Approve/deny
       │
       ├── /admin/setup (SetupWizard) → New institution onboarding
       │
       ├── /admin/frameworks (FrameworkManagement) → CRUD frameworks
       │
       ├── /admin/knowledge (KnowledgeBrowser) → Browse knowledge graph
       │     │
       │     └── /admin/knowledge/:uuid (SubConceptDetail)
       │           → Teaching chunks, assessment items, relationships
       │
       ├── /admin/ilos (ILOManagement) → CRUD ILOs with framework mappings
       │
       ├── /admin/data-integrity (DataIntegrityDashboard)
       │     → Orphan nodes, broken links, sync drift
       │
       └── /admin/fulfills-review (FULFILLSReviewQueue)
             → Review FULFILLS relationships
```

---

## Flow-by-Flow Screen Mapping

### Flow A: First-Time Faculty Registration & Onboarding

```
Screen Sequence:
━━━━━━━━━━━━━━━
/                           Landing page
  │ Click "Request Early Access" or "Sign Up"
  ▼
/role-selection             Select "Faculty" card
  │ Click "Get Started as Faculty"
  ▼
/register/faculty           Fill: name, email (@msm.edu), title, department, password
  │ Submit → POST /auth/register/faculty
  ▼
[Email inbox]               Verification email sent
  │ Click verification link
  ▼
/email-verification         Token validated → GET /auth/verify-email?token=xxx
  │ Auto-redirect
  ▼
/onboarding/faculty         4-step wizard:
  │                           Step 1: Select teaching areas
  │                           Step 2: Select question types
  │                           Step 3: Select usage goals
  │                           Step 4: Enter first course name
  │ POST /onboarding/faculty
  ▼
/dashboard                  Faculty Dashboard (first landing)
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/` Landing | Phase 1 | Week 1-2 | Waitlist form → Supabase |
| `/role-selection` | Phase 1 | Week 7-8 | Static routing only |
| `/register/faculty` | Phase 1 | Week 7-8 | Supabase Auth |
| `/email-verification` | Phase 1 | Week 7-8 | Supabase Auth email |
| `/onboarding/faculty` | **Phase 4** | Week 31-32 | Roadmap defers onboarding to Phase 4 |
| `/dashboard` | **Phase 3** | Week 21-22 | Dashboard is Phase 3 |

**Gap:** The roadmap's Phase 1 has "basic login + course selection" — no onboarding wizard, no full registration flow, no dashboard. Phase 1 faculty auth is minimal Supabase Auth → straight to QuestWorkbench.

---

### Flow B: Faculty Course Setup (Syllabus-to-Graph)

```
Screen Sequence:
━━━━━━━━━━━━━━━
/courses/create             CreateCourse form: name, code, semester, description
  │ POST /courses → Returns courseId
  ▼
/courses/:id/upload-syllabus    Drag & drop PDF/DOCX, or paste text
  │ POST /courses/{id}/syllabus → Starts processing
  ▼
/courses/:id/processing     SyllabusProcessing: real-time progress
  │                           UPLOAD → PARSE → CLEAN → CHUNK → EMBED → EXTRACT
  │                           Poll GET /courses/{id}/processing-status
  │ Processing complete
  ▼
/courses/:id/review-mapping     ReviewSyllabusMapping:
  │                               Extracted topics with confidence scores
  │                               Confirm/reject/edit concept mappings
  │                               PUT /courses/{id}/syllabus-mapping
  ▼
/courses/subconcept-review      SubConceptReviewQueue:
  │                               TEACHES → TEACHES_VERIFIED promotion
  │                               Faculty confirms AI-extracted relationships
  ▼
/courses/outcome-mapping        OutcomeMapping:
  │                               SLO → ILO FULFILLS linking
  │                               Map learning objectives to institutional goals
  ▼
/courses/:id/ready              CourseReady: completion checklist
  │ All green → Course active
  ▼
/courses/:id                    CourseDashboard: week view + coverage stats
  │
  ├── /courses/:id/week/:weekId         WeekView: topics, materials, questions
  │     │
  │     └── /courses/:id/week/:weekId/upload-materials   Upload lecture slides
  │
  └── /courses/upload-lecture → /courses/lecture-processing
        Lecture upload + processing pipeline
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/courses/create` | Phase 1 | Week 3-4 | Basic course creation in Supabase |
| `/courses/:id/upload-syllabus` | Phase 1 | Week 3-4 | Supabase Storage upload |
| `/courses/:id/processing` | Phase 1 (manual) / Phase 3 (full Inngest) | Week 3-4 / Week 17-18 | Phase 1 is manual single-course pipeline |
| `/courses/:id/review-mapping` | Phase 1 | Week 3-4 | Basic concept review |
| `/courses/subconcept-review` | **Phase 2** | Week 15-16 | TEACHES_VERIFIED workflow |
| `/courses/outcome-mapping` | **Phase 3** | Week 17-18 | SLO extraction + FULFILLS linking |
| `/courses/:id/ready` | **Phase 3** | Week 17-18 | Full multi-course support |
| `/courses/:id` CourseDashboard | **Phase 3** | Week 21-22 | Coverage stats need graph data |
| `/courses/upload-lecture` | **Phase 3** | Week 17-18 | PPTX parser (Gap 4) |
| `/courses/lecture-processing` | **Phase 3** | Week 17-18 | Same Inngest pipeline, slide source_type |

**Gap:** Phase 1 ingestion is for ONE course only, manually triggered. The full 7-stage Inngest pipeline with multi-course support, SLO extraction, and lecture ingestion doesn't arrive until Phase 3. The prototype shows the full flow, but 60% of these screens won't have backends until Week 17+.

---

### Flow C: Single Question Generation (The Core Loop)

This is the **most critical flow** — the entire Phase 1 thesis.

```
PROTOTYPE FLOW (form-based):
━━━━━━━━━━━━━━━━━━━━━━━━━━━
/generate/topic             GenerateQuestionsTopic:
  │                           Browse topic tree by system
  │                           Select topics, count, difficulty, question type
  │ Click "Generate"
  ▼
/generation/progress        BatchProgress: per-item progress tracking
  │ Complete
  ▼
/questions/review           FacultyReviewQueue: filter + browse generated items
  │ Click item
  ▼
/questions/:id              ItemDetail: full question view + approve/reject


ROADMAP FLOW (conversational, CopilotKit):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
/faculty/quest              QuestWorkbench (CopilotKit):
  │                           LEFT PANEL (45%): CopilotChat
  │                             Faculty: "Generate a question about
  │                             atherosclerosis for MEDI 531"
  │                           RIGHT PANEL (55%): Progressive rendering
  │                             → Vignette streams via STATE_DELTA
  │                             → Stem appears
  │                             → Options populate one at a time
  │
  │                           Approve → PATCH /questions/{id} status=approved
  │                           Reject  → PATCH /questions/{id} status=rejected
  │
  │                           Item saved via graph_writer to Neo4j + Supabase
  │                             → AssessmentItem node
  │                             → TARGETS → SubConcept
  │                             → AT_BLOOM → BloomLevel
  │
  ▼
/repository                 Browse all generated items (basic filter)
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/faculty/quest` **QuestWorkbench** | **Phase 1** | Week 7-8 | **THIS IS THE PHASE 1 DELIVERABLE** |
| `/generate/topic` form-based generation | Phase 2+ | Week 11-12 | Bulk/form mode is Phase 2 |
| `/generation/wizard` gap-guided generation | **Phase 3** | Week 19-20 | Needs gap analysis data |
| `/generation/progress` batch tracking | **Phase 2** | Week 11-12 | Inngest batch orchestration |
| `/repository` basic question bank | Phase 1 | Week 7-8 | Basic browse + filter |

**Critical alignment issue:** The prototype's primary generation UX is form-based (`GenerateQuestionsTopic` with dropdowns for system, difficulty, count). The roadmap's Phase 1 UX is **conversational** (CopilotKit chat panel + progressive rendering). The `QuestWorkbench` component is the closest match, but it needs to be the CopilotKit integration, not a form.

---

### Flow D: Question Review & Refinement

```
Screen Sequence:
━━━━━━━━━━━━━━━
/questions/review           FacultyReviewQueue:
  │                           Filter by status, system, difficulty, batch
  │                           List view with stem preview + status badges
  │ Click item
  ▼
/questions/:id              ItemDetail:
  │                           Full vignette + stem + options with rationales
  │                           Quality score, Bloom level, USMLE mapping
  │                           Critic Agent scores (6 metrics)
  │                           Toulmin argument (claim, data, warrant, backing, rebuttal, qualifier)
  │                           Source provenance (which content chunks)
  │
  ├── [Approve] → PATCH status=approved → Back to queue
  │
  ├── [Reject] → Modal: rejection reason → PATCH status=rejected
  │
  └── [Refine] → Choose path:
        │
        ├── /questions/:id/refine       ConversationalRefinement:
        │     Chat-based: "Make the vignette shorter"
        │     → Intent classification → Partial pipeline re-run
        │     → Up to 5 iterations
        │     → Side-by-side: original vs revised
        │     → Approve revised version
        │
        ├── /questions/:id/ai-refine    AIRefinement:
        │     Automated improvement suggestions
        │     → System identifies weak metrics
        │     → Auto-generates improvement
        │
        └── /questions/:id/history      QuestionHistory:
              Version history with diffs
              → See all iterations + who changed what
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/questions/review` | Phase 1 (basic) / Phase 2 (full) | Week 7-8 / Week 11-12 | Phase 1 has approve/reject only |
| `/questions/:id` ItemDetail | Phase 1 (basic) / Phase 2 (Critic scores) | Week 7-8 / Week 9-10 | Critic Agent + Toulmin in Phase 2 |
| `/questions/:id/refine` | **Phase 2** | Week 11-12 | Conversational refinement (Gap 5) |
| `/questions/:id/ai-refine` | **Phase 2** | Week 9-10 | Critic Agent auto-suggestions |
| `/questions/:id/history` | **Phase 2** | Week 15-16 | Generation history |

---

### Flow E: Bulk Generation & Batch Review

```
Screen Sequence:
━━━━━━━━━━━━━━━
/generation/wizard          GenerationSpecificationWizard:
  │                           Step 1: Gap Analysis → Shows coverage gaps,
  │                                   USMLE imbalance, difficulty gaps
  │                           Step 2: Parameters → SubConcepts, format,
  │                                   Bloom levels, difficulties, scope
  │                           Step 3: Review → Cost estimate, time estimate
  │                           Step 4: Confirm → POST /generate/batch
  ▼
/generation/progress        BatchProgress:
  │                           Per-item progress via SSE (STATE_DELTA)
  │                           Real-time: queued → processing → completed/failed
  │                           Faculty intervention on failures
  │ Batch complete
  ▼
/questions/review           FacultyReviewQueue:
                              Filter by batch_id → Review generated items
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/generation/wizard` | **Phase 3** | Week 19-20 | Needs gap analysis from multi-course data |
| `/generation/progress` | **Phase 2** | Week 11-12 | Inngest batch orchestration |
| Batch generation capability | **Phase 2** | Week 11-12 | Course Director role gate required |

---

### Flow F: Gap Detection & Targeted Generation

```
Screen Sequence:
━━━━━━━━━━━━━━━
/analytics/blueprint-coverage   BlueprintCoverage:
  │                               16×7 USMLE heatmap (System × Discipline)
  │                               Color-coded by coverage level
  │ Click underserved cell (e.g., Renal × Pharmacology = 0.15)
  ▼
/faculty/quest              QuestWorkbench (pre-filled):
  │                           Context auto-loaded for the gap area
  │                           "Generate 5 questions about Renal Pharmacology"
  │                           → Pipeline runs with targeted SubConcepts
  ▼
/analytics/blueprint-coverage   Heatmap updates (cell turns greener)

ALSO:
/dashboard                  FacultyDashboard:
  │                           Gap alert card: "Coverage gap detected:
  │                           Renal Pharmacology below 60% threshold"
  │ Click alert
  ▼
/faculty/quest              Pre-filled with gap context
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/analytics/blueprint-coverage` | **Phase 3** | Week 19-20 | USMLE gap detection (signature feature) |
| Gap-to-generation closed loop | **Phase 3** | Week 19-20 | Click gap → pre-fill workbench |
| Dashboard gap alerts | **Phase 3** | Week 21-22 | Nightly gap scan via Inngest |

---

### Flow G: Exam Assembly & Delivery

```
Screen Sequence:
━━━━━━━━━━━━━━━
/repository/item-bank       ItemBankBrowser:
  │                           Faceted search: course, Bloom, USMLE, difficulty, status
  │                           View per-item analytics, Critic scores, provenance
  │
  ├── Select items manually, OR
  │
  ▼
/exams/assembly             ExamAssembly:
  │                           Set constraints:
  │                             - N items (e.g., 50)
  │                             - Bloom distribution (e.g., 20% Apply, 40% Analyze, etc.)
  │                             - USMLE system coverage targets
  │                             - Time budget
  │                           → MIP solver (PuLP/OR-Tools) optimizes selection
  │                           → Preview assembled exam
  │                           → Manual swap if needed
  │                           → Finalize
  ▼
/exams/assign               ExamAssignment:
  │                           Select student cohort
  │                           Set start time, end time, duration
  │                           → POST /exams/{id}/assign
  ▼
[Student takes exam]        Timed assessment → Answer recording
                              → Response data accumulates (feeds Phase 5 IRT)


ALSO:
/exams/retired-upload       RetiredExamUpload:
                              Import legacy MSM exam questions
                              → embed → tag → dual-write
                              → Items join the bank
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/repository/item-bank` | **Phase 4** | Week 25-26 | Full item bank with analytics |
| `/exams/assembly` | **Phase 4** | Week 27-28 | MIP solver (Python FastAPI) |
| `/exams/assign` | **Phase 4** | Week 27-28 | Basic exam delivery |
| `/exams/retired-upload` | **Phase 4** | Week 25-26 | Legacy import pipeline |

---

### Flow H: LCME Compliance Evidence

```
Screen Sequence:
━━━━━━━━━━━━━━━
/admin/lcme-compliance-heatmap    LCMEComplianceHeatmap:
  │                                 12 standards × ~93 elements
  │                                 Color: green (≥3 ILOs assessed),
  │                                        yellow (1-2), red (0)
  │ Click element (e.g., Element 7.2)
  ▼
/admin/lcme-element-drill-down    LCMEElementDrillDown:
  │                                 Coverage chain evidence:
  │                                 LCME_Element ← ADDRESSES_LCME ← ILO
  │                                   ← FULFILLS ← SLO ← ASSESSES ← AssessmentItem
  │                                 Which ILOs, which courses, how many items
  │ Export evidence
  ▼
/institution/accreditation        AccreditationReports:
                                    Phase 3: CSV + structured data export
                                    Phase 5: Claude-generated narrative reports
                                    → PDF/DOCX with programmatic citations
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/admin/lcme-compliance-heatmap` | **Phase 3** | Week 23-24 | LCME compliance MVP |
| `/admin/lcme-element-drill-down` | **Phase 3** | Week 23-24 | Coverage chain queries |
| `/institution/accreditation` (raw export) | **Phase 3** | Week 23-24 | CSV evidence export |
| `/institution/accreditation` (narrative) | **Phase 5** | Week 43-44 | Claude-generated reports |

---

### Flow I: Student Practice Session

```
Screen Sequence:
━━━━━━━━━━━━━━━
/student-dashboard          StudentDashboard:
  │                           KPIs: questions answered, accuracy, streak, study time
  │                           Upcoming practice sets
  │                           Course progress cards
  │ Click "Start Practice" or select a practice set
  ▼
/student/practice           StudentPractice:
  │                           Mode: Quick Practice / Custom / Pre-built Sets
  │                           Quick: set count (10), time (15 min), include weak areas
  │                           Custom: select course, topics, difficulty
  │                           → POST /student/sessions → Returns session_id
  ▼
/student/practice/session   StudentQuestionView:
  │                           One question at a time
  │                           Clinical vignette + stem + 5 options
  │                           Timer, question counter, bookmark, flag
  │                           Select answer → Next (or see feedback immediately)
  │
  │                           POST /student/sessions/{id}/answers
  │                             { question_id, selected_option, time_spent }
  │                           → BKT mastery update < 500ms (Phase 5b)
  │                           → Supabase Realtime trigger → Neo4j update
  │
  │ Session complete (all questions answered or time up)
  ▼
/student/practice/results   StudentResults:
                              Score: 18/20 (90%)
                              Per-question review with explanations
                              ECD explanation + misconception feedback
                              Topic breakdown: which areas strong/weak
                              → Dashboard KPIs update
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/student-dashboard` | **Phase 5** | Week 33-34 | Student auth + dashboard |
| `/student/practice` | **Phase 5** | Week 33-34 | Practice launcher |
| `/student/practice/session` | **Phase 5** | Week 33-34 | Item delivery + answer recording |
| `/student/practice/results` | **Phase 5** | Week 33-34 | Score + review |
| BKT mastery updates | **Phase 5** | Week 35-36 | Real-time < 500ms |
| IRT-adaptive item selection | **Phase 5** | Week 39-40 | Fisher Information selection |

---

### Flow J: Student Mastery Tracking

```
Screen Sequence:
━━━━━━━━━━━━━━━
/student/progress           StudentProgress:
  │                           Concept-level mastery heatmap
  │                           USMLE system × mastery level
  │                           Color-coded SubConcepts (red → yellow → green)
  │                           ConceptMastery nodes:
  │                             Student -[:HAS_MASTERY]-> ConceptMastery
  │                                                       -[:FOR_CONCEPT]-> SubConcept
  │
  ├── Click weak area → "Why Am I Struggling?"
  │     Trace backward through PREREQUISITE_OF edges
  │     "Your Cardiovascular Pharmacology mastery is low because
  │      Receptor Pharmacology (prerequisite) is only 0.38"
  │
  └── /student/analytics    StudentAnalytics:
        Performance trends over time
        Mastery trajectory per course
        Comparison to cohort (anonymized)
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| `/student/progress` | **Phase 5** | Week 35-36 | BKT mastery tracking |
| "Why Am I Struggling?" | **Phase 5** | Week 37-38 | PREREQUISITE_OF traversal |
| `/student/analytics` | **Phase 5** | Week 37-38 | Trend charts + trajectory |

---

### Flow K: Advisor At-Risk Intervention

```
Screen Sequence:
━━━━━━━━━━━━━━━
/dashboard (Advisor)        Advisor Dashboard:
  │                           Cohort overview: N students, N at-risk
  │                           Per-student mastery heatmaps
  │                           At-risk flags (2-4 weeks before exam)
  │ Click at-risk student
  ▼
[Student Detail View]       Root-cause analysis:
  │                           Trace backward through PREREQUISITE_OF
  │                           "Marcus is failing Cardiovascular Pharmacology.
  │                            Root cause: Receptor Pharmacology mastery is 0.38.
  │                            This is a prerequisite for 4 other concepts."
  │
  ├── Recommend intervention:
  │     Specific SubConcepts to review
  │     Linked practice sets for weak areas
  │
  └── Track outcome:
        Follow mastery trajectory after intervention
        Did it help? Or need different approach?
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| Advisor Dashboard | **Phase 5** | Week 41-42 | **No prototype screen exists** |
| At-risk detection | **Phase 5** | Week 41-42 | Mastery trajectory prediction |
| Root-cause analysis | **Phase 5** | Week 41-42 | PREREQUISITE_OF graph traversal |

**Gap:** The prototype has no dedicated Advisor screens. The roadmap's Landing page mentions Advisors as a persona, but no specific routes are built for them. This needs new screens.

---

### Flow L: Institutional Admin Setup

```
Screen Sequence:
━━━━━━━━━━━━━━━
/role-selection             Select "Institutional Admin"
  ▼
/register/admin             AdminRegistration: name, email, title,
  │                           institution name, access code
  ▼
/email-verification         Verify email
  ▼
/onboarding/admin           AdminOnboarding: setup guide + task overview
  ▼
/institution                InstitutionalAdminDashboard:
  │
  ├── /institution/users     UserManagement: invite faculty, manage students
  │
  ├── /institution/frameworks  FrameworkConfiguration:
  │     Enable/configure: USMLE, ACGME, EPA, Bloom's, Miller's, LCME
  │
  ├── /institution/coverage   CoverageDashboard: cross-course coverage
  │
  └── /institution/settings   Institution-level settings
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| Admin registration | Phase 1 (basic auth) / Phase 4 (full) | Week 7-8 / Week 31-32 | Phase 1 has minimal auth only |
| Admin onboarding | **Phase 4** | Week 31-32 | Full onboarding wizard |
| Institution dashboard | **Phase 3** | Week 21-22 | Needs multi-course data |
| User management | **Phase 4** | Week 31-32 | Full CRUD |
| Framework configuration | **Phase 3** | Week 17-18 | Framework alignment at scale |

---

### Flow M: Super Admin Platform Management

```
Screen Sequence:
━━━━━━━━━━━━━━━
/admin                      AdminDashboard: system-wide KPIs
  │
  ├── /admin/institutions    InstitutionListDashboard → /admin/institutions/:id
  │
  ├── /admin/applications    ApplicationReviewQueue: approve new institutions
  │
  ├── /admin/users           AdminUserDirectory: all users across all institutions
  │
  ├── /admin/knowledge       KnowledgeBrowser: browse the knowledge graph
  │     │                      Domain → Concept → SubConcept tree
  │     │                      Search, filter by system
  │     └── /admin/knowledge/:uuid  SubConceptDetail
  │
  ├── /admin/ilos            ILOManagement: CRUD with framework mappings
  │
  ├── /admin/data-integrity  DataIntegrityDashboard:
  │                            Orphan nodes, broken links, missing embeddings,
  │                            sync drift, empty SubConcepts
  │
  ├── /admin/fulfills-review FULFILLSReviewQueue
  │
  ├── /admin/lcme-compliance-heatmap → /admin/lcme-element-drill-down
  │
  └── /admin/settings        SystemConfigurationDashboard
        └── /admin/settings/roles  UserRoleManagement
```

| Screen | Roadmap Phase | Real Backend | Notes |
|--------|--------------|-------------|-------|
| Admin dashboard | **Phase 4** | Week 31-32 | SuperAdmin role |
| Knowledge browser | **Phase 3** (data exists) / **Phase 4** (UI) | Week 17-18 / Week 31-32 | Graph data from Phase 3 |
| Data integrity | **Phase 2** (linting) / **Phase 4** (UI) | Week 15-16 / Week 31-32 | KaizenML rules run in Phase 2 |
| LCME screens | **Phase 3** | Week 23-24 | LCME compliance MVP |

---

## Roadmap Phase-to-Screen Matrix

### Phase 1: "The Question Factory" (Weeks 1-8)

**Screens with real backend data:**

| Screen | Route | What's Real |
|--------|-------|------------|
| Login (minimal) | `/login` | Supabase Auth, faculty + institutional_admin roles only |
| Course selection | — | Basic course dropdown (not a full screen) |
| **QuestWorkbench** | `/faculty/quest` | **CopilotKit + LangGraph.js: THE core deliverable** |
| Question bank (basic) | `/repository` | Browse generated items, filter by course |
| Upload syllabus | `/courses/:id/upload-syllabus` | Supabase Storage, single course |
| Processing status | `/courses/:id/processing` | Manual pipeline, single course |
| Concept review (basic) | `/courses/:id/review-mapping` | Approve/reject extracted concepts |

**Screens NOT needed in Phase 1:** Everything else. The roadmap explicitly says: "Not full design system polish yet" and "Don't front-load 70 screens nobody uses yet."

---

### Phase 2: "The Quality Engine" (Weeks 9-16)

**New screens with real backend data:**

| Screen | Route | What's Real |
|--------|-------|------------|
| Review Mode (in workbench) | `/faculty/quest?mode=review` | load → edit → revalidate → critic |
| Conversational Refinement | `/questions/:id/refine` | Intent classification → partial re-run |
| Batch Progress | `/generation/progress` | Inngest batch orchestration, per-item SSE |
| Generation History | — | Past sessions with metrics, timing, costs |
| TEACHES_VERIFIED review | `/courses/subconcept-review` | Faculty promote AI mappings |
| Data linting alerts | — | 5 KaizenML rules as Inngest cron jobs |

---

### Phase 3: "The Coverage Map" (Weeks 17-24)

**New screens with real backend data:**

| Screen | Route | What's Real |
|--------|-------|------------|
| Faculty Dashboard | `/dashboard` | Full KPI strip, gap alerts, course overview |
| Course Dashboard | `/courses/:id` | Week view, coverage stats, questions |
| All Courses | `/courses` | Multi-course list with coverage |
| Blueprint Coverage (USMLE Heatmap) | `/analytics/blueprint-coverage` | 16×7 real gap data |
| Coverage Map (D3) | — | **No prototype screen exists** — needs new component |
| LCME Compliance Heatmap | `/admin/lcme-compliance-heatmap` | 12 standards × elements |
| LCME Element Drill-Down | `/admin/lcme-element-drill-down` | Evidence chain |
| Accreditation Reports (CSV) | `/institution/accreditation` | Raw evidence export |
| Institutional Admin Dashboard | `/institution` | Coverage overview |
| Outcome Mapping | `/courses/outcome-mapping` | SLO → ILO FULFILLS |
| Lecture Upload + Processing | `/courses/upload-lecture` + `/courses/lecture-processing` | PPTX parser |

---

### Phase 4: "The Item Bank + Exam Assembly" (Weeks 25-32)

**New screens with real backend data:**

| Screen | Route | What's Real |
|--------|-------|------------|
| Item Bank Browser | `/repository/item-bank` | Full faceted search + analytics |
| Exam Assembly | `/exams/assembly` | MIP solver constraint satisfaction |
| Exam Assignment | `/exams/assign` | Timed exam delivery |
| Retired Exam Upload | `/exams/retired-upload` | Legacy import pipeline |
| Admin Dashboard | `/admin` | System KPIs, user management |
| Setup Wizard | `/admin/setup` | New institution setup |
| Faculty Management | `/admin/faculty` | Directory + course assignments |
| Knowledge Browser | `/admin/knowledge` | Full graph browsing UI |
| ILO Management | `/admin/ilos` | CRUD with framework mappings |
| Data Integrity Dashboard | `/admin/data-integrity` | Orphan nodes, broken links |
| User Management | `/institution/users` | Full CRUD |
| Onboarding (all roles) | `/onboarding/*` | Faculty wizard, admin setup |
| Notifications | `/notifications` | In-app + Socket.io push |
| LOD Enrichment | — | StandardTerm nodes (backend only) |

---

### Phase 5: "The Student Experience" (Weeks 33-48)

**New screens with real backend data:**

| Screen | Route | What's Real |
|--------|-------|------------|
| Student Registration | `/register/student` | Student role in Supabase Auth |
| Student Onboarding | `/onboarding/student` | Study preferences |
| Student Dashboard | `/student-dashboard` | BKT mastery overview |
| Student Practice | `/student/practice` | Session configuration |
| Student Question View | `/student/practice/session` | Item delivery + answer recording |
| Student Results | `/student/practice/results` | Score + review + explanation |
| Student Progress | `/student/progress` | Concept-level mastery heatmap |
| Student Analytics | `/student/analytics` | Trends, "Why Am I Struggling?" |
| **Advisor Dashboard** | — | **No prototype screen exists** |
| **At-Risk Alerts** | — | **No prototype screen exists** |
| Accreditation Reports (narrative) | `/institution/accreditation` | Claude-generated compliance narratives |
| IRT Calibration | — | Backend only (Python FastAPI) |

---

## Prototype Screens Without Roadmap Coverage

These 15 screens exist in the prototype but have **no explicit roadmap work assigned:**

| Screen | Route | Status |
|--------|-------|--------|
| `Home` | `/home` | Not mentioned in roadmap |
| `Registration` (generic) | `/register` | Redundant — role-specific registration exists |
| `PersonaOnboarding` | `/onboarding` | Redundant — role-specific onboarding exists |
| `FacultyCommunicationHub` | `/faculty/communications` | No roadmap mention |
| `StudentSupportCenter` | `/student/support` | No roadmap mention |
| `AnnouncementSystem` | `/admin/announcements` | No roadmap mention |
| `QuestionTemplates` | `/templates` | No roadmap mention |
| `BulkOperations` | `/bulk-operations` | Bulk generation exists, but not a standalone operations screen |
| `FacultyQuestionUpload` | `/uploads/faculty-questions` | Retired exam upload exists; this may be redundant |
| `GenerateTest` | `/generate/test` | No distinct roadmap work; generation is unified |
| `GenerateQuiz` | `/generate/quiz` | Same |
| `GenerateHandout` | `/generate/handout` | Same |
| `SystemConfigurationDashboard` | `/admin/settings` | Implied but not spec'd |
| `UserRoleManagement` | `/admin/settings/roles` | Implied but not spec'd |
| `QuestionPerformanceMetrics` | `/analytics/questions` | Implied by IRT but no dedicated screen in roadmap |

**Recommendation:** Don't build backends for these until they're explicitly needed. They can remain as mock-data prototypes for stakeholder demos.

---

## Roadmap Features Without Prototype Screens

These 6 roadmap features need **new screens not yet in the prototype:**

| Feature | Roadmap Phase | Needed Screen | Notes |
|---------|--------------|---------------|-------|
| CopilotKit Workbench (chat + preview) | Phase 1, Week 7-8 | `/faculty/quest` exists but needs CopilotKit rewrite | Current QuestWorkbench may not have CopilotKit integration |
| D3 Coverage Map (force-directed graph) | Phase 3, Week 21-22 | New component, likely embedded in dashboard | SubConcept graph colored by coverage |
| Advisor Dashboard | Phase 5, Week 41-42 | New route: `/advisor` or `/advisor/dashboard` | Cohort overview, per-student mastery, at-risk flags |
| At-Risk Student Detail | Phase 5, Week 41-42 | New route: `/advisor/students/:id` | Root-cause analysis, intervention recommendations |
| Exam Delivery (student-facing) | Phase 4, Week 27-28 | New route: `/student/exam/:id` | Timed assessment with answer recording |
| MIP Solver Constraint UI | Phase 4, Week 27-28 | Enhancement to `/exams/assembly` | Constraint relaxation feedback dialog |

---

## Recommended Screen Build Sequence

Based on the roadmap phases, here's the order screens should be connected to real backends:

### Sprint 1-2 (Weeks 1-4): Foundation
```
[ ] /login (Supabase Auth, minimal)
[ ] /courses/:id/upload-syllabus (file upload to Supabase Storage)
[ ] /courses/:id/processing (manual pipeline status)
[ ] /courses/:id/review-mapping (concept review)
```

### Sprint 3-4 (Weeks 5-8): Core Loop
```
[ ] /faculty/quest (QuestWorkbench — CopilotKit + LangGraph.js) ← CRITICAL PATH
[ ] /repository (basic question bank browser)
[ ] Approve/reject on generated items
```

### Sprint 5-6 (Weeks 9-12): Quality
```
[ ] /questions/:id (ItemDetail with Critic scores)
[ ] /questions/:id/refine (ConversationalRefinement)
[ ] /generation/progress (BatchProgress with Inngest)
[ ] /courses/subconcept-review (TEACHES_VERIFIED)
```

### Sprint 7-8 (Weeks 13-16): Trust
```
[ ] ECD + TaskShell integration (backend, affects generation output)
[ ] Data linting alerts (backend, surfaces in notifications)
[ ] Generation history view
```

### Sprint 9-12 (Weeks 17-24): Intelligence
```
[ ] /courses (AllCourses — multi-course)
[ ] /courses/:id (CourseDashboard with real coverage)
[ ] /dashboard (FacultyDashboard with KPIs + gap alerts)
[ ] /analytics/blueprint-coverage (USMLE 16×7 heatmap)
[ ] /admin/lcme-compliance-heatmap
[ ] /admin/lcme-element-drill-down
[ ] /institution (InstitutionalAdminDashboard)
[ ] /institution/accreditation (CSV export)
[ ] /courses/outcome-mapping (SLO → ILO)
[ ] NEW: D3 Coverage Map component
```

### Sprint 13-16 (Weeks 25-32): Instruments + Admin
```
[ ] /repository/item-bank (full faceted search)
[ ] /exams/assembly (MIP solver)
[ ] /exams/assign
[ ] /exams/retired-upload
[ ] /admin (AdminDashboard)
[ ] /admin/knowledge (KnowledgeBrowser)
[ ] /admin/ilos (ILOManagement)
[ ] /admin/data-integrity
[ ] /admin/setup (SetupWizard)
[ ] /admin/faculty
[ ] /institution/users
[ ] /onboarding/* (all roles)
[ ] /notifications
```

### Sprint 17-24 (Weeks 33-48): Students + Advisors
```
[ ] /register/student + /onboarding/student
[ ] /student-dashboard
[ ] /student/practice → /student/practice/session → /student/practice/results
[ ] /student/progress (BKT mastery)
[ ] /student/analytics
[ ] NEW: /advisor/dashboard
[ ] NEW: /advisor/students/:id (at-risk detail)
[ ] NEW: /student/exam/:id (exam delivery)
[ ] /institution/accreditation (narrative reports upgrade)
```

---

## Key Insight: The Prototype-Roadmap Gap

The prototype was built as a **comprehensive stakeholder demo** — all 100+ screens with mock data to show the vision. The roadmap builds the **real system** in value-delivery order. These serve different purposes:

| Dimension | Prototype (Current) | Roadmap (Plan) |
|-----------|-------------------|----------------|
| **Screens** | 89 components, all mock data | ~8 screens in Phase 1, growing to ~60 by Phase 5 |
| **Generation UX** | Form-based (dropdowns, selectors) | Conversational (CopilotKit chat + progressive render) |
| **Dashboard** | Full KPI strip with sparklines | Phase 1 has no dashboard; Phase 3 adds it |
| **Student** | Complete practice + mastery + analytics | Phase 5 (months away) |
| **Admin** | 15 screens built | Phase 4 (Week 31-32) |
| **Design system** | Fully applied everywhere | "Not full polish" until Phase 3 Week 21-22 |
| **Auth** | 10 screens with role selection | Minimal Supabase Auth in Phase 1 |

**The prototype's value:** Stakeholder buy-in, investor demos, design direction validation.
**The roadmap's value:** Actual working software that proves the thesis in stages.

The bridge: As each roadmap phase completes, swap the mock `setTimeout` calls in the corresponding prototype screens with real API calls to the backend. The screens don't need to be rewritten — they need their `fetchDashboardData()` and `handleSubmit()` functions pointed at real endpoints.
