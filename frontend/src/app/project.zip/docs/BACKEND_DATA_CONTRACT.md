# Journey-OS: Complete Screen Inventory & Backend Data Contract

> **Generated:** March 3, 2026
> **Total Routes:** 107 route definitions mapping to 89 unique page components across 25 subdirectories
> **Status:** All screens currently use mock data with `setTimeout` delays simulating API calls. The data shapes documented below reflect exactly what each component currently expects and renders.

---

## Table of Contents

1. [Public / Marketing](#1-public--marketing-2-screens)
2. [Authentication](#2-authentication-10-screens)
3. [Onboarding](#3-onboarding-4-screens)
4. [Faculty Dashboards](#4-faculty-dashboards-3-screens)
5. [Student Dashboard & Learning](#5-student-dashboard--learning-7-screens)
6. [Course Management](#6-course-management-14-screens)
7. [Question Generation](#7-question-generation-10-screens)
8. [Question Review & Refinement](#8-question-review--refinement-7-screens)
9. [Repository & Item Bank](#9-repository--item-bank-2-screens)
10. [Exam Management](#10-exam-management-3-screens)
11. [Uploads](#11-uploads-1-screen)
12. [Analytics & Reporting](#12-analytics--reporting-6-screens)
13. [Institutional Admin](#13-institutional-admin-5-screens)
14. [Super Admin / Platform Admin](#14-super-admin--platform-admin-15-screens)
15. [Faculty Course Management](#15-faculty-course-management-6-screens)
16. [Communications](#16-communications-3-screens)
17. [Templates & Operations](#17-templates--operations-2-screens)
18. [Settings, Profile, Notifications, Help](#18-settings-profile-notifications-help-4-screens)
19. [Public Application](#19-public-application-1-screen)
20. [Error Pages](#20-error-pages-1-screen)
21. [Cross-Cutting Backend Requirements](#cross-cutting-backend-requirements)
22. [Known Issues & Consolidation Notes](#known-issues--consolidation-notes)

---

## Authentication Flows by Role

### Student Flow
1. `/` (Landing) -- Landing page with waitlist
2. `/role-selection` -- Select "Student"
3. `/register/student` (StudentRegistration) -- Fill form
4. Email sent with verification link
5. `/email-verification?token=xxx&role=student` -- Verify email
6. `/onboarding/student` (StudentOnboarding) -- Personalize (study goals, subjects, time)
7. `/student-dashboard` -- Student Dashboard

### Faculty Flow
1. `/` (Landing) -- Landing page with waitlist
2. `/role-selection` -- Select "Faculty"
3. `/register/faculty` (FacultyRegistration) -- Fill form
4. Email sent with verification link
5. `/email-verification?token=xxx&role=faculty` -- Verify email
6. `/onboarding/faculty` (FacultyOnboarding) -- Personalize (teaching areas, question types, courses)
7. `/dashboard` -- Faculty Dashboard

### Admin Flow
1. `/` (Landing) -- Landing page with waitlist
2. `/role-selection` -- Select "Institutional Admin"
3. `/register/admin` (AdminRegistration) -- Fill form (includes access code)
4. Email sent with verification link
5. `/email-verification?token=xxx&role=admin` -- Verify email
6. `/onboarding/admin` (AdminOnboarding) -- Setup guide and task overview
7. `/admin` -- Admin Dashboard

### Sign In
- `/login` -- Select role tab (Student/Faculty/Admin) -- Redirects to appropriate dashboard

---

## 1. Public / Marketing (2 screens)

| Route | Component | Source File | Data Expectations |
|-------|-----------|-------------|-------------------|
| `/` | `Landing` | `pages/Landing.tsx` | **Read:** None (static). **Write:** `POST /waitlist` -- `{ email, role, institution }` |
| `/home` | `Home` | `pages/Home.tsx` | Static content page |

---

## 2. Authentication (10 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/role-selection` | `RoleSelection` | `pages/auth/RoleSelection.tsx` | Static UI -- navigates to `/register/{role}` |
| `/login` | `Login` | `pages/auth/Login.tsx` | **Write:** `POST /auth/login` -- `{ email, password, role }` -- Returns `{ token, user, redirect_path }` |
| `/register` | `Registration` | `pages/auth/Registration.tsx` | Generic registration shell |
| `/register/student` | `StudentRegistration` | `pages/auth/StudentRegistration.tsx` | **Write:** `POST /auth/register/student` -- `{ email, name, password, studentId, yearLevel }` |
| `/register/faculty` | `FacultyRegistration` | `pages/auth/FacultyRegistration.tsx` | **Write:** `POST /auth/register/faculty` -- `{ email, name, password, title, department }` |
| `/register/admin` | `AdminRegistration` | `pages/auth/AdminRegistration.tsx` | **Write:** `POST /auth/register/admin` -- `{ email, name, password, title, institutionName, accessCode }` |
| `/forgot-password` | `ForgotPassword` | `pages/auth/ForgotPassword.tsx` | **Write:** `POST /auth/forgot-password` -- `{ email }` |
| `/email-verification` | `EmailVerification` | `pages/auth/EmailVerification.tsx` | **Read:** `GET /auth/verify-email?token=xxx&role=xxx` -- `{ verified: boolean }` |
| `/verify-email` | `EmailVerification` | `pages/auth/EmailVerification.tsx` | Same as above (alias route) |
| `/invite/accept` | `InvitationAccept` | `pages/auth/InvitationAccept.tsx` | **Read:** `GET /auth/invitation?token=xxx`. **Write:** `POST /auth/accept-invitation` -- `{ token, password }` |

### Department Enum (Faculty Registration)

```
Anatomy, Biochemistry, Cardiology, Emergency Medicine, Family Medicine,
Internal Medicine, Neurology, Obstetrics and Gynecology, Pathology,
Pediatrics, Pharmacology, Physiology, Psychiatry, Radiology, Surgery
```

### Auth User Model

```typescript
interface User {
  id: string;
  email: string;
  name: string;
  role: "student" | "faculty" | "admin" | "advisor" | "institutional_admin";
  title?: string;
  department?: string;
  institution_id: string;
  student_id?: string;
  year_level?: string;
  avatar_url?: string;
  initials: string;
  created_at: string;
}
```

### Login Response

```typescript
interface LoginResponse {
  token: string;
  user: User;
  redirect_path: string;
  // redirect_path values by role:
  // faculty  -> "/dashboard"
  // student  -> "/student-dashboard"
  // admin    -> "/admin"
  // advisor  -> "/dashboard"
}
```

---

## 3. Onboarding (4 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/onboarding` | `PersonaOnboarding` | `pages/auth/PersonaOnboarding.tsx` | Persona selection -- routes to role-specific onboarding |
| `/onboarding/student` | `StudentOnboarding` | `pages/onboarding/StudentOnboarding.tsx` | **Write:** `POST /onboarding/student` -- `{ study_goals[], subjects[], weekly_study_time }` |
| `/onboarding/faculty` | `FacultyOnboarding` | `pages/onboarding/FacultyOnboarding.tsx` | **Write:** `POST /onboarding/faculty` -- see model below |
| `/onboarding/admin` | `AdminOnboarding` | `pages/onboarding/AdminOnboarding.tsx` | **Write:** `POST /onboarding/admin` -- `{ setup_tasks_completed[], institution_config }` |

### Faculty Onboarding Data

```typescript
interface FacultyOnboardingData {
  teachingAreas: string[];
  // Options: "Basic Sciences (Pre-clinical)", "Clinical Sciences",
  //          "Board Exam Preparation", "Clerkship Education", "Residency Training"

  questionTypes: string[];
  // Options: "Multiple Choice (Single Best Answer)", "Multiple Choice (Multiple Correct)",
  //          "Clinical Vignettes", "Image-based Questions", "Laboratory Data Interpretation"

  usageGoals: string[];
  // Options: "Create course exam questions", "Build question banks for students",
  //          "Generate USMLE-style practice questions", "Assess student learning outcomes",
  //          "Create formative assessments"

  courseName?: string;
}
```

---

## 4. Faculty Dashboards (3 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/dashboard` | `Dashboard` | `pages/dashboard/Dashboard.tsx` | **Read:** `GET /faculty/dashboard` -- KPIs + courses + activity + mastery |
| `/faculty-dashboard` | `FacultyDashboard` | `pages/dashboard/FacultyDashboard.tsx` | Same data shape (alias) |
| `/faculty` or `/faculty/dashboard` | `FacultyDashboard` | `pages/faculty/FacultyDashboard.tsx` | **Read:** `GET /faculty/dashboard` -- courses + recent activity |

### Faculty Dashboard Response

```typescript
interface FacultyDashboardData {
  user: {
    name: string;       // e.g. "Dr. Adeyemi"
    initials: string;   // e.g. "OA"
    role: string;       // "Faculty"
    department: string; // e.g. "Pharmacology"
  };

  kpis: {
    questions_generated: number;      // e.g. 342
    avg_item_quality: number;         // IRT difficulty, e.g. 0.84
    coverage_score: number;           // percentage, e.g. 91
    active_students: number;          // e.g. 127
    sparklines: number[][];           // 7-point trend arrays per KPI
    changes: string[];                // e.g. ["+28 this week", "IRT difficulty", ...]
  };

  courses: Course[];
  recent_activity: ActivityItem[];
  mastery_topics: { name: string; mastery: number }[];
}
```

### Course Model

```typescript
interface Course {
  id: string;
  code: string;           // e.g. "PHAR 501"
  name: string;           // e.g. "Medical Pharmacology I"
  term: string;           // e.g. "Spring 2026"
  student_count: number;
  question_count: number;
  coverage: number;        // percentage 0-100
  status: "active" | "archived" | "draft";
  last_activity: string;   // relative timestamp
  color?: string;          // hex color for UI
}
```

### Activity Item Model

```typescript
interface ActivityItem {
  type: "generated" | "review" | "alert" | "student" |
        "question_generated" | "student_added" | "course_updated" |
        "completed" | "milestone";
  text: string;
  description?: string;
  course_name?: string;
  time: string;            // relative timestamp, e.g. "2 hours ago"
  icon?: string;
}
```

---

## 5. Student Dashboard & Learning (7 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/student-dashboard` or `/student` | `StudentDashboard` | `pages/dashboard/StudentDashboard.tsx` | **Read:** `GET /student/dashboard` |
| `/student/dashboard` | `StudentDashboard` | `pages/dashboard/StudentDashboard.tsx` | Same (alias) |
| `/student/practice` | `StudentPractice` | `pages/student/StudentPractice.tsx` | **Read:** `GET /student/practice-sets?difficulty=&topics=` |
| `/student/practice/session` | `StudentQuestionView` | `pages/student/StudentQuestionView.tsx` | **Read:** `GET /student/session/{id}/questions` |
| `/student/practice/results` | `StudentResults` | `pages/student/StudentResults.tsx` | **Read:** `GET /student/session/{id}/results` |
| `/student/progress` | `StudentProgress` | `pages/student/StudentProgress.tsx` | **Read:** `GET /student/progress` -- concept-level mastery map |
| `/student/analytics` | `StudentAnalytics` | `pages/student/StudentAnalytics.tsx` | **Read:** `GET /student/analytics` -- performance trends |
| `/student/support` | `StudentSupportCenter` | `pages/communications/StudentSupportCenter.tsx` | Communications/support interface |

### Student Dashboard Response

```typescript
interface StudentDashboardData {
  user: {
    name: string;       // e.g. "John Mitchell"
    initials: string;   // e.g. "JM"
    role: string;       // "Student"
    department: string; // e.g. "M2" (year level)
  };

  kpis: {
    questions_answered: number;     // e.g. 247
    accuracy_rate: number;          // percentage, e.g. 78
    current_streak: number;         // days, e.g. 12
    study_time: number;             // hours this week, e.g. 8.5
    sparklines: number[][];
  };

  courses: StudentCourse[];
  upcoming_practice: UpcomingPractice[];
  recent_activity: ActivityItem[];
}

interface StudentCourse {
  name: string;          // e.g. "Medical Pharmacology I"
  code: string;          // e.g. "PHAR 501"
  progress: number;      // percentage 0-100
  next_topic: string;    // e.g. "Cardiovascular Drugs"
  due_date: string;      // e.g. "Feb 18"
  color: string;
}

interface UpcomingPractice {
  title: string;
  questions: number;
  due: string;           // "Today", "Tomorrow", or date
  priority: "high" | "medium" | "low";
}
```

### Practice Set Model

```typescript
interface PracticeSet {
  id: string;
  title: string;
  description: string;
  question_count: number;
  estimated_time: number;        // minutes
  difficulty: "Easy" | "Medium" | "Hard" | "Mixed";
  topics: string[];
  last_attempted?: string;
  best_score?: number;           // percentage
}
```

### Student Question Model (Practice Session)

```typescript
interface StudentQuestion {
  id: number;
  stem: string;                  // clinical vignette text
  options: {
    id: string;                  // "A", "B", "C", "D", "E"
    text: string;
  }[];
  correctAnswer: string;         // option ID, e.g. "B"
  explanation: string;           // general explanation
  rationale: {
    correct: string;             // why the correct answer is right
    wrongOptions: Record<string, string>;  // why each wrong answer is wrong
  };
  tags: {
    subject: string;             // e.g. "Cardiology"
    system: string;              // e.g. "Cardiovascular"
    difficulty: string;          // "Easy" | "Medium" | "Hard"
    bloomLevel: string;          // e.g. "Application"
  };
}
```

### Quick Practice Configuration

```typescript
interface QuickPracticeConfig {
  question_count: number;        // default: 10
  time_limit: number;            // minutes, default: 15
  include_weak_areas: boolean;   // default: true
}
```

---

## 6. Course Management (14 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/courses` | `AllCourses` | `pages/courses/AllCourses.tsx` | **Read:** `GET /courses?status=&search=` |
| `/courses/create` | `CreateCourse` | `pages/courses/CreateCourse.tsx` | **Write:** `POST /courses` |
| `/courses/:courseId` | `CourseDashboard` | `pages/courses/CourseDashboard.tsx` | **Read:** `GET /courses/{id}` |
| `/courses/:courseId/upload-syllabus` | `UploadSyllabus` | `pages/courses/UploadSyllabus.tsx` | **Write:** `POST /courses/{id}/syllabus` -- multipart file (PDF/DOCX) or `{ text_content }` |
| `/courses/:courseId/processing` | `SyllabusProcessing` | `pages/courses/SyllabusProcessing.tsx` | **Read:** `GET /courses/{id}/processing-status` (polling/SSE) |
| `/courses/:courseId/review-mapping` | `ReviewSyllabusMapping` | `pages/courses/ReviewSyllabusMapping.tsx` | **Read:** `GET /courses/{id}/syllabus-mapping`. **Write:** `PUT /courses/{id}/syllabus-mapping` |
| `/courses/syllabus-editor` | `SyllabusEditor` | `pages/courses/SyllabusEditor.tsx` | **Read/Write:** Edit parsed syllabus structure |
| `/courses/outcome-mapping` | `OutcomeMapping` | `pages/courses/OutcomeMapping.tsx` | **Read:** `GET /courses/{id}/outcomes` -- ILO/SLO mappings |
| `/courses/upload-lecture` | `LectureUpload` | `pages/courses/LectureUpload.tsx` | **Write:** `POST /courses/{id}/lectures` -- file upload |
| `/courses/lecture-processing` | `LectureProcessing` | `pages/courses/LectureProcessing.tsx` | **Read:** `GET /lectures/{id}/processing-status` (polling/SSE) |
| `/courses/subconcept-review` | `SubConceptReviewQueue` | `pages/courses/SubConceptReviewQueue.tsx` | **Read:** `GET /courses/{id}/subconcepts?status=pending`. **Write:** `PATCH /subconcepts/{id}` |
| `/courses/:courseId/ready` | `CourseReady` | `pages/courses/CourseReady.tsx` | **Read:** `GET /courses/{id}/readiness` -- completion checklist |
| `/courses/:courseId/week/:weekId` | `WeekView` | `pages/courses/WeekView.tsx` | **Read:** `GET /courses/{id}/weeks/{weekId}` |
| `/courses/:courseId/week/:weekId/upload-materials` | `WeekMaterialsUpload` | `pages/courses/WeekMaterialsUpload.tsx` | **Write:** `POST /weeks/{id}/materials` -- file upload |

### Create Course Request

```typescript
interface CreateCourseRequest {
  name: string;           // e.g. "Pathology"
  code: string;           // e.g. "PATH-250"
  semester: string;       // "fall-2025" | "spring-2026" | "summer-2026" | "fall-2026"
  year: number;
  description?: string;
  credit_hours?: number;
  student_level?: string; // "M1" | "M2" | "M3" | "M4"
}
```

### Course Detail Response

```typescript
interface CourseDetail {
  id: string;
  name: string;
  code: string;
  semester: string;
  year: number;
  description: string;
  status: "draft" | "active" | "archived";
  weeks: Week[];
  total_questions: number;
  coverage_percentage: number;
  recent_questions: RecentQuestion[];
}

interface Week {
  id: number;
  title: string;               // e.g. "Introduction to Cardiovascular System"
  topics: string[];            // e.g. ["Heart Anatomy", "Blood Flow", "Cardiac Cycle"]
  question_count: number;
  target_count: number;        // e.g. 15
  coverage: "high" | "medium" | "low";
}

interface RecentQuestion {
  id: string;
  stem: string;                // truncated stem text
  status: "approved" | "pending" | "rejected";
  date: string;                // relative timestamp
}
```

### Syllabus Mapping Model

```typescript
interface SyllabusMapping {
  course_id: string;
  extracted_topics: {
    name: string;
    week: number;
    confidence: number;        // 0-1, AI confidence score
  }[];
  concept_mappings: {
    topic: string;
    concept_id: string;
    subconcept_ids: string[];
  }[];
  unmapped_topics: string[];
}
```

### Processing Status (for Syllabus & Lecture)

```typescript
interface ProcessingStatus {
  status: "queued" | "extracting" | "mapping" | "completed" | "failed";
  progress: number;            // 0-100
  steps: {
    name: string;
    status: "pending" | "in_progress" | "completed" | "failed";
    message?: string;
  }[];
  error?: string;
}
```

---

## 7. Question Generation (10 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/generate/topic` | `GenerateQuestionsTopic` | `pages/generation/GenerateQuestionsTopic.tsx` | **Read:** topic tree. **Write:** `POST /generate/questions` |
| `/faculty/questions/generate` | `GenerateQuestionsTopic` | Same component | Same |
| `/courses/:courseId/week/:weekId/generate` | `GenerateQuestionsSyllabus` | `pages/generation/GenerateQuestionsSyllabus.tsx` | **Write:** `POST /generate/from-syllabus` |
| `/generation/wizard` | `GenerationSpecificationWizard` | `pages/generation/GenerationSpecificationWizard.tsx` | **Read:** gap analysis. **Write:** `POST /generate/batch` |
| `/generation/progress` | `BatchProgress` | `pages/generation/BatchProgress.tsx` | **Read:** `GET /generation/batch/{id}/progress` (SSE/polling) |
| `/generate/test` | `GenerateTest` | `pages/generation/GenerateTest.tsx` | **Write:** `POST /generate/test` |
| `/generate/quiz` | `GenerateQuiz` | `pages/generation/GenerateQuiz.tsx` | **Write:** `POST /generate/quiz` |
| `/generate/handout` | `GenerateHandout` | `pages/generation/GenerateHandout.tsx` | **Write:** `POST /generate/handout` |
| `/faculty/quest` | `QuestWorkbench` | `pages/faculty/QuestWorkbench.tsx` | Interactive question generation workbench |
| `/courses/:courseId/week/:weekId/generate-test` | `GenerateTest` | Same component | Same with course/week context |
| `/courses/:courseId/week/:weekId/generate-quiz` | `GenerateQuiz` | Same component | Same with course/week context |
| `/courses/:courseId/week/:weekId/generate-handout` | `GenerateHandout` | Same component | Same with course/week context |

### Topic Tree (for Topic Selector)

```typescript
interface SystemCategory {
  id: string;              // e.g. "cardiovascular"
  name: string;            // e.g. "Cardiovascular System"
  topics: Topic[];
}

interface Topic {
  id: string;
  name: string;
  parent: string;          // system category id
  question_count: number;  // existing questions for this topic
}
```

### Generation Request

```typescript
interface GenerationRequest {
  topic_ids?: string[];
  course_id?: string;
  week_id?: number;
  count: number;                    // 1-50
  difficulty: "easy" | "medium" | "hard" | "mixed";
  question_type: "mcq" | "clinical_vignette" | "mixed";
  bloom_levels?: BloomLevel[];
  source_scope?: "course" | "institution" | "general";
  format?: "Single Best Answer";
}

type BloomLevel = "Remember" | "Understand" | "Apply" | "Analyze" | "Evaluate" | "Create";
```

### Gap Analysis Response

```typescript
interface GapAnalysis {
  coverage_gaps: string[];
  // e.g. ["Heart Failure Management (0 items)", "Arrhythmia Diagnosis (2 items - need 8 more)"]

  usmle_imbalance: {
    system: string;
    current: number;
    target: number;
  }[];

  difficulty_gaps: {
    level: string;         // "Easy" | "Medium" | "Hard"
    current: number;
    target: number;
  }[];

  recommended_targets: string[];
  // e.g. ["Heart Failure: Diagnosis and Management", "Atrial Fibrillation: Treatment Options"]
}
```

### Generation Specification (Wizard Step 2)

```typescript
interface GenerationSpecification {
  selected_subconcepts: string[];
  format: string;                  // "Single Best Answer"
  bloom_levels: BloomLevel[];
  difficulties: string[];
  source_scope: "course" | "institution" | "general";
  count: number;
  estimated_cost?: number;
  estimated_time?: string;
}
```

### Batch Progress Response

```typescript
interface BatchProgress {
  batch_id: string;
  status: "queued" | "processing" | "completed" | "failed";
  total: number;
  completed: number;
  items: GeneratedQuestion[];      // progressively populated
  estimated_cost?: number;
  estimated_time?: string;
}
```

---

## 8. Question Review & Refinement (7 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/questions/review` | `FacultyReviewQueue` | `pages/questions/FacultyReviewQueue.tsx` | **Read:** `GET /questions?status=&system=&difficulty=&batch_id=` |
| `/faculty/questions/review` | `FacultyReviewQueue` | Same component | Same |
| `/questions/:questionId` | `ItemDetail` | `pages/questions/ItemDetail.tsx` | **Read:** `GET /questions/{id}`. **Write:** `PATCH /questions/{id}` |
| `/questions/:questionId/detail` | `QuestionDetailView` | `pages/questions/QuestionDetailView.tsx` | Same as ItemDetail (alternate layout) |
| `/questions/:questionId/refine` | `ConversationalRefinement` | `pages/questions/ConversationalRefinement.tsx` | **Write:** `POST /questions/{id}/refine` |
| `/questions/:questionId/ai-refine` | `AIRefinement` | `pages/questions/AIRefinement.tsx` | **Write:** `POST /questions/{id}/ai-refine` |
| `/questions/:questionId/history` | `QuestionHistory` | `pages/questions/QuestionHistory.tsx` | **Read:** `GET /questions/{id}/history` |
| `/courses/:courseId/questions` | `QuestionReviewList` | `pages/questions/QuestionReviewList.tsx` | **Read:** `GET /courses/{id}/questions?status=` |
| `/faculty/questions/:id` | `QuestionDetailView` | `pages/questions/QuestionDetailView.tsx` | Same |

### Question Detail Model (Core)

```typescript
interface QuestionDetail {
  id: string;
  stem: string;
  lead_in: string;
  options: QuestionOption[];
  format: string;                    // "Single Best Answer", "Multiple Correct", etc.
  system: string;                    // Organ system, e.g. "Cardiovascular"
  difficulty: "Easy" | "Medium" | "Hard";
  bloom_level: string;               // Bloom's taxonomy level
  clinical_setting: string;          // e.g. "Emergency Department"
  subconcept: string;                // Knowledge graph node reference
  target_slo: string;                // Student learning outcome
  quality_score: number;             // 0-1, IRT-derived
  times_used: number;
  status: "pending" | "approved" | "rejected";
  created_by: string;
  created_at: string;
  pipeline_version: string;          // AI pipeline version, e.g. "v2.1"
  core_model: string;                // LLM model used, e.g. "gpt-4"
  batch_id: string;
  course_id?: string;
  reject_reason?: string;
}

interface QuestionOption {
  id: string;                        // "a", "b", "c", "d", "e"
  text: string;
  is_correct: boolean;
  rationale: string;                 // why this option is right/wrong
  misconception_category?: string;   // what misconception this distractor targets
}
```

### Review Queue Filters

```typescript
interface ReviewQueueFilters {
  status: "all" | "pending" | "approved" | "rejected";
  system: "all" | string;           // organ system filter
  difficulty: "all" | "Easy" | "Medium" | "Hard";
  batch_id?: string;
}
```

### Review Actions

```typescript
// Approve a question
PATCH /questions/{id}
{ status: "approved" }

// Reject a question
PATCH /questions/{id}
{ status: "rejected", reject_reason: string }
```

### Conversational Refinement

```typescript
interface RefinementRequest {
  instruction: string;               // natural language instruction
  target_stage: "auto" | "core" | "distractors" | "rationale";
  iteration: number;                 // current iteration (max 5)
}

interface RefinementResponse {
  revised: QuestionDetail;           // the updated question
  changes_summary: string;           // what was changed
  iteration: number;
}

interface IterationHistory {
  id: number;
  instruction: string;
  timestamp: string;
}

// Max iterations per question: 5
```

---

## 9. Repository & Item Bank (2 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/repository` | `Repository` | `pages/repository/Repository.tsx` | **Read:** `GET /repository/questions?search=&page=&limit=` |
| `/repository/item-bank` | `ItemBankBrowser` | `pages/repository/ItemBankBrowser.tsx` | **Read:** `GET /item-bank?system=&difficulty=&bloom=&status=&format=` |
| `/faculty/repository` | `Repository` | Same component | Same |
| `/faculty/questions/repository` | `Repository` | Same component | Same |

### Item Bank Filters

```typescript
interface ItemBankFilters {
  system?: string;           // organ system
  difficulty?: string;
  bloom_level?: string;
  status?: string;
  format?: string;
  search?: string;
  page: number;
  limit: number;             // default: 20
}

interface ItemBankResponse {
  items: QuestionDetail[];
  total: number;
  page: number;
  total_pages: number;
}
```

---

## 10. Exam Management (3 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/exams/assembly` | `ExamAssembly` | `pages/exams/ExamAssembly.tsx` | **Read:** available questions. **Write:** `POST /exams` |
| `/faculty/exams/assembly` | `ExamAssembly` | Same component | Same |
| `/exams/assign` | `ExamAssignment` | `pages/exams/ExamAssignment.tsx` | **Write:** `POST /exams/{id}/assign` |
| `/faculty/exams/assignment` | `ExamAssignment` | Same component | Same |
| `/exams/retired-upload` | `RetiredExamUpload` | `pages/exams/RetiredExamUpload.tsx` | **Write:** `POST /exams/retired` -- file upload |

### Exam Model

```typescript
interface Exam {
  id: string;
  name: string;                      // e.g. "Cardiovascular Midterm Exam"
  questions: ExamQuestion[];
  total_points: number;
  blueprint_validation: BlueprintValidation;
  created_at: string;
  status: "draft" | "published" | "completed";
}

interface ExamQuestion {
  id: string;
  stem: string;
  system: string;
  difficulty: "Easy" | "Medium" | "Hard";
  bloom_level: string;
  clinical_setting: string;
}

interface BlueprintValidation {
  system_distribution: {
    system: string;
    actual: number;
    target: number;
    status: "pass" | "warn" | "fail";
  }[];
  difficulty_balance: {
    difficulty: string;
    actual: number;
    target: number;
    status: "pass" | "warn" | "fail";
  }[];
  total_questions: number;
  total_points: number;
}
```

### Exam Assignment Request

```typescript
interface ExamAssignmentRequest {
  exam_id: string;
  student_ids: string[];
  start_time: string;              // ISO datetime
  end_time: string;                // ISO datetime
  duration: number;                // minutes
}
```

---

## 11. Uploads (1 screen)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/uploads/faculty-questions` | `FacultyQuestionUpload` | `pages/uploads/FacultyQuestionUpload.tsx` | **Write:** `POST /uploads/questions` -- bulk import (CSV/Excel) |

---

## 12. Analytics & Reporting (6 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/analytics` | `Analytics` | `pages/analytics/Analytics.tsx` | **Read:** `GET /analytics/overview` |
| `/analytics/course/:courseId` | `CourseAnalytics` | `pages/analytics/CourseAnalytics.tsx` | **Read:** `GET /analytics/course/{id}` |
| `/analytics/personal` | `PersonalDashboard` | `pages/analytics/PersonalDashboard.tsx` | **Read:** `GET /analytics/personal` |
| `/analytics/blueprint-coverage` | `BlueprintCoverage` | `pages/analytics/BlueprintCoverage.tsx` | **Read:** `GET /analytics/blueprint?course_id=` |
| `/analytics/questions` | `QuestionPerformanceMetrics` | `pages/analytics/QuestionPerformanceMetrics.tsx` | **Read:** `GET /analytics/questions` |
| `/institution/analytics` | `InstitutionalAnalytics` | `pages/analytics/InstitutionalAnalytics.tsx` | **Read:** `GET /analytics/institutional` |
| `/faculty/analytics` | `InstitutionalAnalytics` | Same component | Same |
| `/admin/analytics` | `InstitutionalAnalytics` | Same component | Same |

### Course Analytics Response

```typescript
interface CourseAnalyticsData {
  weekly_data: { week: string; questions: number }[];
  difficulty_data: { name: string; value: number; color: string }[];
  generation_data: { date: string; count: number }[];
  topics_data: { topic: string; count: number }[];
  blueprint_coverage: {
    system: string;
    total: number;
    covered: number;
    percentage: number;
  }[];
}
```

---

## 13. Institutional Admin (5 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/institution` | `InstitutionalAdminDashboard` | `pages/institution/InstitutionalAdminDashboard.tsx` | **Read:** `GET /institution/dashboard` |
| `/institution/dashboard` | `InstitutionalAdminDashboard` | Same | Same |
| `/institution/users` | `UserManagement` | `pages/institution/UserManagement.tsx` | **CRUD:** `/institution/users` |
| `/institution/frameworks` | `FrameworkConfiguration` | `pages/institution/FrameworkConfiguration.tsx` | **Read/Write:** `/institution/frameworks` |
| `/institution/coverage` | `CoverageDashboard` | `pages/institution/CoverageDashboard.tsx` | **Read:** `GET /institution/coverage` |
| `/institution/accreditation` | `AccreditationReports` | `pages/institution/AccreditationReports.tsx` | **Read:** `GET /institution/accreditation/reports` |
| `/institution/settings` | `Settings` | `pages/settings/Settings.tsx` | Same as general settings |
| `/institution/faculty` | `FacultyManagement` | `pages/admin/FacultyManagement.tsx` | Same as admin faculty management |

### Institutional Dashboard Response

```typescript
interface InstitutionalDashboardData {
  stats: QuickStat[];
  alerts: InstitutionalAlert[];
  coverage_overview: CoverageOverview;
}

interface QuickStat {
  label: string;
  value: string | number;
  change: string;                    // e.g. "+12 this month"
  trend: "up" | "down" | "neutral";
  icon: string;                      // icon identifier
  color: string;                     // hex color
}

interface InstitutionalAlert {
  id: string;
  type: "info" | "warning" | "success";
  title: string;
  description: string;
  timestamp: string;
  action_label?: string;
  action_href?: string;
}
```

### Supported Competency Frameworks

```typescript
interface FrameworkConfiguration {
  usmle: { enabled: boolean; version: string };       // USMLE Step 1/2
  acgme: { enabled: boolean; competencies: string[] }; // ACGME competencies
  epa: { enabled: boolean; activities: string[] };      // Entrustable Professional Activities
  blooms: { enabled: boolean; levels: string[] };       // Bloom's taxonomy (6 levels)
  millers: { enabled: boolean; levels: string[] };      // Miller's pyramid
  lcme: { enabled: boolean; standards: string[] };      // LCME standards
}
```

---

## 14. Super Admin / Platform Admin (15 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/admin` | `AdminDashboard` | `pages/admin/AdminDashboard.tsx` | **Read:** `GET /admin/dashboard` |
| `/admin/dashboard` | `AdminDashboard` | Same | Same |
| `/admin/institutions` | `InstitutionListDashboard` | `pages/admin/InstitutionListDashboard.tsx` | **Read:** `GET /admin/institutions` |
| `/admin/institutions/:id` | `InstitutionDetailView` | `pages/admin/InstitutionDetailView.tsx` | **Read:** `GET /admin/institutions/{id}` |
| `/admin/users` | `AdminUserDirectory` | `pages/admin/AdminUserDirectory.tsx` | **CRUD:** `/admin/users?role=&status=&search=` |
| `/admin/announcements` | `AnnouncementSystem` | `pages/communications/AnnouncementSystem.tsx` | **CRUD:** `/admin/announcements` |
| `/admin/settings` | `SystemConfigurationDashboard` | `pages/settings/SystemConfigurationDashboard.tsx` | **Read/Write:** `/admin/settings` |
| `/admin/settings/roles` | `UserRoleManagement` | `pages/settings/UserRoleManagement.tsx` | **CRUD:** `/admin/roles` |
| `/admin/applications` | `ApplicationReviewQueue` | `pages/admin/ApplicationReviewQueue.tsx` | **Read:** `GET /admin/applications?status=pending`. **Write:** `PATCH /admin/applications/{id}` |
| `/admin/setup` | `SetupWizard` | `pages/admin/SetupWizard.tsx` | Multi-step institution setup wizard |
| `/admin/frameworks` | `FrameworkManagement` | `pages/admin/FrameworkManagement.tsx` | **CRUD:** `/admin/frameworks` |
| `/admin/faculty` | `FacultyManagement` | `pages/admin/FacultyManagement.tsx` | **CRUD:** `/admin/faculty` |
| `/admin/knowledge` | `KnowledgeBrowser` | `pages/admin/KnowledgeBrowser.tsx` | **Read:** `GET /admin/knowledge?system=&search=` |
| `/admin/knowledge/:uuid` | `SubConceptDetail` | `pages/admin/SubConceptDetail.tsx` | **Read:** `GET /admin/knowledge/{uuid}` |
| `/admin/ilos` | `ILOManagement` | `pages/admin/ILOManagement.tsx` | **CRUD:** `/admin/ilos` |
| `/admin/data-integrity` | `DataIntegrityDashboard` | `pages/admin/DataIntegrityDashboard.tsx` | **Read:** `GET /admin/data-integrity` |
| `/admin/fulfills-review` | `FULFILLSReviewQueue` | `pages/admin/FULFILLSReviewQueue.tsx` | **Read/Write:** FULFILLS relationship review |
| `/admin/lcme-compliance-heatmap` | `LCMEComplianceHeatmap` | `pages/admin/LCMEComplianceHeatmap.tsx` | **Read:** `GET /admin/lcme/coverage` |
| `/admin/lcme-element-drill-down` | `LCMEElementDrillDown` | `pages/admin/LCMEElementDrillDown.tsx` | **Read:** `GET /admin/lcme/elements/{id}` |

### Admin Dashboard Response

```typescript
interface AdminDashboardData {
  user: { name: string; initials: string; role: string; department: string };

  kpis: {
    total_users: number;              // e.g. 287
    system_health: number;            // percentage, e.g. 98
    total_questions: number;          // e.g. 18500
    coverage_score: number;           // institutional average, e.g. 89
    sparklines: number[][];
  };

  recent_users: {
    name: string;
    email: string;
    role: string;
    status: "active" | "pending";
    joined: string;
  }[];

  system_alerts: {
    type: "warning" | "info" | "success";
    text: string;
    time: string;
    priority: "high" | "medium" | "low";
  }[];

  course_stats: {
    dept: string;
    courses: number;
    items: number;
    coverage: number;
    faculty: number;
  }[];
}
```

### Knowledge Graph Models

```typescript
interface KnowledgeNode {
  id: string;                        // UUID
  name: string;
  description?: string;
  level: "domain" | "concept" | "subconcept";
  child_count?: number;
  teaching_chunks?: number;          // subconcept only
  assessment_items?: number;         // subconcept only
  children?: KnowledgeNode[];
}
```

### ILO (Institutional Learning Outcome) Model

```typescript
interface ILO {
  id: string;
  course_code: string;               // e.g. "CARD-501"
  ilo_code: string;                  // e.g. "ILO-1"
  description: string;
  mappings: {
    acgme: number;                   // count of mapped ACGME competencies
    epa: number;                     // count of mapped EPAs
    lcme: number;                    // count of mapped LCME elements
  };
}
```

### LCME Compliance Heatmap

```typescript
interface LCMECoverageData {
  standards: string[];               // e.g. ["Standard 7", "Standard 8", "Standard 9"]
  elements: string[];                // e.g. ["7.1", "7.2", "7.3", "8.1", ...]
  coverage: Record<string, number>;  // e.g. { "7.1": 85, "7.2": 92, "7.3": 45, ... }
  // Color coding:
  //   0%     -> gray    (no coverage)
  //   < 50%  -> red     (critical gap)
  //   50-79% -> amber   (needs attention)
  //   >= 80% -> green   (adequate)
}
```

---

## 15. Faculty Course Management (6 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/faculty/courses` | `CourseList` | `pages/faculty/CourseList.tsx` | **Read:** `GET /faculty/courses` |
| `/faculty/courses/create` | `CreateEditCourse` | `pages/faculty/CreateEditCourse.tsx` | **Write:** `POST /faculty/courses` |
| `/faculty/courses/:id` | `CourseDetailView` | `pages/faculty/CourseDetailView.tsx` | **Read:** `GET /faculty/courses/{id}` |
| `/faculty/courses/:id/edit` | `CreateEditCourse` | `pages/faculty/CreateEditCourse.tsx` | **Write:** `PUT /faculty/courses/{id}` |
| `/faculty/courses/:id/roster` | `CourseRoster` | `pages/faculty/CourseRoster.tsx` | **Read:** `GET /faculty/courses/{id}/roster` |

### Course Roster Response

```typescript
interface CourseRosterData {
  course_id: string;
  students: {
    id: string;
    name: string;
    email: string;
    year_level: string;
    mastery_score: number;         // 0-100
    questions_completed: number;
    last_active: string;
  }[];
  total: number;
}
```

---

## 16. Communications (3 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/faculty/communications` | `FacultyCommunicationHub` | `pages/communications/FacultyCommunicationHub.tsx` | **CRUD:** `/communications?type=faculty` |
| `/student/support` | `StudentSupportCenter` | `pages/communications/StudentSupportCenter.tsx` | **CRUD:** `/communications?type=student_support` |
| `/admin/announcements` | `AnnouncementSystem` | `pages/communications/AnnouncementSystem.tsx` | **CRUD:** `/announcements` |

### Announcement Model

```typescript
interface Announcement {
  id: string;
  title: string;
  body: string;
  audience: "all" | "faculty" | "students" | "admins";
  priority: "low" | "medium" | "high";
  publish_date: string;
  created_by: string;
  status: "draft" | "published";
}
```

---

## 17. Templates & Operations (2 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/templates` | `QuestionTemplates` | `pages/templates/QuestionTemplates.tsx` | **CRUD:** `/templates` |
| `/bulk-operations` | `BulkOperations` | `pages/operations/BulkOperations.tsx` | **Write:** `POST /bulk/{operation}` |

### Bulk Operations

```typescript
type BulkOperation =
  | { operation: "approve"; question_ids: string[] }
  | { operation: "reject"; question_ids: string[]; reason: string }
  | { operation: "tag"; question_ids: string[]; tags: string[] }
  | { operation: "export"; question_ids: string[]; format: "csv" | "json" | "qti" }
  | { operation: "delete"; question_ids: string[] };
```

---

## 18. Settings, Profile, Notifications, Help (4 screens)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/settings` | `Settings` | `pages/settings/Settings.tsx` | **Read/Write:** `GET/PUT /user/settings` |
| `/profile` | `Profile` | `pages/profile/Profile.tsx` | **Read/Write:** `GET/PUT /user/profile` |
| `/notifications` | `Notifications` | `pages/notifications/Notifications.tsx` | **Read:** `GET /notifications?unread=true`. **Write:** `PATCH /notifications/{id}/read` |
| `/help` | `Help` | `pages/help/Help.tsx` | Static + FAQs |

### Notification Model

```typescript
interface Notification {
  id: string;
  type: "info" | "warning" | "success" | "action_required";
  title: string;
  message: string;
  read: boolean;
  created_at: string;
  action_href?: string;
}
```

---

## 19. Public Application (1 screen)

| Route | Component | Source File | Data Contract |
|-------|-----------|-------------|---------------|
| `/apply` | `InstitutionApplication` | `pages/InstitutionApplication.tsx` | **Write:** `POST /applications` -- institution application form |

---

## 20. Error Pages (1 screen)

| Route | Component | Source File |
|-------|-----------|-------------|
| `*` | `NotFound` | `pages/errors/NotFound.tsx` |

---

## Cross-Cutting Backend Requirements

### Authentication & Authorization

- JWT/session-based auth with role-based access control (RBAC)
- **Roles:** `student`, `faculty`, `advisor`, `institutional_admin`, `super_admin`
- Email verification flow with token-based URLs
- Invitation system with access codes for admins
- Password reset flow

### Real-Time / Polling Endpoints

These screens require either Server-Sent Events (SSE) or polling:

| Feature | Endpoint Pattern | Update Frequency |
|---------|-----------------|-----------------|
| Syllabus processing | `GET /courses/{id}/processing-status` | Every 2-3 seconds |
| Lecture processing | `GET /lectures/{id}/processing-status` | Every 2-3 seconds |
| Batch question generation | `GET /generation/batch/{id}/progress` | Every 1-2 seconds |

### File Upload Endpoints

| Upload Type | Endpoint | Accepted Formats |
|-------------|----------|-----------------|
| Syllabus | `POST /courses/{id}/syllabus` | PDF, DOCX |
| Lecture materials | `POST /courses/{id}/lectures` | PDF, PPTX, MP4 |
| Week materials | `POST /weeks/{id}/materials` | PDF, PPTX, images |
| Faculty question bulk import | `POST /uploads/questions` | CSV, Excel (.xlsx) |
| Retired exam import | `POST /exams/retired` | PDF, DOCX |

### Knowledge Graph API

- Hierarchical browsing: Domain -> Concept -> SubConcept
- Full-text search across nodes
- Relationship traversal: TEACHES, VERIFIED, ADDRESSED, ASSESSES, FULFILLS
- Coverage gap detection across the graph

### AI Pipeline Integration

| Capability | Endpoint | Notes |
|------------|----------|-------|
| Question generation | `POST /generate/questions` | Multi-model pipeline with Evidence-Centered Design validation |
| Conversational refinement | `POST /questions/{id}/refine` | Up to 5 iterations per question |
| AI-powered refinement | `POST /questions/{id}/ai-refine` | Automated improvement suggestions |
| Gap analysis | `GET /courses/{id}/gap-analysis` | Coverage + difficulty + USMLE balance |
| Blueprint validation | `POST /exams/{id}/validate` | System distribution + difficulty balance |

### Competency Framework Alignment

The system must model and validate against six competency frameworks:

| Framework | Purpose | Example Values |
|-----------|---------|---------------|
| **USMLE** | Step 1/2 taxonomy | Organ systems, disciplines |
| **ACGME** | Core competencies | Patient Care, Medical Knowledge, Practice-Based Learning, etc. |
| **EPA** | Entrustable Professional Activities | 13 core EPAs |
| **Bloom's** | Cognitive taxonomy | Remember, Understand, Apply, Analyze, Evaluate, Create |
| **Miller's** | Clinical competence pyramid | Knows, Knows How, Shows How, Does |
| **LCME** | Accreditation standards | Standards 7, 8, 9 (elements 7.1, 7.2, etc.) |

---

## Known Issues & Consolidation Notes

### Duplicate Components

| Component Name | Location 1 | Location 2 | Notes |
|---------------|-----------|-----------|-------|
| `FacultyDashboard` | `pages/dashboard/FacultyDashboard.tsx` | `pages/faculty/FacultyDashboard.tsx` | Different data shapes -- consolidate or clearly differentiate |

### Missing Auth Context

None of the screens currently consume a shared auth context. Backend integration requires:

1. A global `AuthProvider` wrapping the router
2. Pass `user`, `token`, and `role` to all protected routes
3. Route guards redirecting unauthenticated users to `/login`
4. Role-based route protection (e.g., `/admin/*` requires `super_admin` role)

### Route Aliases

Several routes point to the same component -- consider consolidating with redirects:

- `/student-dashboard` and `/student` and `/student/dashboard` -> all `StudentDashboard`
- `/faculty-dashboard` and `/dashboard` -> both faculty dashboard variants
- `/institution` and `/institution/dashboard` -> both `InstitutionalAdminDashboard`
- `/admin` and `/admin/dashboard` -> both `AdminDashboard`
- `/email-verification` and `/verify-email` -> both `EmailVerification`

### Placeholder Routes

Some routes reuse another component as a placeholder:

- `/institution/students` -> uses `InstitutionalAdminDashboard` (needs own component)
- `/institution/courses` -> uses `InstitutionalAdminDashboard` (needs own component)
- `/institution/blueprints` -> uses `InstitutionalAdminDashboard` (needs own component)
- `/faculty/questions/batch-upload` -> uses `GenerateQuestionsTopic` (needs own component)
- `/faculty/questions/retired-upload` -> uses `GenerateQuestionsTopic` (needs own component)
